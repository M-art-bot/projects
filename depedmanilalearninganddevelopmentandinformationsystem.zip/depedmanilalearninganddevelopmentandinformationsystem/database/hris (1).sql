-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2021 at 01:12 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hris`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE `actions` (
  `action_id` int(11) NOT NULL,
  `action_type` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`action_id`, `action_type`) VALUES
(1, 'New'),
(2, 'In Review'),
(3, 'Phone Screen'),
(4, 'Assessment'),
(5, 'Interview'),
(6, 'Background Check'),
(7, 'Offered'),
(8, 'Hired'),
(9, 'Disqualified');

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `activity_id` int(11) NOT NULL,
  `applicant_Id` int(20) NOT NULL,
  `activity_name` varchar(255) NOT NULL,
  `activity_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`activity_id`, `applicant_Id`, `activity_name`, `activity_created_timestamp`) VALUES
(1, 16, 'You submit a/an TIP Course 1A (M1.2)', '2021-05-23 15:55:52');

-- --------------------------------------------------------

--
-- Table structure for table `address_informations`
--

CREATE TABLE `address_informations` (
  `address_information_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `residential_address` text NOT NULL,
  `permanent_address` text NOT NULL,
  `address_informations_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `address_informations`
--

INSERT INTO `address_informations` (`address_information_id`, `applicant_id`, `residential_address`, `permanent_address`, `address_informations_created_timestamp`) VALUES
(1, 1, '289 E. Castillo St. Maypajo, Caloocan City', '289 E. Castillo St. Maypajo, Caloocan City', '2021-05-07 09:46:41');

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `applicant_id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `middle_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `extension_name` varchar(25) DEFAULT NULL,
  `telephone_no` text NOT NULL,
  `mobile_no` text NOT NULL,
  `email_address` varchar(50) DEFAULT NULL,
  `date_of_birth` text NOT NULL,
  `place_of_birth` text NOT NULL,
  `gender` text NOT NULL,
  `civil_status` text NOT NULL,
  `citizenship` text NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `job_id` int(50) DEFAULT NULL,
  `action_id` int(11) DEFAULT NULL,
  `activity_id` int(11) NOT NULL,
  `rate` int(2) DEFAULT 0,
  `personal` int(11) NOT NULL,
  `fam` int(11) NOT NULL,
  `educ` int(10) NOT NULL,
  `csc` int(11) NOT NULL,
  `work` int(11) NOT NULL,
  `vw` int(11) NOT NULL,
  `ld` int(11) NOT NULL,
  `other` int(11) NOT NULL,
  `res` int(11) NOT NULL,
  `per` int(11) NOT NULL,
  `other_1` int(11) NOT NULL,
  `other_2` int(2) NOT NULL,
  `applicant_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`applicant_id`, `first_name`, `middle_name`, `last_name`, `extension_name`, `telephone_no`, `mobile_no`, `email_address`, `date_of_birth`, `place_of_birth`, `gender`, `civil_status`, `citizenship`, `password`, `job_id`, `action_id`, `activity_id`, `rate`, `personal`, `fam`, `educ`, `csc`, `work`, `vw`, `ld`, `other`, `res`, `per`, `other_1`, `other_2`, `applicant_created_timestamp`) VALUES
(1, 'JOSE ANDRESS', 'MORGADO', 'DEL ROSARIO', 'N/A', '', '', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-05-04 08:17:45'),
(14, 'LILIBETH', 'N/A', 'CALIPES', 'N/A', 'N/A', 'N/A', 'LILIBETHCALIPES04@GMAIL.COM', '04/09/1998', 'MANILA', 'FEMALE', 'SINGLE', 'FILIPINO', '1addcc92aed4f17f817b87506c80930d', 1, 2, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2021-05-08 04:28:55'),
(15, 'JOSE ANDRESS', NULL, 'DEL ROSARIO', NULL, '', '', 'JOSEANDRESS1998.14@GMAIL.COM1', '', '', '', '', '', '04df7bf1c12cb638654aea74ea32d7d9', NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-05-08 08:25:53'),
(16, 'JOSE ANDRESS', 'MORGADO', 'DEL ROSARIO', 'N/A', 'N/A', '09152544359', 'joseandress.delrosario@deped.gov.ph', '14/08/1998', 'MANILA', 'MALE', 'SINGLE', 'FILIPINO', '6b516056c1afabfa4943db11b65ee51f', 1, 8, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, '2021-05-10 03:03:20'),
(17, 'MARLON', 'N/A', 'COTANDA', NULL, '', '', 'MARLONCOTANDA@GMAIL.COM', '', '', '', '', '', '4fa34c31e70ad7580f0cb4e53689e0b6', NULL, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2021-05-15 07:28:38'),
(18, 'JUAN', 'N/A', 'DELA CRUZ', 'N/A', 'N/A', 'N/A', 'DELACRUZJUAN@GMAIL.COM', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'bbfd3f026f042154a2c55079cad9365b', 2, 8, 0, 5, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, '2021-05-15 16:15:28');

-- --------------------------------------------------------

--
-- Table structure for table `civil_service_eligibility`
--

CREATE TABLE `civil_service_eligibility` (
  `civil_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `civil_service` text NOT NULL,
  `rating` text NOT NULL,
  `date_of_examination` text NOT NULL,
  `place_of_examination` text NOT NULL,
  `license_number` text NOT NULL,
  `date_of_validity` text NOT NULL,
  `civil_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `civil_service_eligibility`
--

INSERT INTO `civil_service_eligibility` (`civil_id`, `applicant_id`, `civil_service`, `rating`, `date_of_examination`, `place_of_examination`, `license_number`, `date_of_validity`, `civil_created_timestamp`) VALUES
(72, 16, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-13 22:40:52'),
(73, 14, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 12:09:47'),
(74, 18, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 16:25:45');

-- --------------------------------------------------------

--
-- Table structure for table `contact_informations`
--

CREATE TABLE `contact_informations` (
  `contact_information_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `contact_no` text NOT NULL,
  `contact_informations_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact_informations`
--

INSERT INTO `contact_informations` (`contact_information_id`, `applicant_id`, `contact_no`, `contact_informations_created_timestamp`) VALUES
(1, 1, '9152544359', '2021-05-07 09:42:51');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `courses_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `courses_name` text NOT NULL,
  `courses_g_drive` text NOT NULL,
  `courses_score` varchar(50) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`courses_id`, `applicant_id`, `courses_name`, `courses_g_drive`, `courses_score`, `timestamp`) VALUES
(1, 16, 'TIP Course 1A (M1.2)', 'https://drive.google.com/file/d/1kMr7WXMU2YNzcpDaNrATwTyezhZwpO32/view', '96', '2021-05-23 15:55:52');

-- --------------------------------------------------------

--
-- Table structure for table `educational_backgrounds`
--

CREATE TABLE `educational_backgrounds` (
  `educational_backgrounds_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `es_name` varchar(50) NOT NULL,
  `es_year` text NOT NULL,
  `secondary_name` varchar(50) NOT NULL,
  `secondary_year` text NOT NULL,
  `voc_name` varchar(50) NOT NULL,
  `voc_year` text NOT NULL,
  `college_name` varchar(50) NOT NULL,
  `college_year` text NOT NULL,
  `grad_name` varchar(50) NOT NULL,
  `grad_year` text NOT NULL,
  `educational_backgrounds_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `educational_backgrounds`
--

INSERT INTO `educational_backgrounds` (`educational_backgrounds_id`, `applicant_id`, `es_name`, `es_year`, `secondary_name`, `secondary_year`, `voc_name`, `voc_year`, `college_name`, `college_year`, `grad_name`, `grad_year`, `educational_backgrounds_created_timestamp`) VALUES
(1, 16, 'ANDRES BONIFACIO ELEMENTARY SCHOOL', '2010', 'CAYETANO ARELLANO HIGH SCHOOL', '2014', 'N/A', 'N/A', 'UNIVERSIDAD DE MANILA', '2020', 'N/A', 'N/A', '2021-05-12 08:36:47'),
(2, 14, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 12:05:44'),
(3, 18, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 16:25:08');

-- --------------------------------------------------------

--
-- Table structure for table `family_background`
--

CREATE TABLE `family_background` (
  `family_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `spouse_last_name` text NOT NULL,
  `spouse_first_name` text NOT NULL,
  `spouse_middle_name` text NOT NULL,
  `spouse_extension_name` text NOT NULL,
  `occupation` text NOT NULL,
  `company_name` text NOT NULL,
  `company_address` text NOT NULL,
  `company_tel_no` text NOT NULL,
  `fathers_last_name` text NOT NULL,
  `fathers_first_name` text NOT NULL,
  `fathers_middle_name` text NOT NULL,
  `fathers_extension_name` text NOT NULL,
  `mothers_maiden_name` text NOT NULL,
  `mothers_last_name` text NOT NULL,
  `mothers_first_name` text NOT NULL,
  `mothers_middle_name` text NOT NULL,
  `family_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `family_background`
--

INSERT INTO `family_background` (`family_id`, `applicant_id`, `spouse_last_name`, `spouse_first_name`, `spouse_middle_name`, `spouse_extension_name`, `occupation`, `company_name`, `company_address`, `company_tel_no`, `fathers_last_name`, `fathers_first_name`, `fathers_middle_name`, `fathers_extension_name`, `mothers_maiden_name`, `mothers_last_name`, `mothers_first_name`, `mothers_middle_name`, `family_created_timestamp`) VALUES
(1, 16, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'DEL ROSARIO', 'TEUDULO', 'REYES', 'N/A', 'N/A', 'MORGADO', 'LUCIA', 'FERRER', '2021-05-12 05:15:51'),
(2, 14, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 11:55:41'),
(3, 18, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 16:24:26');

-- --------------------------------------------------------

--
-- Table structure for table `id_cards`
--

CREATE TABLE `id_cards` (
  `id_card_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `gsis_no` varchar(50) NOT NULL,
  `pagibig_no` varchar(50) NOT NULL,
  `phil_no` varchar(50) NOT NULL,
  `sss_no` varchar(50) NOT NULL,
  `tin_no` varchar(50) NOT NULL,
  `id_card_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `id_cards`
--

INSERT INTO `id_cards` (`id_card_id`, `applicant_id`, `gsis_no`, `pagibig_no`, `phil_no`, `sss_no`, `tin_no`, `id_card_created_timestamp`) VALUES
(1, 1, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-07 09:14:39');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `job_id` int(11) NOT NULL,
  `position_title` varchar(75) NOT NULL,
  `item_no` varchar(75) NOT NULL,
  `pay_grade` varchar(75) NOT NULL,
  `salary` varchar(75) NOT NULL,
  `education` varchar(75) NOT NULL,
  `training` varchar(75) NOT NULL,
  `experience` varchar(75) NOT NULL,
  `eligibility` varchar(75) NOT NULL,
  `place_of_assignment` varchar(75) NOT NULL,
  `is_active` int(10) NOT NULL,
  `job_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`job_id`, `position_title`, `item_no`, `pay_grade`, `salary`, `education`, `training`, `experience`, `eligibility`, `place_of_assignment`, `is_active`, `job_created_timestamp`) VALUES
(1, 'ADMINISTRATIVE OFFICER II', '*************', '2', '12000', 'BACHELOR`S DEGREE RELEVANT TO THE JOB', 'N/A', 'N/A', 'CIVIL SERVICE', 'DCS', 1, '2021-05-15 07:35:51'),
(2, 'ADMINISTRATIVE OFFICER I', '*************', '2', '12000', 'BACHELOR`S DEGREE RELEVANT TO THE JOB', 'N/A', 'N/A', 'CIVIL SERVICE', 'DCS-MANILA', 1, '2021-05-15 15:43:24');

-- --------------------------------------------------------

--
-- Table structure for table `ld`
--

CREATE TABLE `ld` (
  `ld_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `date_start` text NOT NULL,
  `date_end` text NOT NULL,
  `number` text NOT NULL,
  `type` text NOT NULL,
  `sponsor` text NOT NULL,
  `ld_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ld`
--

INSERT INTO `ld` (`ld_id`, `applicant_id`, `title`, `date_start`, `date_end`, `number`, `type`, `sponsor`, `ld_created_timestamp`) VALUES
(0, 16, 'IT SUMMIT 2018', '21/11/2018', '21/11/2018', '8', 'N/A', 'UDM-CET', '2021-05-15 11:03:48'),
(0, 14, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 12:13:54'),
(0, 18, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 16:28:42');

-- --------------------------------------------------------

--
-- Table structure for table `others`
--

CREATE TABLE `others` (
  `other_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `hobbies` text NOT NULL,
  `recognition` text NOT NULL,
  `membership` text NOT NULL,
  `others_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `others`
--

INSERT INTO `others` (`other_id`, `applicant_id`, `hobbies`, `recognition`, `membership`, `others_created_timestamp`) VALUES
(10, 14, 'N/A', 'N/A', 'N/A', '2021-05-15 12:14:05'),
(11, 18, 'N/A', 'N/A', 'N/A', '2021-05-15 16:28:05'),
(12, 16, 'WEB DEVELOPMENT', 'TEAM LEADER', 'UDM DEV TEAM', '2021-05-23 05:28:17'),
(13, 16, 'SYSTEM ANALYS | SYSTEM TROUBLESHOOTING', 'N/A', 'UDM DEV TEAM', '2021-05-23 05:28:17'),
(14, 16, 'MANAGEMENT OF INFORMATION SYSTETM', 'N/A', 'UDM DEV TEAM', '2021-05-23 05:28:17'),
(15, 16, 'WEB DEVELOPMENT', 'N/A', 'RPM BUSINESS SOLUTIONS', '2021-05-23 05:28:17'),
(16, 16, 'NETWORK ASSISTANT', 'N/A', 'INFOCOM-MAKATI', '2021-05-23 05:28:17');

-- --------------------------------------------------------

--
-- Table structure for table `permanent_address`
--

CREATE TABLE `permanent_address` (
  `per_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `per_lot_no` text NOT NULL,
  `per_street` text NOT NULL,
  `per_subdivision` text NOT NULL,
  `per_brgy` text NOT NULL,
  `per_city` text NOT NULL,
  `per_prov` text NOT NULL,
  `per_zip` text NOT NULL,
  `per_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `permanent_address`
--

INSERT INTO `permanent_address` (`per_id`, `applicant_id`, `per_lot_no`, `per_street`, `per_subdivision`, `per_brgy`, `per_city`, `per_prov`, `per_zip`, `per_created_timestamp`) VALUES
(1, 16, '289', 'E. CASTILLO ST.', 'MAYPAJO', '31', 'CALOOCAN CITY', 'NCR', '1014', '2021-05-11 12:52:42'),
(2, 14, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 11:59:06'),
(3, 18, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 16:22:45');

-- --------------------------------------------------------

--
-- Table structure for table `personal_informations`
--

CREATE TABLE `personal_informations` (
  `personal_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `height` text NOT NULL,
  `weight` text NOT NULL,
  `blood_type` text NOT NULL,
  `gsis` text NOT NULL,
  `pagibig` text NOT NULL,
  `philhealth` text NOT NULL,
  `sss` text NOT NULL,
  `tin` text NOT NULL,
  `employee_no` text NOT NULL,
  `personal_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `personal_informations`
--

INSERT INTO `personal_informations` (`personal_id`, `applicant_id`, `height`, `weight`, `blood_type`, `gsis`, `pagibig`, `philhealth`, `sss`, `tin`, `employee_no`, `personal_created_timestamp`) VALUES
(1, 16, '5\'3', '69', 'A+', 'N/A', 'N/A', 'N/A', 'N/A', '375-323-501', 'N/A', '2021-05-11 13:30:25'),
(2, 14, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 11:59:25'),
(3, 18, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 16:23:17');

-- --------------------------------------------------------

--
-- Table structure for table `residential_address`
--

CREATE TABLE `residential_address` (
  `res_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `res_lot_no` text NOT NULL,
  `res_street` text NOT NULL,
  `res_subdivision` text NOT NULL,
  `res_brgy` text NOT NULL,
  `res_city` text NOT NULL,
  `res_prov` text NOT NULL,
  `res_zip` text NOT NULL,
  `res_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `residential_address`
--

INSERT INTO `residential_address` (`res_id`, `applicant_id`, `res_lot_no`, `res_street`, `res_subdivision`, `res_brgy`, `res_city`, `res_prov`, `res_zip`, `res_created_timestamp`) VALUES
(1, 16, '289', 'E. CASTILLO ST.', 'MAYPAJO', '31', 'CALOOCAN CITY', 'NCR', '1014', '2021-05-11 12:35:19'),
(2, 14, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 11:58:37'),
(3, 18, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 16:22:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_type` varchar(5) DEFAULT NULL,
  `user_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `user_type`, `user_created_timestamp`) VALUES
(1, 'admin', '39d67050343b8ba580da96adab996c13', '1', '2021-05-02 13:25:55');

-- --------------------------------------------------------

--
-- Table structure for table `voluntary`
--

CREATE TABLE `voluntary` (
  `voluntary_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `voluntary_name` text NOT NULL,
  `date_start` text NOT NULL,
  `date_end` text NOT NULL,
  `number` text NOT NULL,
  `position` text NOT NULL,
  `voluntary_created_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `voluntary`
--

INSERT INTO `voluntary` (`voluntary_id`, `applicant_id`, `voluntary_name`, `date_start`, `date_end`, `number`, `position`, `voluntary_created_timestamp`) VALUES
(7, 16, 'JUNIOR PHILLIPINE COMPUTER SOCIETY(JPCS-CET)', '2019', '2020', 'N/A', '4TH YEAR REPRESENTATIVE', '2021-05-15 10:31:09'),
(8, 16, 'JUNIOR PHILLIPINE COMPUTER SOCIETY(JPCS-CET)', '2018', '2019', 'N/A', '3RD YEAR REPRESENTATIVE', '2021-05-15 10:31:09'),
(9, 16, 'ROTARACT', '2017', '2020', 'N/A', 'MEMBER', '2021-05-15 10:31:09'),
(10, 14, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 12:13:23'),
(11, 18, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 16:27:08');

-- --------------------------------------------------------

--
-- Table structure for table `work_experiences`
--

CREATE TABLE `work_experiences` (
  `work_id` int(11) NOT NULL,
  `applicant_id` int(11) NOT NULL,
  `position_title` text NOT NULL,
  `date_start` text NOT NULL,
  `date_end` text NOT NULL,
  `company` text NOT NULL,
  `monthly_salary` text NOT NULL,
  `pay_grade` text NOT NULL,
  `status` text NOT NULL,
  `is_gov` text NOT NULL,
  `work_created_time_stamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `work_experiences`
--

INSERT INTO `work_experiences` (`work_id`, `applicant_id`, `position_title`, `date_start`, `date_end`, `company`, `monthly_salary`, `pay_grade`, `status`, `is_gov`, `work_created_time_stamp`) VALUES
(1, 16, 'DADA', 'DADA', 'DADADA', 'DAD', 'DADA', 'DADA', 'DA', 'DADADA', '2021-05-14 05:27:09'),
(2, 16, '3231', '321', '3123213', '33123', '3132', '31', '313', '3131', '2021-05-14 05:27:09'),
(3, 14, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 12:11:31'),
(4, 18, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '2021-05-15 16:26:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
  ADD PRIMARY KEY (`action_id`);

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`activity_id`);

--
-- Indexes for table `address_informations`
--
ALTER TABLE `address_informations`
  ADD PRIMARY KEY (`address_information_id`);

--
-- Indexes for table `applicants`
--
ALTER TABLE `applicants`
  ADD PRIMARY KEY (`applicant_id`);

--
-- Indexes for table `civil_service_eligibility`
--
ALTER TABLE `civil_service_eligibility`
  ADD PRIMARY KEY (`civil_id`);

--
-- Indexes for table `contact_informations`
--
ALTER TABLE `contact_informations`
  ADD PRIMARY KEY (`contact_information_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`courses_id`);

--
-- Indexes for table `educational_backgrounds`
--
ALTER TABLE `educational_backgrounds`
  ADD PRIMARY KEY (`educational_backgrounds_id`);

--
-- Indexes for table `family_background`
--
ALTER TABLE `family_background`
  ADD PRIMARY KEY (`family_id`);

--
-- Indexes for table `id_cards`
--
ALTER TABLE `id_cards`
  ADD PRIMARY KEY (`id_card_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `others`
--
ALTER TABLE `others`
  ADD PRIMARY KEY (`other_id`);

--
-- Indexes for table `permanent_address`
--
ALTER TABLE `permanent_address`
  ADD PRIMARY KEY (`per_id`);

--
-- Indexes for table `personal_informations`
--
ALTER TABLE `personal_informations`
  ADD PRIMARY KEY (`personal_id`);

--
-- Indexes for table `residential_address`
--
ALTER TABLE `residential_address`
  ADD PRIMARY KEY (`res_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `voluntary`
--
ALTER TABLE `voluntary`
  ADD PRIMARY KEY (`voluntary_id`);

--
-- Indexes for table `work_experiences`
--
ALTER TABLE `work_experiences`
  ADD PRIMARY KEY (`work_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
  MODIFY `action_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `applicants`
--
ALTER TABLE `applicants`
  MODIFY `applicant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `civil_service_eligibility`
--
ALTER TABLE `civil_service_eligibility`
  MODIFY `civil_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `contact_informations`
--
ALTER TABLE `contact_informations`
  MODIFY `contact_information_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `courses_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `educational_backgrounds`
--
ALTER TABLE `educational_backgrounds`
  MODIFY `educational_backgrounds_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `family_background`
--
ALTER TABLE `family_background`
  MODIFY `family_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `id_cards`
--
ALTER TABLE `id_cards`
  MODIFY `id_card_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `others`
--
ALTER TABLE `others`
  MODIFY `other_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `permanent_address`
--
ALTER TABLE `permanent_address`
  MODIFY `per_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `personal_informations`
--
ALTER TABLE `personal_informations`
  MODIFY `personal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `residential_address`
--
ALTER TABLE `residential_address`
  MODIFY `res_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `voluntary`
--
ALTER TABLE `voluntary`
  MODIFY `voluntary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `work_experiences`
--
ALTER TABLE `work_experiences`
  MODIFY `work_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
