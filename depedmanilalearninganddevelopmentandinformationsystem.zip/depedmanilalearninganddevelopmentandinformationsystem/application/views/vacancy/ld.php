<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-12">
                <div class="card-body px-0 pt-0 pb-2"> 
                    <div class="card-header pb-0 text-left bg-transparent">
                       <a class="btn btn-warning"href="javascript:window.history.go(-1);"><< BACK</a>
                        <h3 class="font-weight-bolder text-dark text-gradient">Welcome</h3>
                    </div>
                    <div class="card-body">

                        <h3 class="font-weight-bolder text-dark text-gradient">LEARNING AND DEVELOPMENT (L&D) INTERVENTIONS/TRAINING PROGRAMS ATTENDED</h3>
                        <p>Type N/A IF NOT APPLICABLE</p>


                        <?php if ($this->session->flashdata('success_ld')) : ?>

                            <div class="alert alert-success d-flex align-items-center" role="alert">
                                <svg class="bi flex-shrink-0 me-2" width="24" height="24"><use xlink:href="#check-circle-fill"/></svg>
                                <div>
                                   Your 
                                        LEARNING AND DEVELOPMENT (L&D) INTERVENTIONS/TRAINING PROGRAMS ATTENDED has been successfully updated.
                                </div>
                            </div>

                        <?php endif; ?>

                           <?php if ($this->session->flashdata('success_add_ld')) : ?>

                            <div class="alert alert-success d-flex align-items-center" role="alert">
                                <svg class="bi flex-shrink-0 me-2" width="24" height="24"><use xlink:href="#check-circle-fill"/></svg>
                                <div>
                                    Your LEARNING AND DEVELOPMENT (L&D) INTERVENTIONS/TRAINING PROGRAMS ATTENDEDld work has been successfully added.
                                </div>
                            </div>

                        <?php endif; ?>


                       <?php if ($this->session->flashdata('form_ld')) : ?>

                       <?= form_open("Info/ld_add", array('class'=>'row g-3 needs-validation', 'novalidate'=>''))?>

                        <div class="table-responsive p-0 col-12">

                            <table class="table table-stripe" id="career" style="width:100%" >
                                <thead>
                                    <tr>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                
                                      <th><button type="button" id="add_row" class="btn btn-default"><i class="fa fa-plus"></i></button></th>
                                    </tr>
                                </thead>

                               <tbody>
                                 <tr id="row_1">
                                   <td>     

                                          <div class="col-12">
                                            <label class="form-label">TITLE</label>
                                            <input type="text" name="title[]" id="title_1" class="form-control" autocomplete="off" required placeholder="NAME & ADDRESS OF ORGANIZATION">
                                          
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide TITLE
                                            </div>
                                          </div>
                                    </td>
                                    <td>
                                            <label class="form-label">Date Started(dd/mm/yyyy)</label>
                                            <input type="text" name="date_start[]" id="date_start_1" class="form-control" placeholder="Date started"autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date started
                                            </div>
                                    
                                    </td>
                                    <td>
                                       
                                            <label class="form-label">Date Ended(dd/mm/yyyy)</label>
                                            <input type="text" name="date_end[]" id="date_end_1" class="form-control" autocomplete="off" required placeholder="Date Ended">
                                           
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date ended
                                            </div>
                                     
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">NUMBER OF HOURS</label>
                                            <input type="text" name="number[]" id="number_1" class="form-control" autocomplete="off" required placeholder="Company">
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                 Please provide NUMBER OF HOURS
                                            </div>
                                        
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">TYPE OF LD</label>
                                            <input type="text" name="type[]" id="type_1" placeholder="TYPE OF LD" class="form-control" autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide TYPE OF LD
                                            </div>
                                                                    
                                       
                                    </td>  
                                    <td>
                                      
                                            <label class="form-label">CONDUCTED/SPONSORED BY</label>
                                            <input type="text" name="sponsor[]" id="sponsor_1" placeholder="CONDUCTED/SPONSORED BY" class="form-control" autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide CONDUCTED/SPONSORED BY
                                            </div>
                                                                    
                                       
                                    </td> 
                                    <td>
                                        <button type="button" class="btn btn-default" onclick="removeRow('1')"><i class="fa fa-close"></i></button>
                                    </td>
                                 </tr>
                               </tbody>

                            </table>

                        </div>

                    <?php endif; ?>

                    <?php if ($this->session->flashdata('form_ld_id')) : ?>
                    <?= form_open("Info/ld_update", array('class'=>'row g-3 needs-validation', 'novalidate'=>''))?>

                        <div class="table-responsive p-0 col-12">

                            <table class="table table-stripe" id="career" style="width:100%" >
                                <thead>
                                    <tr>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                   <button type="button" id="add_row" class="btn btn-primary">  Add training programs</i></button></th>
                                    </tr>
                                </thead>

                               <tbody>
                
                       
                                    <?php $x = 1; ?>
                                        <?php foreach ($order_data['order_item'] as $key => $val): ?>
                                           <tr id="row_<?= $x;?>">
                                   <td> 
                                          <div class="col-12">
                                            <label class="form-label">TITLE</label>
                                            <input type="text" name="title[]" id="title_1" class="form-control" autocomplete="off" required placeholder="NAME & ADDRESS OF ORGANIZATION" value="<?php echo $val['title'];?>">
                                          
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide TITLE
                                            </div>
                                      </div>
                                    </td>
                                    <td>
                                            <label class="form-label">Date Started(dd/mm/yyyy)</label>
                                            <input type="text" name="date_start[]" id="date_start_1" class="form-control" placeholder="Date started"autocomplete="off" value="<?php echo $val['date_start'];?>"required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date started
                                            </div>
                                    
                                    </td>
                                    <td>
                                       
                                            <label class="form-label">Date Ended(dd/mm/yyyy)</label>
                                            <input type="text" name="date_end[]" id="date_end_1" value="<?php echo $val['date_end'];?>" class="form-control" autocomplete="off" required placeholder="Date Ended">
                                           
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date ended
                                            </div>
                                     
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">NUMBER OF HOURS</label>
                                            <input type="text" name="number[]" id="number_1" class="form-control" value="<?php echo $val['number'];?>" autocomplete="off" required placeholder="Company">
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                 Please provide NUMBER OF HOURS
                                            </div>
                                        
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">TYPE OF LD</label>
                                            <input type="text" name="type[]" id="type_1" placeholder="TYPE OF LD" value="<?php echo $val['type'];?>" class="form-control" autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide TYPE OF LD
                                            </div>
                                                                    
                                       
                                    </td>  
                                    <td>
                                      
                                            <label class="form-label">CONDUCTED/SPONSORED BY</label>
                                            <input type="text" name="sponsor[]" id="sponsor_1"  value="<?php echo $val['sponsor'];?>"placeholder="CONDUCTED/SPONSORED BY" class="form-control" autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide CONDUCTED/SPONSORED BY
                                            </div>
                                                                    
                                       
                                    </td> 
                                 
                                    <td>
                                        <button type="button" class="btn btn-default" onclick="removeRow('<?= $x;?>')"><i class="fa fa-close"></i></button>
                                    </td>
                                 </tr>
                                    <?php $x++; ?>
                                        <?php endforeach; ?>
                              
                                </tbody>
                            </table>

                        </div>

                    <?php endif; ?>
                        <div class="col-12">  
                            <button class="btn btn-primary" type="submit">Save</button>
                        </div>
                        <?= form_close();?>
                        <hr>
             
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>

<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>

<script type="text/javascript">
    // Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()

$("#add_row").unbind('click').bind('click', function() {
      var table = $("#career");
      var count_table_tbody_tr = $("#career tbody tr").length;
      var row_id = count_table_tbody_tr + 1;
 

               var html = '<tr id="row_'+row_id+'">'+
                    '<td><input type="text" name="title[]" id="title_'+row_id+'" class="form-control"  required placeholder="TITLE"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide TITLE</div></td>'+

                     '<td><input type="text" name="date_start[]" id="date_start_'+row_id+'" class="form-control"  required placeholder="DATE STARTED"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Date Started</div></td>'+

                      '<td><input type="text" name="date_end[]" id="date_end_'+row_id+'" class="form-control"  required placeholder="DATE ENDED"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Date Ended</div></td>'+


                    '<td><input type="text" name="number[]" id=number_'+row_id+'" class="form-control"  required placeholder="NUMBER OF HOURS"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please NUMBER OF HOURS</div>'+

                    '<td><input type="text" name="type[]" id=type_'+row_id+'" class="form-control"  required placeholder="TYPE"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">TYPE</div>'+

                     '<td><input type="text" name="sponsor[]" id=sponsor_'+row_id+'" class="form-control"  required placeholder="CONDUCTED/SPONSORED BY"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">CONDUCTED/SPONSORED BY</div>'+


                    '<td><button type="button" class="btn btn-default" onclick="removeRow(\''+row_id+'\')"><i class="fa fa-close"></i></button></td>'+
                    '</tr>';

                if(count_table_tbody_tr >= 1) {
                $("#career tbody tr:last").after(html);  
              }
              else {
                $("#career tbody").html(html);
              }

             

          })
   
    function removeRow(tr_id)
  {
    $("#career tbody tr#row_"+tr_id).remove();

  }

  
</script>

<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
    <symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
    </symbol>
</svg>