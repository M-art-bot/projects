<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Submit Output</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <?= form_open('course/ajax_add',array('id'=>'form','role'=>"form text-left", 'class'=>"row g-3 needs-validation", 'novalidate' => ''));?>
            <div class="mb-3">
            <label for="validationCustom01" class="form-label">Module Name</label>
                    <select name="module_id" class="form-control
                    ">
                    <?php foreach($modules as $module): ?>
                        <option value="<?php echo $module['module_id'];?>"><?= $module['module_name'];?></option>
                    <?php endforeach; ?>
                    </select>
                <div class="invalid-feedback">
                    Please provide a module name.
                </div>
            </div>
             <div class="mb-3">
            <label for="validationCustom01" class="form-label">Paste here your Google Drive`s Link</label>
               
                    <input type="text" class="form-control" name="course_g_drive" placeholder="Google Drive`s Link"  id="validationCustom01" required>
                
                <div class="invalid-feedback">
                    Please provide a Google Drive`s Link.
                </div>
            </div>
             <div class="mb-3">
            <label for="validationCustom01" class="form-label">Your score</label>
               
                    <input type="text" class="form-control" name="score" placeholder="Score"  id="validationCustom01" required>
           
                <div class="invalid-feedback">
                    Please provide a Score.
                </div>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit"  id="btnSave" class="btn btn-primary">Save / Upload</button>
        <?= form_close();?>
      </div>
    </div> 
  </div>
</div>

<div class="container-fluid py-4">
    <div class="row">
         <div class="col-12">
            <div class="card mb-8">
                <div class="card-body">
                    <div class="col-12 text-uppercase text-dark text-xxs font-weight-bolder opacity-7 ">
                         <a class="text-uppercase text-secondary text-lg font-weight-bolder opacity-100" href="javascript:;" onclick="general_ins()">GENERAL INSTRUCTIONS</a>
                    </div>
                     <div class="col-6 pull pull-right">
                            <div class="text-uppercase text-dark text-xxs font-weight-bolder opacity-7 ">
                                 <a class="text-uppercase btn btn-info text-lg font-weight-bolder text-dark" href="javascript:;" onclick="show_form()">SUBMIT OUTPUT</a>
                            </div>
                        </div>
                    <hr>
                    <div class="col-12 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ">
                       <span class="px-2"><a href="<?= base_url().md5('ld-tip');?>" class="text-uppercasee text-secondary text-lg font-weight-bolder">TIP</a></span>
                        <span class="px-2"><a href="<?= base_url().md5('ld-ppst');?>" class="text-uppercase  text-gradient-primary  text-lg font-weight-bolder opacity-100">PPST</a></span>
                        <span class="px-2"><a href="<?= base_url().md5('ld-ppssh');?>" class="text-uppercase text-secondary text-lg font-weight-bolder opacity-100">PPSSH</a></span>
                        <span class="px-2"><a href="<?= base_url().md5('ld-ppss');?>" class="text-uppercase text-secondary text-lg font-weight-bolder opacity-100">PPSS</a></span>
                    </div>
                    <hr>
                    <div class="col-12 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ">
                        <iframe src="https://drive.google.com/embeddedfolderview?id=1p3FaNVHrB9tdqATrMJlSQlYIA9VThCpQ" width="100%" height="480"></iframe>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
       
<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>

<?php if ($this->session->flashdata('success')) : ?>
    <script type="text/javascript">
         Swal.fire({
                  position: 'top-end',
                  icon: 'success',
                  title: 'Your work has been submitted',
                  showConfirmButton: false,
                  timer: 1500
                });
    </script>
<?php endif;?>

 <script type="text/javascript">
                      
    function general_ins(){

        $.confirm({
            icon: 'fa fa-warning',
            title: 'GENERAL INSTRUCTIONS',
            content: 'Read and understand submit output at ....',
            confirmClass: 'bg-success'
        });
    }

    function show_form(){
        $('#staticBackdrop').modal('show');
       document.getElementById("form").reset()
    }

    (function () {
      'use strict'

      var forms = document.querySelectorAll('.needs-validation')

     
      Array.prototype.slice.call(forms)
        .forEach(function (form) {
          form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
            }

            form.classList.add('was-validated')
          }, false)
        })
    })()

</script>