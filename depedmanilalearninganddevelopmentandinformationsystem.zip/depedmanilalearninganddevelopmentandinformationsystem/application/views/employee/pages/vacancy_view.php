<div class="container-fluid py-4">
    <div class="row">
         <div class="col-12">
            <div class="card">
            <div class="card-header pb-0 px-3">
                <h6 class="mb-0"></h6>
            </div>
            <div class="card-body pt-4 p-3">
                <ul class="list-group">
                    <li class="list-group-item border-0 d-flex p-4 mb-2 bg-gray-100 border-radius-lg">
                          <div class="d-flex flex-column">
                            <h6 class="mb-3 text-sm"><?= $jobs['position_title'];?></h6>
                            <span class="mb-2 text-xs">Item No: <span class="text-dark font-weight-bold ms-2"><?= $jobs['item_no'];?></span></span>
                            <span class="mb-2 text-xs">Pay Grade: <span class="text-dark ms-2 font-weight-bold"><?= $jobs['pay_grade'];?></span></span>
                            <span class="text-xs">Salary: <span class="text-dark ms-2 font-weight-bold"><?= $jobs['salary'];?></span></span>
                            <span class="text-xs">Education: <span class="text-dark ms-2 font-weight-bold"><?= $jobs['education'];?></span></span>
                            <span class="text-xs">Training: <span class="text-dark ms-2 font-weight-bold"><?= $jobs['training'];?></span></span>
                            <span class="text-xs">Experience: <span class="text-dark ms-2 font-weight-bold"><?= $jobs['experience'];?></span></span>
                            <span class="text-xs">Eligibility: <span class="text-dark ms-2 font-weight-bold"><?= $jobs['eligibility'];?></span></span>
                            <span class="text-xs">Place of Assignment: <span class="text-dark ms-2 font-weight-bold"><?= $jobs['place_of_assignment'];?></span></span>
                          </div>
                          <div class="ms-auto">
                            <?php if($credentials['job_id']){
                                echo '<a class="btn btn-outline-success btn-sm px-3 mb-0" onclick="#"><i class="fa fa-check-alt text-dark me-2" aria-hidden="true"></i>You are currently applied in this division</a>';
                            } else if($credentials['job_id'] == 0){
                                echo '<a class="btn btn-outline-dark btn-sm px-3 mb-0" onclick="confirm()"><i class="fa fa-pencil-alt text-dark me-2" aria-hidden="true"></i>Apply for this position</a>';
                            }?>
                            
                          </div>
                    </li>
              </ul>
            </div>
          </div>
        </div>
    </div>
</div>
       
<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

<script type="text/javascript">
    function confirm(){
        $.confirm({
            title: 'Submit Application?',
            content: 'This dialog will automatically trigger \'cancel\' in 6 seconds if you don\'t respond.',
            autoClose: 'cancelAction|8000',
            buttons: {
                deleteUser: {
                    text: 'SUBMIT',
                    action: function () {
                    
                       $.ajax({
                            url: '<?php echo base_url().'jobs/submit/'.$jobs['job_id'];?>',
                            type: "POST",
                            data: {
                                $id : "<?= $jobs['job_id'];?>"
                            },
                            success: function () {
                                 $.alert('<i class="fa fa-check" aria-hidden="true"></i> Your application has been submitted');
                                 location.reload();
                            }
                        });

                      
                        
                    }
                },



                cancelAction: {
                        text:'Cancel',
                        action: function () {
                        $.alert('Your application is cancelled');
                         }
                }
            }
        });
    }
</script>