<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>


<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Submit Output</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
          <?= form_open('course/ajax_add',array('id'=>'form','role'=>"form text-left", 'class'=>"row g-3 needs-validation", 'novalidate' => ''));?>
            <div class="mb-3">
            <label for="validationCustom01" class="form-label">Course Name</label>
                
                    <input type="text" class="form-control" name="course_name" placeholder="Course Name"  id="validationCustom01" required>
                
                <div class="invalid-feedback">
                    Please provide a course name.
                </div>
            </div>
             <div class="mb-3">
            <label for="validationCustom01" class="form-label">Google Drive`s Link</label>
               
                    <input type="text" class="form-control" name="course_g_drive" placeholder="Google Drive`s Link"  id="validationCustom01" required>
                
                <div class="invalid-feedback">
                    Please provide a Google Drive`s Link.
                </div>
            </div>
             <div class="mb-3">
            <label for="validationCustom01" class="form-label">Score</label>
               
                    <input type="text" class="form-control" name="score" placeholder="Score"  id="validationCustom01" required>
           
                <div class="invalid-feedback">
                    Please provide a Score.
                </div>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit"  id="btnSave" class="btn btn-primary">Save / Upload</button>
        <?= form_close();?>
      </div>
    </div> 
  </div>
</div>


<div class="container-fluid py-4">
    <div class="row">
         <div class="col-12">
            <div class="card mb-8">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="text-uppercase text-dark text-xxs font-weight-bolder opacity-7 ">
                                 <a class="text-uppercase text-secondary text-lg font-weight-bolder opacity-100" href="javascript:;" onclick="general_ins()">GENERAL INSTRUCTIONS</a>
                            </div>
                        </div>
                        <div class="col-6 pull pull-right">
                            <div class="text-uppercase text-dark text-xxs font-weight-bolder opacity-7 ">
                                 <a class="text-uppercase btn btn-info text-lg font-weight-bolder text-dark" href="javascript:;" onclick="show_form()">SUBMIT OUTPUT</a>
                            </div>
                        </div>
                    </div>
                    <hr>
                  
                 
                    <div class="col-12 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ">
                        <span class="px-2"><a href="ld-tip" class="text-uppercase text-gradient-primary text-lg font-weight-bolder">TIP</a></span>
                        <span class="px-2"><a href="ld-ppst" class="text-uppercase text-secondary text-lg font-weight-bolder opacity-100">PPST</a></span>
                        <span class="px-2"><a href="ld-ppssh" class="text-uppercase text-secondary text-lg font-weight-bolder opacity-100">PPSSH</a></span>
                        <span class="px-2"><a href="ld-ppss" class="text-uppercase text-secondary text-lg font-weight-bolder opacity-100">PPSS</a></span>
                    </div>

                    <hr>
                    <div class="col-12 text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ">
                        <iframe src="https://drive.google.com/embeddedfolderview?id=1p3FaNVHrB9tdqATrMJlSQlYIA9VThCpQ#grid" width="100%" height="480"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
       
<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>

<?php if ($this->session->flashdata('success')) : ?>
    <script type="text/javascript">
        $.confirm({
            icon: 'fa fa-success',
            title: 'Success',
            content: 'The output has been successfully submitted',
            confirmClass: 'bg-success'
        });
    </script>
<?php endif;?>
 <script type="text/javascript">
                      
    function general_ins(){

        $.confirm({
            icon: 'fa fa-warning',
            title: 'GENERAL INSTRUCTIONS',
            content: 'Read and understand submit output at ....',
            confirmClass: 'bg-success'
        });
    }

    function show_form(){
        $('#staticBackdrop').modal('show');
       document.getElementById("form").reset()
    }

    (function () {
      'use strict'

      var forms = document.querySelectorAll('.needs-validation')

     
      Array.prototype.slice.call(forms)
        .forEach(function (form) {
          form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
            }

            form.classList.add('was-validated')
          }, false)
        })
    })()

</script>