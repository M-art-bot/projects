<script src="<?= base_url();?>assets/admin/forms/js/core/popper.min.js"></script>
<script src="<?= base_url();?>assets/admin/forms/js/core/bootstrap.min.js"></script>
<script src="<?= base_url();?>assets/admin/forms/js/plugins/smooth-scrollbar.min.js"></script>
<script src="<?= base_url();?>assets/admin/forms/js/soft-ui-dashboard.min.js?v=1.0.1"></script>
<script src="<?= base_url();?>assets/admin/forms//js/plugins/chartjs.min.js"></script>
<script src="<?= base_url();?>assets/admin/forms/js/plugins/Chart.extension.js"></script>



</body>

</html>