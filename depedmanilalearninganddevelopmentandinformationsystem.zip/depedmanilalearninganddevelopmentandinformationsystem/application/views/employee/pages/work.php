<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4">
                <div class="card-body px-0 pt-0 pb-2"> 
                    <div class="card-header pb-0 text-left bg-transparent">
                       <a class="btn btn-warning"href="javascript:window.history.go(-1);"><< BACK</a>
                        <h3 class="font-weight-bolder text-dark text-gradient">Welcome</h3>
                    </div>
                    <div class="card-body">

                        <h3 class="font-weight-bolder text-dark text-gradient">Work Experience</h3>
                        <p>Type N/A IF NOT APPLICABLE</p>


                        <?php if ($this->session->flashdata('success_work')) : ?>

                            <div class="alert alert-success d-flex align-items-center" role="alert">
                                <svg class="bi flex-shrink-0 me-2" width="24" height="24"><use xlink:href="#check-circle-fill"/></svg>
                                <div>
                                   Your work experience has been successfully updated.
                                </div>
                            </div>

                        <?php endif; ?>

                           <?php if ($this->session->flashdata('success_add_work')) : ?>

                            <div class="alert alert-success d-flex align-items-center" role="alert">
                                <svg class="bi flex-shrink-0 me-2" width="24" height="24"><use xlink:href="#check-circle-fill"/></svg>
                                <div>
                                   Your work experience has been successfully added.
                                </div>
                            </div>

                        <?php endif; ?>


                       <?php if ($this->session->flashdata('form_work')) : ?>

                       <?= form_open("Info/work_add", array('class'=>'row g-3 needs-validation', 'novalidate'=>''))?>

                        <div class="table-responsive p-0">

                            <table class="table table-stripe" id="career" style="width:100%" >
                                <thead>
                                    <tr>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th><button type="button" id="add_row" class="btn btn-default"><i class="fa fa-plus"></i></button></th>
                                    </tr>
                                </thead>

                               <tbody>
                                 <tr id="row_1">
                                   <td> 
                                   
                                            <label class="form-label">POSITION TITLE</label>
                                            <input type="text" name="position_title[]" id="position_title_1" class="form-control" autocomplete="off" required placeholder="Position title">
                                          
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Position Title
                                            </div>
                                     
                                    </td>
                                    <td>
                                            <label class="form-label">Date Started(dd/mm/yyyy)</label>
                                            <input type="text" name="date_start[]" id="date_start_1" class="form-control" placeholder="Date started"autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date started
                                            </div>
                                    
                                    </td>
                                    <td>
                                       
                                            <label class="form-label">Date Ended(dd/mm/yyyy)</label>
                                            <input type="text" name="date_end[]" id="date_end_1" class="form-control" autocomplete="off" required placeholder="Date Ended">
                                           
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date ended
                                            </div>
                                     
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">DEPARTMENT/AGENCY/OFFICE/COMPANY</label>
                                            <input type="text" name="company[]" id="company_1" class="form-control" autocomplete="off" required placeholder="Company">
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                 Please provide Company
                                            </div>
                                        
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">MONTHLY SALARY</label>
                                            <input type="text" name="monthly_salary[]" id="monthly_salary_1" placeholder="Monthly Salary" class="form-control" autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Monthly Salary
                                            </div>
                                                                    
                                       
                                    </td>

                                    <td>
                                      
                                            <label class="form-label">PAY GRADE</label>
                                            <input type="text" name="pay_grade[]" id="pay_grade_1" placeholder="PAY GRADE" class="form-control" autocomplete="off" required>
                                           
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Pay Grade
                                            </div>
                                                                    
                                       
                                    </td>

                                     <td>
                                      
                                            <label class="form-label">STATUS OF APPOINTMENT</label>
                                            <input type="text" name="status[]" id="status_1" placeholder="STATUS OF APPOINTMENT" class="form-control" autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide STATUS
                                            </div>
                                                                    
                                       
                                    </td>

                                     <td>
                                      
                                            <label class="form-label">GOV`T SERVICE(Y/N)</label>
                                            <input type="text" name="is_gov[]" id="is_gov_1" placeholder="Gov` Service?" class="form-control" autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide GOV`T SERVICE(Y/N)
                                            </div>
                                                                    
                                       
                                    </td>

                                    <td>
                                        <button type="button" class="btn btn-default" onclick="removeRow('1')"><i class="fa fa-close"></i></button>
                                    </td>
                                 </tr>
                               </tbody>

                            </table>

                        </div>

                    <?php endif; ?>

                    <?php if ($this->session->flashdata('form_work_id')) : ?>
                    <?= form_open("Info/work_update", array('class'=>'row g-3 needs-validation', 'novalidate'=>''))?>

                        <div class="table-responsive p-0">

                            <table class="table table-stripe" id="career" style="width:100%" >
                                <thead>
                                    <tr>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th><button type="button" id="add_row" class="btn btn-default"><i class="fa fa-plus"></i></button></th>
                                    </tr>
                                </thead>

                               <tbody>
                
                       
                                    <?php $x = 1; ?>
                                        <?php foreach ($order_data['order_item'] as $key => $val): ?>
                                           <tr id="row_<?= $x;?>">
                                   <td> 
                                   
                                            <label class="form-label">POSITION TITLE</label>
                                            <input type="text" value="<?= $val['position_title'];?>"name="position_title[]" id="position_title_<?= $x;?>" class="form-control" autocomplete="off" required placeholder="Position title"value="<?= $val['position_title'];?>">
            
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Position Title
                                            </div>
                                     
                                    </td>
                                    <td>
                                            <label class="form-label">Date Started(dd/mm/yyyy)</label>
                                            <input type="text" name="date_start[]" id="date_start_<?= $x;?>" class="form-control" placeholder="Date started"autocomplete="off" value="<?= $val['date_start'];?>"required> 
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date started
                                            </div>
                                    
                                    </td>
                                    <td>
                                       
                                            <label class="form-label">Date Ended(dd/mm/yyyy)</label>
                                            <input type="text" name="date_end[]" id="date_end_<?= $x;?>" class="form-control" autocomplete="off" required placeholder="Date Ended" value="<?= $val['date_end'];?>">
                                         
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date ended
                                            </div>
                                     
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">DEPARTMENT/AGENCY/OFFICE/COMPANY</label>
                                            <input type="text" name="company[]" id="company_<?= $x;?>" class="form-control" autocomplete="off" required placeholder="Company" value="<?= $val['company'];?>">
                                        
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                 Please provide Company
                                            </div>
                                        
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">MONTHLY SALARY</label>
                                            <input type="text" name="monthly_salary[]" id="monthly_salary_<?= $x;?>" placeholder="Monthly Salary" class="form-control" autocomplete="off" required value="<?= $val['monthly_salary'];?>">
                                          
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Monthly Salary
                                            </div>
                                                                    
                                       
                                    </td>

                                    <td>
                                      
                                            <label class="form-label">PAY GRADE</label>
                                            <input type="text" name="pay_grade[]" id="pay_grade_<?= $x;?>" placeholder="PAY GRADE" class="form-control" autocomplete="off" required value="<?= $val['pay_grade'];?>">
                                          
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Pay Grade
                                            </div>
                                                                    
                                       
                                    </td>

                                     <td>
                                      
                                            <label class="form-label">STATUS OF APPOINTMENT</label>
                                            <input type="text" name="status[]" id="status_<?= $x;?>" placeholder="STAUS OF APPOINTMENT" class="form-control" autocomplete="off" required value="<?= $val['status'];?>">
                                          
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide STATUS
                                            </div>
                                                                    
                                       
                                    </td>

                                     <td>
                                      
                                            <label class="form-label">GOV`T SERVICE(Y/N)</label>
                                            <input type="text" name="is_gov[]" id="is_gov_<?= $x;?>" placeholder="Gov` Service?" class="form-control" autocomplete="off" required value="<?= $val['is_gov'];?>">
                                          
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide GOV`T SERVICE(Y/N)
                                            </div>
                                                                    
                                       
                                    </td>

                                    <td>
                                        <button type="button" class="btn btn-default" onclick="removeRow('<?= $x;?>')"><i class="fa fa-close"></i></button>
                                    </td>
                                 </tr>
                                    <?php $x++; ?>
                                        <?php endforeach; ?>
                              
                                </tbody>
                            </table>

                        </div>

                    <?php endif; ?>
                        <div class="col-12">  
                            <button class="btn btn-primary" type="submit">Save</button>
                        </div>
                        <?= form_close();?>
                        <hr>
             
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>

<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>

<script type="text/javascript">
    // Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()

$("#add_row").unbind('click').bind('click', function() {
      var table = $("#career");
      var count_table_tbody_tr = $("#career tbody tr").length;
      var row_id = count_table_tbody_tr + 1;
 

               var html = '<tr id="row_'+row_id+'">'+
                    '<td><input type="text" name="position_title[]" id="position_title_'+row_id+'" class="form-control"  required placeholder="POSITION TTILE"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Position Title</div></td>'+

                     '<td><input type="text" name="date_start[]" id="date_start_'+row_id+'" class="form-control"  required placeholder="DATE STARTED"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Date Started</div></td>'+

                      '<td><input type="text" name="date_end[]" id="date_end_'+row_id+'" class="form-control"  required placeholder="DATE ENDED"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Date Ended</div></td>'+


                    '<td><input type="text" name="company[]" id=company_'+row_id+'" class="form-control"  required placeholder="Company"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Company</div>'+

                    '<td><input type="text" name="monthly_salary[]" id=monthly_salary_'+row_id+'" class="form-control"  required placeholder="Monthly Salary"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Monthly Salary</div>'+

                    '<td><input type="text" name="pay_grade[]" id=pay_grade_'+row_id+'" class="form-control"  required placeholder="Pay Grade"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Pay Grade</div>'+


                    '<td><input type="text" name="status[]" id=status_'+row_id+'" class="form-control"  required placeholder="Status"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Status</div>'+

                      '<td><input type="text" name="is_gov[]" id=is_gov_'+row_id+'" class="form-control"  required placeholder="Gov`t Service?"><div class="valid-feedback">Looks good!</div><div class="invalid-feedback">Please provide Gov`t Service</div>'+

                    '<td><button type="button" class="btn btn-default" onclick="removeRow(\''+row_id+'\')"><i class="fa fa-close"></i></button></td>'+
                    '</tr>';

                if(count_table_tbody_tr >= 1) {
                $("#career tbody tr:last").after(html);  
              }
              else {
                $("#career tbody").html(html);
              }

             

          })
   
    function removeRow(tr_id)
  {
    $("#career tbody tr#row_"+tr_id).remove();

  }

  
</script>

<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
    <symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
    </symbol>
</svg>