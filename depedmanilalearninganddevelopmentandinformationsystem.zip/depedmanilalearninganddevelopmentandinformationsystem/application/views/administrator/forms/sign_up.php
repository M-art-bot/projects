<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">



<div class="container position-sticky z-index-sticky top-0">
    <div class="row">
        <div class="col-12">
            <nav class="navbar navbar-expand-lg  blur blur-rounded top-0  z-index-3 shadow position-absolute my-3 py-2 start-0 end-0 mx-4">
                <div class="container-fluid">
                    <a class="navbar-brand font-weight-bolder ms-lg-0 ms-3 " href="<?= base_url('users-login');?>">
                        <?= $system_name;?>
                    </a>
                </div>
            </nav>
        </div>
    </div>
</div>


<section>
    <div class="page-header section-height-75">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-5 col-md-6 d-flex flex-column mx-auto">
                    <div class="card card-plain mt-8">
                        <div class="card-header pb-0 text-left bg-transparent">
                            <h3 class="font-weight-bolder text-info text-gradient">Sign up</h3>
                            <p class="mb-0">Please fill in this form to create an account.</p>
                            <p class="mb-0"><span style="color:red">*</span> is REQUIRED.</p>
                        </div>
                        <div class="card-body">
                            <?php if ($this->session->flashdata('failed')) : ?>
                                <div class="alert alert-warning d-flex align-items-center" role="alert">
                                    <svg class="bi flex-shrink-0 me-2" width="24" height="24"><use xlink:href="#exclamation-triangle-fill"/></svg>
                                    <div>
                                       Your email has already exists. Please use another email address
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?= form_open('Employers/sign_up_pro',array( 'id' => 'form', 'role'=>"form text-left", 'class'=>"row g-3 needs-validation", 'novalidate' => ''));?>
                                <div class="mb-3">
                                    <label for="validationCustom04" class="form-label">Last Name <span style="color:red">*</span></label>
                                    <input type="text" class="form-control" name="last_name" placeholder="Last Name"  id="validationCustom04" required>

                                    <div class="invalid-feedback">
                                    Please provide a last name.
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="validationCustom02" class="form-label">First Name <span style="color:red">*</span></label>
                                    <input type="text" class="form-control" name="first_name" placeholder="First Name"  id="validationCustom02" required>
                                    <div class="invalid-feedback">
                                        Please provide a first name.
                                    </div>
                                </div>
                                <div class="mb-3">
                                   <label for="validationCustom03" class="form-label">Middle Name</label>
                                    <input type="text" class="form-control" name="middle_name" placeholder="Middle Name">
                                    <div class="invalid-feedback">
                                        Please provide a middle name.
                                    </div>  
                                </div>
                                <div class="mb-3">
                                    <label for="validationCustom16" class="form-label">Position <span style="color:red">*</span></label>
                                    <select name="job_id" id="validationCustom16" class="form-control" required >
                                        <option value="">Select position</option>
                                            <?php foreach($jobs as $job): ?>
                                                <option value="<?= $job['job_id'];?>"><?= $job['position_title'];?></option>
                                            <?php endforeach; ?>
                                    </select>                             
                                    <div class="invalid-feedback">
                                        Please choose a position.
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="validationCustom06" class="form-label">Place of assignment <span style="color:red">*</span></label>
                                        <select name="school_id" id="validationCustom06" required class="form-control">
                                            <option value="">Select Place of Assignment</option>
                                                    <?php foreach($schools as $school): ?>
                                                        <option value="<?= $school['school_id'];?>"><?= $school['school_name'];?></option>
                                                    <?php endforeach; ?>
                                        </select> 
                                </div>
                                <div class="invalid-feedback">
                                    Please choose a place of assignment
                                </div>
                                <div class="mb-3">
                                <label for="validationCustom07" class="form-label">Email Address <span style="color:red">*</span></label>
                                    <input type="email" class="form-control" name="email_address" pattern=".+@deped.gov.ph"   placeholder="Email Address"  id="validationCustom07" required>
                                    <div class="invalid-feedback">
                                        Please provide deped email address.
                                    </div>
                                </div>
                                <div class="mb-3">
                                <label for="validationCustom08" class="form-label">Password <span style="color:red">*</span></label>
                                    <input type="password" class="form-control" name="password" placeholder="Password" id="validationCustom08" required="">
                                    <div class="invalid-feedback">
                                        Please choose a password.
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn bg-gradient-warning w-100 mt-4 mb-0">Sign Up</button>
                                </div>
                                 <div class="text-center">
                                    <a href="<?= base_url();?><?= md5('employers-login');?>"class="btn bg-gradient-primary w-100 mt-4 mb-0">Sign In</a>
                                </div>
                            <?= form_close();?>                
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="oblique position-absolute top-0 h-100 d-md-block d-none me-n8">
                      <div class="oblique-image bg-cover position-absolute fixed-top ms-auto h-100 z-index-0 ms-n6" style="background-image:url('<?= base_url();?>assets/admin/forms/images/curved-images/curved6.jpg')"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
    (function () {
      'use strict'

      var forms = document.querySelectorAll('.needs-validation')

     
      Array.prototype.slice.call(forms)
        .forEach(function (form) {
          form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()

            }

            form.classList.add('was-validated')
          }, false)
        })
    })()
</script>

<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
    <symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
    </symbol>
</svg>