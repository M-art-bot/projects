<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12 col-xl-12">
            <div class="card h-100">
                <div class="card-header pb-0 p-3">
                    <h6 class="mb-0"><i class="fa fa-user-circle fixed-plugin-button-nav cursor-pointer"></i> PERSONAL INFORMATIONS</h6></br>
                    <form class="form-inline">
                        <div class="row">
                            <hr>
                             <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">LAST NAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="last_name" disabled autocomplete="off" value="<?= $profile->last_name;?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    You must provide last name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom02" class="form-label">FIRST NAME</label>
                                <input type="text" class="form-control" id="validationCustom02" name="first_name" disabled autocomplete="off" value="<?= $profile->first_name;?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    You must provide first name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom03" class="form-label">MIDDLE NAME</label>
                                <input type="text" class="form-control" id="validationCustom03" name="middle_name" disabled="" value="<?= $profile->middle_name;?>"autocomplete="off">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    You must provide middle name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom04" class="form-label">NAME EXTENSION(JR, SR)</label>
                                <input type="text" class="form-control" id="validationCustom04" name="extension_name" value="<?= $profile->extension_name;?>" disabled="" autocomplete="off">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    You must provide extension name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom05" class="form-label">TELEPHONE NUMBER</label>
                                <input type="text" class="form-control" id="validationCustom05" name="telephone_no" disabled autocomplete="off" value="<?= $profile->telephone_no;?>" >
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    You must provide telephone number.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom06" class="form-label">MOBILE NUMBER</label>
                                <input type="text" class="form-control" id="validationCustom06" name="mobile_no" disabled autocomplete="off" value="<?= $profile->mobile_no;?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    You must provide mobile number.
                                </div>
                            </div>

                            <div class="col-md-8">
                                <label for="validationCustomUsername" class="form-label">Email Address</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text" id="inputGroupPrepend">@</span>
                                    <input type="email" class="form-control" value="<?= $profile->email_address;?>" id="validationCustomUsername" aria-describedby="inputGroupPrepend" name="email_address" disabled autocomplete="off">
                                    <div class="invalid-feedback">
                                        Please choose a email address.
                                    </div>
                                </div>
                            </div>



                            <div class="col-md-4">
                                <label for="validationCustom07" class="form-label">DATE OF BIRTH(dd/mm/yyyy)</label>
                                <input type="text" class="form-control" id="validationCustom07" name="date_of_birth" value="<?= $profile->date_of_birth;?>" autocomplete="off" disabled>
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide a date of birth.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom08" class="form-label">PLACE OF BIRTH</label>
                                <input type="text" class="form-control" id="validationCustom08" name="place_of_birth" value="<?= $profile->place_of_birth;?>" autocomplete="off" disabled>
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide a place of birth.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom09" class="form-label">GENDER (MALE OR FEMALE)</label>
                                <input type="text" class="form-control" id="validationCustom09" name="gender" value="<?= $profile->gender;?>" autocomplete="off" disabled>
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please choose gender.
                                </div>
                            </div>

                            <div class="col-md-12">
                                <label for="validationCustom10" class="form-label">CIVIL STATUS (SINGLE/MARRIED/WINDOWED/SEPERATED/OTHER(S))</label>
                                <input type="text" class="form-control" id="validationCustom10" name="civil_status" value="<?= $profile->civil_status;?>" autocomplete="off" disabled>
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please choose civil status.
                                </div>
                            </div>

                          

                            <div class="col-md-12">
                                <label for="validationCustom11" class="form-label">CITIZENSHIP (FILIPINO/DUAL CITIZENSHIP/ BY BIRTH / BY NATURALIZATION)</label>
                                <input type="text" class="form-control" id="validationCustom11" name="citizenship" value="<?= $profile->citizenship;?>" autocomplete="off" disabled>
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    You choose citizenship.
                                </div>
                            </div>
                            <HR>
                             <h6 class="mb-0"><i class="fa fa-user-circle fixed-plugin-button-nav cursor-pointer"></i> FAMILY BACKGROUND</h6></br>
                             <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">SPOUSE`S SURNAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="spouse_last_name" disabled autocomplete="off" value="<?= $family['spouse_last_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide spouse`s surname.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">SPOUSE`S FIRST NAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="spouse_first_name" disabled autocomplete="off" value="<?= $family['spouse_first_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide spouse`s first name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">SPOUSE`S MIDDLE NAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="spouse_middle_name" disabled autocomplete="off" value="<?= $family['spouse_middle_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide spouse`s middle name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">SPOUSE`S NAME EXTENSION(JR,SR)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="spouse_extension_name" disabled autocomplete="off" value="<?= $family['spouse_extension_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide spouse`s extension name.
                                </div>
                            </div>


                             <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">OCCUPATION</label>
                                <input type="text" class="form-control" id="validationCustom01" name="occupation" disabled autocomplete="off" value="<?= $family['occupation'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide spouse`s occupation.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">SPOUSE`S EMPLOYERS/BUSINESS NAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="company_name" disabled autocomplete="off" value="<?= $family['company_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide spouse`s business name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">SPOUSE`S BUSINESS ADDRESS</label>
                                <input type="text" class="form-control" id="validationCustom01" name="company_address" disabled autocomplete="off" value="<?= $family['company_address'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide spouse`s business address.
                                </div>
                            </div>

                             <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">SPOUSE`S TELEPHONE NO.</label>
                                <input type="text" class="form-control" id="validationCustom01" name="company_tel_no" disabled autocomplete="off" value="<?= $family['company_tel_no'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide spouse`s telephone no.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">FATHER`S SURNAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="fathers_last_name" disabled autocomplete="off" value="<?= $family['fathers_last_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide father`s surname.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">FATHER`S FIRST NAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="fathers_first_name" disabled autocomplete="off" value="<?= $family['fathers_first_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide father`s first name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">FATHER`S MIDDLE NAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="fathers_middle_name" disabled autocomplete="off" value="<?= $family['fathers_middle_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide father`s middle name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">FATHER`S NAME EXTENSION(JR,SR)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="fathers_extension_name" disabled autocomplete="off" value="<?= $family['fathers_extension_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide father`s surname.
                                </div>
                            </div>


                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">MOTHER`S SURNAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="mothers_last_name" disabled autocomplete="off" value="<?= $family['spouse_last_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide mother`s surname.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">MOTHER`S FIRST NAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="mothers_first_name" disabled autocomplete="off" value="<?= $family['mothers_first_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide mother`s first name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">MOTHER`S MIDDLE NAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="mothers_middle_name" disabled autocomplete="off" value="<?= $family['mothers_middle_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide mother`s middle name.
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">MOTHER`S MAIDEN NAME</label>
                                <input type="text" class="form-control" id="validationCustom01" name="mothers_maiden_name" disabled autocomplete="off" value="<?= $family['mothers_maiden_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide mother`s maiden name.
                                </div>
                            </div>
                            <HR>
                            <h6 class="mb-0"><i class="fa fa-school fixed-plugin-button-nav cursor-pointer"></i> EDUCATIONAL BACKGROUND</h6></br>
                            <div class="col-md-8">
                                <label for="validationCustom01" class="form-label">NAME OF SCHOOL (ELEMENTARY)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="es_name" disabled autocomplete="off" value="<?= $educ['es_name'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                   Please provide name of school (elementary).
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">YEAR GRADUATED (ELEMENTARY)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="es_year" value="<?= $educ['es_year'];?>"disabled autocomplete="" >
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                      Please provide year graduated (elementary).
                                </div>
                            </div>

                          <div class="col-md-8">
                                <label for="validationCustom01" class="form-label">NAME OF SCHOOL (SECONDARY)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="secondary_name" value="<?= $educ['secondary_name'];?>" disabled autocomplete="off">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide name of school (secondary).
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">YEAR GRADUATED (SECONDARY)</label>
                                <input type="text" class="form-control" value="<?= $educ['secondary_year'];?>" id="validationCustom01" name="secondary_year" disabled autocomplete="off" >
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                     Please provide year graduated (secondary).
                                </div>
                            </div>

                            <div class="col-md-8">
                                <label for="validationCustom01" class="form-label">NAME OF SCHOOL (VOCATIONAL)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="voc_name"   value="<?= $educ['voc_name'];?>" disabled autocomplete="off">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide name of school (vocational).
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">YEAR GRADUATED (VOCATIONAL)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="voc_year" disabled autocomplete="off" value="<?= $educ['voc_year'];?>">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                     Please provide year graduated (vocational).
                                </div>
                            </div>

                            <div class="col-md-8">
                                <label for="validationCustom01" class="form-label">NAME OF SCHOOL (COLLEGE)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="college_name"value="<?= $educ['college_name'];?>"  disabled autocomplete="off">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                     Please provide name of school (college).
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">YEAR GRADUATED (COLLEGE)</label>
                                <input type="text" class="form-control" id="validationCustom01" value="<?= $educ['college_year'];?>" name="college_year" disabled autocomplete="off" >
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide year graduated (college).
                                </div>
                            </div>

                           <div class="col-md-8">
                                <label for="validationCustom01" class="form-label">NAME OF SCHOOL (GRADUATE STUDIES)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="grad_name" value="<?= $educ['grad_name'];?>" disabled autocomplete="off">
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide name of school (greduate studies).
                                </div>
                            </div>

                            <div class="col-md-4">
                                <label for="validationCustom01" class="form-label">YEAR GRADUATED (GRADUATE STUDIES)</label>
                                <input type="text" class="form-control" id="validationCustom01" name="grad_year" value="<?= $educ['grad_year'];?>" disabled autocomplete="off" >
                                <div class="valid-feedback">
                                Looks good!
                                </div>
                                <div class="invalid-feedback">
                                    Please provide year graduated.
                                </div>
                            </div>
                            <hr>
                                <h6 class="mb-0"><i class="fa fa-user-circle fixed-plugin-button-nav cursor-pointer"></i> CIVIL SERVICE ELIGIBILITY</h6></br>
                                <hr>
                                <div class="table-responsive p-0">

                            <table class="table table-stripe" id="career" style="width:100%" >
                                <thead>
                                    <tr>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                     
                                    </tr>
                                </thead>

                               <tbody>
                
                       
                                    <?php $x = 1; ?>
                                        <?php foreach ($order_data['order_item'] as $key => $val): ?>
                                            <tr id="row_<?= $x;?>">
                                   <td>     
                                            <input type="hidden" name="civil_id_value[]" id="civil_id_value_<?= $x;?>" value="<?php echo $val['civil_id']; ?>" class="form-control" autocomplete="off" >

                                            <label class="form-label">CAREER SERVICE </label>
                                            <input type="text" name="career_service[]" id="career_service_<?= $x;?>" class="form-control" autocomplete="off" disabled placeholder="Career Service" value="<?php echo $val['civil_service']; ?>">
                                            <input type="hidden" name="career_service_value[]" id="career_service_value_<?= $x;?>" class="form-control" autocomplete="off" >
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Career Service
                                            </div>
                                     
                                    </td>
                                    <td>
                                            <label class="form-label">RATING</label>
                                            <input type="text" name="rating[]" id="rating_1" class="form-control" placeholder="Rating"autocomplete="off" value="<?php echo $val['rating']; ?>"disabled>
                                            <input type="hidden" name="rating_value[]" id="rating_value_<?= $x;?>" value="<?php echo $val['rating']; ?>"class="form-control" autocomplete="off">
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Rating
                                            </div>
                                    
                                    </td>
                                    <td>
                                       
                                            <label class="form-label">DATE OF EXAMINATION</label>
                                            <input type="text" name="date_of_examination[]" id="career_service_<?= $x;?>" class="form-control" autocomplete="off" disabled placeholder="Date of Examination" value="<?php echo $val['date_of_examination']; ?>">
                                            <input type="hidden" name="date_of_examination_value[]" value="<?php echo $val['date_of_examination']; ?>"id="career_service_value_<?= $x;?>" class="form-control" autocomplete="off">
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date of Examination
                                            </div>
                                     
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">PLACE OF EXAMINATION</label>
                                            <input type="text" name="place_of_examination[]" id="place_of_examination_<?= $x;?>" value="<?php echo $val['place_of_examination']; ?>"class="form-control" autocomplete="off" disabled placeholder="Place of Examination">
                                            <input type="hidden" name="place_of_examination_value[]" value="<?php echo $val['place_of_examination']; ?>" id="place_of_examination_value_<?= $x;?>" class="form-control" autocomplete="off">
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                 Please provide Place of Examination
                                            </div>
                                        
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">LICENSE NUMBER</label>
                                            <input type="text" name="license_number[]" id="license_number_<?= $x;?>" value="<?php echo $val['license_number']; ?>"placeholder="Number" class="form-control" autocomplete="off" disabled>
                                            <input type="hidden" name="license_number_value[]" value="<?php echo $val['license_number']; ?>"id="license_number_value_<?= $x;?>" class="form-control" autocomplete="off">
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide License number
                                            </div>
                                                                            
                                             <label class="form-label">LICENSE DATE OF VALIDITY</label>
                                            <input type="text" name="date_of_validity[]" id="career_service_<?= $x;?>" class="form-control" autocomplete="off" disabled placeholder="Date of validity." value="<?php echo $val['date_of_validity']; ?>" >
                                            <input type="hidden" alue="<?php echo $val['date_of_validity']; ?>" name="date_of_validity_value[]" id="career_service_value_<?= $x;?><?= $x;?>" class="form-control" autocomplete="off">
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide License date of validity.
                                            </div>
                                       
                                    </td>
                                   

                                    <?php $x++; ?>
                                        <?php endforeach; ?>
                              
                                </tbody>
                            </table>

                        </div>
                        <HR>
                        <h6 class="mb-0"><i class="fa fa-user-circle fixed-plugin-button-nav cursor-pointer"></i> WORK EXPERIENCE</h6></br><HR>

                        <div class="table-responsive p-0">

                            <table class="table table-stripe" id="career" style="width:100%" >
                                <thead>
                                    <tr>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      
                                    </tr>
                                </thead>

                               <tbody>
                
                       
                                    <?php $y = 1; ?>
                                        <?php foreach ($order_data_2['order_item_2'] as $key => $val_2): ?>
                                           <tr id="row_<?= $y;?>">
                                   <td> 
                                   
                                            <label class="form-label">POSITION TITLE</label>
                                            <input type="text" value="<?= $val_2['position_title'];?>"name="position_title[]" id="position_title_<?= $x;?>" class="form-control" autocomplete="off" required placeholder="Position title"value="<?= $val_2['position_title'];?>" disabled>
            
                                           
                                    </td>
                                    <td>
                                            <label class="form-label">Date Started(dd/mm/yyyy)</label>
                                            <input type="text" name="date_start[]" id="date_start_<?= $x;?>" class="form-control" placeholder="Date started"autocomplete="off" disabled value="<?= $val_2['date_start'];?>"required> 
                                            
                                         
                                    
                                    </td>
                                    <td>
                                       
                                            <label class="form-label">Date Ended(dd/mm/yyyy)</label>
                                            <input type="text" name="date_end[]" disabled id="date_end_<?= $x;?>" class="form-control" autocomplete="off" required placeholder="Date Ended"  disabledvalue="<?= $val_2['date_end'];?>">
                                         
                                            
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">DEPARTMENT/AGENCY/OFFICE/COMPANY</label>
                                            <input type="text" name="company[]" id="company_<?= $x;?>" class="form-control" autocomplete="off" required placeholder="Company" disabled value="<?= $val_2['company'];?>">
                                        
                                          
                                        
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">MONTHLY SALARY</label>
                                            <input type="text" name="monthly_salary[]" id="monthly_salary_<?= $x;?>" placeholder="Monthly Salary" class="form-control"  disabled autocomplete="off" required value="<?= $val_2['monthly_salary'];?>">
                                          
                                           
                                                                    
                                       
                                    </td>

                                    <td>
                                      
                                            <label class="form-label">PAY GRADE</label>
                                            <input type="text" name="pay_grade[]" id="pay_grade_<?= $x;?>" placeholder="PAY GRADE" class="form-control" autocomplete="off" disabled required value="<?= $val_2['pay_grade'];?>">
                                          
                                            
                                                                    
                                       
                                    </td>

                                     <td>
                                      
                                            <label class="form-label">STATUS OF APPOINTMENT</label>
                                            <input type="text" name="status[]" id="status_<?= $x;?>" placeholder="STAUS OF APPOINTMENT" class="form-control" autocomplete="off"  disabled required value="<?= $val_2['status'];?>">
                                          
                                           
                                                                    
                                       
                                    </td>

                                     <td>
                                      
                                            <label class="form-label">GOV`T SERVICE(Y/N)</label>
                                            <input type="text" name="is_gov[]" id="is_gov_<?= $x;?>" placeholder="Gov` Service?" class="form-control" autocomplete="off" disabled required value="<?= $val_2['is_gov'];?>">
                                          
                                                         
                                       
                                    </td>

                                 
                                 </tr>
                                    <?php $y++; ?>
                                        <?php endforeach; ?>
                              
                                </tbody>
                            </table>

                        </div>
                         <hr>
                        <h6 class="mb-0"><i class="fa fa-user-circle fixed-plugin-button-nav cursor-pointer"></i> Voluntary Work Or Involvement in Civic/Non Goverment/ People/ Voluntary Organization/s</h6></br><hr>
                             <div class="table-responsive p-0">

                            <table class="table table-stripe" id="career" style="width:100%" >
                                <thead>
                                    <tr>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                     
                                    </tr>
                                </thead>

                               <tbody>
                
                       
                                    <?php $Z = 1; ?>
                                        <?php foreach ($order_data_3['order_item_3'] as $key => $val_3): ?>
                                           <tr id="row_<?= $Z;?>">
                                   <td> 
                                   
                                            <label class="form-label">NAME & ADDRESS OF ORGANIZATION</label>
                                            <textarea disabled  class="form-control"><?=$val_3['voluntary_name'];?></textarea>
                                          
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide NAME & ADDRESS OF ORGANIZATION
                                            </div>
                                     
                                    </td>
                                    <td>
                                            <label class="form-label">Date Started(dd/mm/yyyy)</label>
                                            <input type="text" name="date_start[]" id="date_start_1" class="form-control" placeholder="Date started"autocomplete="off" disabled required value="<?=$val_3['date_start'];?>">
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date started
                                            </div>
                                    
                                    </td>
                                    <td>
                                       
                                            <label class="form-label">Date Ended(dd/mm/yyyy)</label>
                                            <input type="text" name="date_end[]" id="date_end_1" class="form-control" autocomplete="off" required placeholder="Date Ended" disabled  value="<?=$val_3['date_end'];?>">
                                           
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date ended
                                            </div>
                                     
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">NUMBER OF HOURS</label>
                                            <input type="text" name="number[]" id="number_1" class="form-control" autocomplete="off" required placeholder="Company" disabled value="<?=$val_3['number'];?>">
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                 Please provide NUMBER OF HOURS
                                            </div>
                                        
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">POSITION / NATURE OF WORK</label>
                                            <input type="text" name="position[]" id="position_1" placeholder="POSITION / NATURE OF WORK" class="form-control"  disabled autocomplete="off" required value="<?=$val_3['position'];?>">
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide POSITION / NATURE OF WORK
                                            </div>
                                                                    
                                       
                                    </td>   
                                 
                                 </tr>
                                    <?php $Z++; ?>
                                        <?php endforeach; ?>
                              
                                </tbody>
                            </table>

                        </div>


                            <hr>
                               <h6 class="mb-0"><i class="fa fa-user-circle fixed-plugin-button-nav cursor-pointer"></i> LEARNING AND DEVELOPMENT (L&D) INTERVENTIONS/TRAINING PROGRAMS ATTENDED</h6></br><hr>
                               <HR>

                            <div class="table-responsive p-0">

                            <table class="table table-stripe" id="career" style="width:100%" >
                                <thead>
                                    <tr>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                   
                                    </tr>
                                </thead>

                               <tbody>
                
                       
                                    <?php $aa = 1; ?>
                                        <?php foreach ($order_data_4['order_item_4'] as $key => $val_4): ?>
                                           <tr id="row_<?= $aa;?>">
                                   <td> 
                                   
                                            <label class="form-label">TITLE</label>
                                            <input type="text" name="title[]" id="title_1" class="form-control" autocomplete="off" required placeholder="NAME & ADDRESS OF ORGANIZATION" disabled value="<?php echo $val_4['title'];?>">
                                          
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide TITLE
                                            </div>
                                     
                                    </td>
                                    <td>
                                            <label class="form-label">Date Started(dd/mm/yyyy)</label>
                                            <input type="text" name="date_start[]" id="date_start_1" class="form-control" placeholder="Date started"autocomplete="off" disabled value="<?php echo $val_4['date_start'];?>"required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date started
                                            </div>
                                    
                                    </td>
                                    <td>
                                       
                                            <label class="form-label">Date Ended(dd/mm/yyyy)</label>
                                            <input type="text" name="date_end[]" id="date_end_1" value="<?php echo $val_4['date_end'];?>" class="form-control" disabled autocomplete="off" required placeholder="Date Ended">
                                           
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide Date ended
                                            </div>
                                     
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">NUMBER OF HOURS</label>
                                            <input type="text" name="number[]" id="number_1" class="form-control" value="<?php echo $val_4['number'];?>" autocomplete="off" disabled required placeholder="Company">
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                 Please provide NUMBER OF HOURS
                                            </div>
                                        
                                    </td>
                                    <td>
                                      
                                            <label class="form-label">TYPE OF LD</label>
                                            <input type="text" name="type[]" id="type_1" placeholder="TYPE OF LD" value="<?php echo $val_4['type'];?>" class="form-control" disabled autocomplete="off" required>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide TYPE OF LD
                                            </div>
                                                                    
                                       
                                    </td>  
                                    <td>
                                      
                                            <label class="form-label">CONDUCTED/SPONSORED BY</label>
                                            <input type="text" name="sponsor[]" id="sponsor_1"  value="<?php echo $val_4['sponsor'];?>"placeholder="CONDUCTED/SPONSORED BY" class="form-control" autocomplete="off" required disabled>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide CONDUCTED/SPONSORED BY
                                            </div>
                                                                    
                                       
                                    </td> 
                              
                                 </tr>
                                    <?php $aa++; ?>
                                        <?php endforeach; ?>
                              
                                </tbody>
                            </table>

                        </div>
                            


                        <div class="table-responsive p-0">

                            <table class="table table-stripe" id="career" style="width:100%" >
                                <thead>
                                    <tr>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                                      <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9"></th>
                             
                               
                                    </tr>
                                </thead>

                               <tbody>
                
                       
                                    <?php $b = 1; ?>
                                        <?php foreach ($order_data_5['order_item_5'] as $key => $val_5): ?>
                                           <tr id="row_<?= $b;?>">
                                     <td>     

                                   
                                            <label class="form-label">SPECIAL SKILL and HOBBIES</label>
                                            <input type="text" name="hobbies[]" id="hobbies_1" class="form-control" autocomplete="off" required placeholder="SPECIAL SKILL and HOBBIE" value="<?= $val_5['hobbies'];?>" disabled>
                                          
                                            <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide SPECIAL SKILL and HOBBIE
                                            </div>
                                     
                                    </td>
                                    <td>
                                            <label class="form-label">NON-ACADEMIC DISTINCTIONS / RECOGNITION</label>
                                            <input type="text" name="recognition[]" id="recorgnition_1" class="form-control" placeholder="NON-ACADEMIC DISTINCTIONS / RECOGNITION"autocomplete="off" VALUE="<?= $val_5['recognition'];?>"required disabled>
                                            
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide NON-ACADEMIC DISTINCTIONS / RECOGNITION
                                            </div>
                                    
                                    </td>
                                    <td>
                                       
                                            <label class="form-label">MEMBERSHIP IN ASSOCIATION/ORGANIZATION</label>
                                            <input type="text" name="membership[]" id="membership_1" class="form-control" autocomplete="off" required placeholder="MEMBERSHIP IN ASSOCIATION/ORGANIZATION" VALUE="<?= $val_5['membership'];?>" disabled>
                                           
                                             <div class="valid-feedback">
                                                Looks good!
                                            </div>
                                            <div class="invalid-feedback">
                                                Please provide MEMBERSHIP IN ASSOCIATION/ORGANIZATION
                                            </div>
                                     
                                    </td>
                                 
                                  
                                 </tr>
                                    <?php $b++; ?>
                                        <?php endforeach; ?>
                              
                                </tbody>
                            </table>

                        </div>


                             <h6 class="mb-0"><i class="fa fa-paperclip fixed-plugin-button-nav cursor-pointer"></i> ATTACHMENTS</h6></br><HR>


                        </div>
                        <a href="javascript:window.history.go(-1);"><< BACK</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>



<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>
