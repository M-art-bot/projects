<div class="container-fluid py-4">
    <div class="row">
          <!-- Summarize of Total Submitted Per School Per Modules-->
        
        <div class="col-3">
            <div class="card mb-4 py-4 px-4 pt-4 pb-4">
                <div class="card-body px-0 pt-0 pb-2">
                  <a href="<?= base_url();?>administrator-personnel-non-teaching">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">
                        <h2 class=""><i class="fa fa-user"></i>
                    Non Teaching Employees</p>
                    <h5 class="font-weight-bolder mb-0">
                        <?= $nonteaching; ?>
                      <span class="text-success text-sm font-weight-bolder"></span>
                    </h5>
                  </a>
              </div>
            </div>  
      </div>
<!-- teaching related dagdag dawww PUTA D na natapos -->
      <div class="col-3">
            <div class="card mb-4 py-4 px-4 pt-4 pb-4">
                <div class="card-body px-0 pt-0 pb-2">
                  <a href="<?= base_url();?>administrator-personnel-teaching">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">
                        <h2 class=""><i class="fa fa-user"></i>
                    Teaching Employees</p>
                    <h5 class="font-weight-bolder mb-0">
                        <?= $teaching; ?>
                      <span class="text-success text-sm font-weight-bolder"></span>
                    </h5>
                  </a>
              </div>
            </div>  
      </div>

        <div class="col-3">
            <div class="card mb-4 py-4 px-4 pt-4 pb-4">
                <div class="card-body px-0 pt-0 pb-2">
                  <a href="<?= base_url();?>administrator-personnel">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">
                        <h2 class=""><i class="fa fa-user"></i>
                    Registered Employees</p>
                    <h5 class="font-weight-bolder mb-0">
                        <?= $users; ?>
                      <span class="text-success text-sm font-weight-bolder"></span>
                    </h5>
                  </a>
              </div>
            </div>  
      </div>
      
    <div class="col-3">
            <div class="card mb-4 py-4 px-4 pt-4 pb-4">
                <div class="card-body px-0 pt-0 pb-2">
                  <a href="#">
                    <p class="text-sm mb-0 text-capitalize font-weight-bold">
                        <h2 class=""><i class="fa fa-user"></i>
                    Teaching Related</p>
                    <h5 class="font-weight-bolder mb-0">
                       
                      <span class="text-success text-sm font-weight-bolder"></span>
                    </h5>
                  </a>
              </div>
            </div>  
      </div>


      <div class="col-lg-12">
          <div class="card">
            <div class="card-header pb-0">
              <h6>Submitted modules per school</h6>
              <p class="text-sm">
    
  
              </p>
            </div>
            <div class="card-body p-3">
              <div class="bg-gradient-dark border-radius-lg py-3 pe-1 mb-3">
                <div class="chart">
                  <canvas id="chart-bars" class="chart-canvas" height="170px"></canvas>
                </div>
              </div>
            </div>
          </div>
        </div>

         <div class="col-lg-12">
          <div class="card">
            <div class="card-header pb-0">
              <h6>Submitted modules per module</h6>
              <p class="text-sm">
    
  
              </p>
            </div>
            <div class="card-body p-3">
              <div class="chart">
                <canvas id="chart-lines" class="chart-canvas" height="300px"></canvas>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-12">
          <div class="card">
            <div class="card-header pb-0">
              <h6>Positions</h6>
              <p class="text-sm">
    
  
              </p>
            </div>
            <div class="card-body p-3">
              <div class="chart">
                <canvas id="chart-liness" class="chart-canvas" height="300px"></canvas>
              </div>
            </div>
          </div>
        </div>


        <div class="col-lg-12">
          <div class="card">
            <div class="card-header pb-0">
              <h6>Age</h6>
              <p class="text-sm">
    
  
              </p>
            </div>
            <div class="card-body p-3">
              <div class="chart">
                <canvas id="chart-liness_age" class="chart-canvas" height="300px"></canvas>
              </div>
            </div>
          </div>
        </div>



          
    </div>
</div>


   

               
<script>
  $(function(){
        
    var cData = JSON.parse(`<?php echo $chart_data; ?>`);

     var ctx2 = document.getElementById("chart-lines").getContext("2d");

    var gradientStroke1 = ctx2.createLinearGradient(0, 230, 0, 50);

    gradientStroke1.addColorStop(1, 'rgba(203,12,159,0.2)');
    gradientStroke1.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke1.addColorStop(0, 'rgba(203,12,159,0)'); //purple colors

    var gradientStroke2 = ctx2.createLinearGradient(0, 230, 0, 50);

    gradientStroke2.addColorStop(1, 'rgba(20,23,39,0.2)');
    gradientStroke2.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke2.addColorStop(0, 'rgba(20,23,39,0)'); //purple colors


    new Chart(ctx2, {
      type: "line",
      data: {
        labels: cData.label,
        datasets: [{
            label: cData.label,
            tension: 0.4,
            borderWidth: 0,
            pointRadius: 0,
            borderColor: "#cb0c9f",
            borderWidth: 3,
            backgroundColor: gradientStroke1,
            data: cData.data,
            maxBarThickness: 6
          },
         
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        legend: {
          display: false,
        },
        tooltips: {
          enabled: true,
          mode: "index",
          intersect: false,
        },
        scales: {
          yAxes: [{
            gridLines: {
              borderDash: [2],
              borderDashOffset: [2],
              color: '#dee2e6',
              zeroLineColor: '#dee2e6',
              zeroLineWidth: 1,
              zeroLineBorderDash: [2],
              drawBorder: false,
            },
            ticks: {
              suggestedMin: 0,
              suggestedMax: 10,
              beginAtZero: true,
              padding: 10,
              fontSize: 11,
              fontColor: '#adb5bd',
              lineHeight: 3,
              fontStyle: 'normal',
              fontFamily: "Open Sans",
            },
          }, ],
          xAxes: [{
            gridLines: {
              zeroLineColor: 'rgba(0,0,0,0)',
              display: false,
            },
            ticks: {
              padding: 10,
              fontSize: 11,
              fontColor: '#adb5bd',
              lineHeight: 3,
              fontStyle: 'normal',
              fontFamily: "Open Sans",
            },
          }, ],
        },  
      },
       });

    // ----------

    var cData3 = JSON.parse(`<?php echo $chart_datassss; ?>`);

     var ctx3 = document.getElementById("chart-liness").getContext("2d");

    var gradientStroke1 = ctx3.createLinearGradient(0, 230, 0, 50);

    gradientStroke1.addColorStop(1, 'rgba(203,12,159,0.2)');
    gradientStroke1.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke1.addColorStop(0, 'rgba(203,12,159,0)'); //purple colors

    var gradientStroke2 = ctx3.createLinearGradient(0, 230, 0, 50);

    gradientStroke2.addColorStop(1, 'rgba(20,23,39,0.2)');
    gradientStroke2.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke2.addColorStop(0, 'rgba(20,23,39,0)'); //purple colors


    new Chart(ctx3, {
      type: "line",
      data: {
        labels: cData3.label,
        datasets: [{
            label: cData3.label,
            tension: 0.4,
            borderWidth: 0,
            pointRadius: 0,
            borderColor: "#cb0c9f",
            borderWidth: 3,
            backgroundColor: gradientStroke1,
            data: cData3.data,
            maxBarThickness: 6
          },
         
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        legend: {
          display: false,
        },
        tooltips: {
          enabled: true,
          mode: "index",
          intersect: false,
        },
        scales: {
          yAxes: [{
            gridLines: {
              borderDash: [2],
              borderDashOffset: [2],
              color: '#dee2e6',
              zeroLineColor: '#dee2e6',
              zeroLineWidth: 1,
              zeroLineBorderDash: [2],
              drawBorder: false,
            },
            ticks: {
              suggestedMin: 0,
              suggestedMax: 10,
              beginAtZero: true,
              padding: 10,
              fontSize: 11,
              fontColor: '#adb5bd',
              lineHeight: 3,
              fontStyle: 'normal',
              fontFamily: "Open Sans",
            },
          }, ],
          xAxes: [{
            gridLines: {
              zeroLineColor: 'rgba(0,0,0,0)',
              display: false,
            },
            ticks: {
              padding: 10,
              fontSize: 11,
              fontColor: '#adb5bd',
              lineHeight: 3,
              fontStyle: 'normal',
              fontFamily: "Open Sans",
            },
          }, ],
        },  
      },
       });

    // ----------------

    var cData4 = JSON.parse(`<?php echo $chart_data_age; ?>`);

     var ctx4 = document.getElementById("chart-liness_age").getContext("2d");

    var gradientStroke1 = ctx4.createLinearGradient(0, 230, 0, 50);

    gradientStroke1.addColorStop(1, 'rgba(203,12,159,0.2)');
    gradientStroke1.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke1.addColorStop(0, 'rgba(203,12,159,0)'); //purple colors

    var gradientStroke2 = ctx3.createLinearGradient(0, 230, 0, 50);

    gradientStroke2.addColorStop(1, 'rgba(20,23,39,0.2)');
    gradientStroke2.addColorStop(0.2, 'rgba(72,72,176,0.0)');
    gradientStroke2.addColorStop(0, 'rgba(20,23,39,0)'); //purple colors


    new Chart(ctx4, {
      type: "line",
      data: {
        labels: cData4.label,
        datasets: [{
            label: cData4.label,
            tension: 0.4,
            borderWidth: 0,
            pointRadius: 0,
            borderColor: "#cb0c9f",
            borderWidth: 3,
            backgroundColor: gradientStroke1,
            data: cData4.data,
            maxBarThickness: 6
          },
         
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        legend: {
          display: false,
        },
        tooltips: {
          enabled: true,
          mode: "index",
          intersect: false,
        },
        scales: {
          yAxes: [{
            gridLines: {
              borderDash: [2],
              borderDashOffset: [2],
              color: '#dee2e6',
              zeroLineColor: '#dee2e6',
              zeroLineWidth: 1,
              zeroLineBorderDash: [2],
              drawBorder: false,
            },
            ticks: {
              suggestedMin: 0,
              suggestedMax: 10,
              beginAtZero: true,
              padding: 10,
              fontSize: 11,
              fontColor: '#adb5bd',
              lineHeight: 3,
              fontStyle: 'normal',
              fontFamily: "Open Sans",
            },
          }, ],
          xAxes: [{
            gridLines: {
              zeroLineColor: 'rgba(0,0,0,0)',
              display: false,
            },
            ticks: {
              padding: 10,
              fontSize: 11,
              fontColor: '#adb5bd',
              lineHeight: 3,
              fontStyle: 'normal',
              fontFamily: "Open Sans",
            },
          }, ],
        },  
      },
       });


 // ---------------------------

var cData2 = JSON.parse(`<?php echo $chart_datas; ?>`);
 var ctx = document.getElementById("chart-bars").getContext("2d");

    new Chart(ctx, {
      type: "bar",
      data: {
        labels: cData2.label,
        datasets: [{
          label: cData2.label,
          tension: 0.4,
          borderWidth: 0,
          pointRadius: 0,
          backgroundColor: "#fff",
          data: cData2.data,
          maxBarThickness: 6
        }, ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        legend: {
          display: false,
        },
        tooltips: {
          enabled: true,
          mode: "index",
          intersect: false,
        },
        scales: {
          yAxes: [{
            gridLines: {
              display: false,
            },
            ticks: {
              suggestedMin: 0,
              suggestedMax: 10,
              beginAtZero: true,
              padding: 0,
              fontSize: 14,
              lineHeight: 3,
              fontColor: "#fff",
              fontStyle: 'normal',
              fontFamily: "Open Sans",
            },
          }, ],
          xAxes: [{
            gridLines: {
              display: false,
            },
            ticks: {
              display: false,
              padding: 20,
            },
          }, ],
        },
      },
    });

  });



</script>
<style type="text/css">
    .fa-user{
        color:violet;
        font-weight: bolder;    }

        .fa-search{
        color:violet;
        font-weight: bolder;    }

</style>



