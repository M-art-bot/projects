<div class="form_2 modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title modal-titles" id="staticBackdropLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <form action="#" id="form" class="form-horizontal needs-validation" novalidate>
              <label for="validationCustom04" class="form-label">Last Name <span style="color:red">*</span></label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="last_name" placeholder="Last Name"  id="validationCustom01" required>
                                    </div>
                                    <div class="invalid-feedback">
                                        Please choose a last name.
                                    </div>

                                <label for="validationCustom05" class="form-label">First Name <span style="color:red">*</span></label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="first_name" placeholder="First Name"  id="validationCustom01" required>
                                    </div>
                                    <div class="invalid-feedback">
                                        Please choose a first name.
                                    </div>

                                 <label for="validationCustom03" class="form-label">Middle Name</label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" name="middle_name" placeholder="Middle Name">
                                    </div>
                                    <div class="invalid-feedback">
                                        Please choose a middle name.
                                    </div>


                                <label for="validationCustom01" class="form-label">Email Address <span style="color:red">*</span></label>
                                    <div class="mb-3">
                                        <input type="email" class="form-control" name="email_address" placeholder="Email Address"  id="validationCustom01" required>
                                    </div>
                                    <div class="invalid-feedback">
                                        Please choose a email address.
                                    </div>

                                <label for="validationCustom02" class="form-label">Password <span style="color:red">*</span></label>
                                    <div class="mb-3">
                                        <input type="password" class="form-control" name="password" placeholder="Password" id="validationCustom02" required="">
                                    </div>
                                    <div class="invalid-feedback">
                                        Please choose a password.
                                    </div>

                                <div class="text-center">
                                    <button type="submit" class="btn bg-gradient-warning w-100 mt-4 mb-0">Sign Up</button>
                                </div>
            </div>
            <div class="modal-footer">
             
                    <div class="text-center">
                        <button type="button" id="btnSave" onclick="save()" class="btn bg-gradient-warning w-100 mt-4 mb-0">Sign Up</button>
                    </div>
            </div>
        </form>
        </div>
    </div>
</div>


<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4 py-4 px-4 pt-4 pb-4">
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <button class="btn btn-sm btn-success" onclick="add_new_job()"><i class="fa fa-plus"></i> Add New Employee</button>
                        <table id="recruitment" class="table table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9">No</th>
                                    <th class="text-uppercase text center text-secondary text-md font-weight-bolder opacity-9">Email Address</th>
                                    <th class="text-uppercase  text center text-secondary text-md font-weight-bolder opacity-9">Actions</th> <a href=""></a>                                
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>



<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>
   
<script type="text/javascript">

var save_method;
var table;

$(document).ready(function() {
table = $('#recruitment').DataTable(
        {
            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [], //Initial no order.
     
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo site_url('personnel/ajax_list_3')?>",
                "type": "POST"
            },
     
            //Set column definition initialisation properties.
            "columnDefs": [
            { 
                "targets": [ -1 ], //last column
                "orderable": false, //set not orderable
            },
            ],
           
        }
    );
});

function add_new_job()
{
    save_method = 'add';
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('.form_2').modal('show'); // show bootstrap modal
    $('.modal-title').text('Add Employee'); // Set Title to Bootstrap modal title

}

function move_to(id)
{
    save_method = 'update';
    $('#form1')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
   //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('candidates/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
 
            $('[name="applicant_id"]').val(data.applicant_id);
            $('.actions').modal('show');
            $('.modal-titles').text('Move to'); 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function rate_to(id)
{
    save_method = 'rate';
    $('#form_2')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
   //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('candidates/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
 
            $('[name="applicant_ids"]').val(data.applicant_id);
            $('.form_2').modal('show');
            $('.modal-titles').text('Activity'); 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function save()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;
 
    if(save_method == 'add') {
        url = "<?php echo base_url();?>candidates/ajax_add";

    } 

    if(save_method == 'rate') {
        url = "<?php echo base_url();?>candidates/ajax_rate";
    
    }
    else {
        url = "<?php echo base_url();?>candidates/ajax_update";
 
    }
 
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form').serialize(),
        dataType: "json",
       
        success: function(data)
        {
 
            if(data.status) //if success close modal and reload ajax table
            {
                $('.modal_add_job').modal('hide');
                reload_table();
            }
 
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            location.reload();
 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
 
        }
    });
}

function save2()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;
 

     url = "<?php echo base_url();?>candidates/ajax_rate";
    

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form_2').serialize(),
        dataType: "json",
       
        success: function(data)
        {
 
            if(data.status) //if success close modal and reload ajax table
            {
                $('.modal').modal('hide');
                reload_table();
                 location.reload();
            }
 
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            location.reload();
 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
 
        }
    });
}


function save1()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;
 
    if(save_method == 'add') {
        url = "<?php echo base_url();?>candidates/ajax_add";
   
    } else {
        url = "<?php echo base_url();?>candidates/ajax_update";
     
    }
 
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form1').serialize(),
        dataType: "json",
       
        success: function(data)
        {
 
            if(data.status) //if success close modal and reload ajax table
            {
                $('.modal').modal('hide');
                reload_table();
            }
 
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            location.reload();
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
 
        }
    });
}
function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}

</script>
<!-- Modal -->

<style type="text/css">
    .fa-star{
        color:gold;
        font-weight: bolder;    }

</style>