<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.7.1/js/buttons.print.min.js">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.7.1/css/buttons.dataTables.min.css">
<div class="container">
        <h1 style="font-size:20pt">Summary List</h1>
 
        <br />
       
        <button class="btn btn-default" onclick="reload_table()"><i class="glyphicon glyphicon-refresh"></i> Reload</button>
        <br />
        <br />
        <table id="table" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Category Name</th>
                    <th>Module Name</th>
                    <th>Module G Drive Link</th>
                    <th style="width:125px;">Total Submit</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
 
            <tfoot>
                <tr>
                    <th>Category Name</th>
                    <th>Module Name</th>
                    <th>Module G Drive Link</th>
                    <th >Total Submit</th>
                </tr>
            </tfoot>
        </table>
</div>


<script type="text/javascript">
 
var save_method; //for save method string
var table;
 
$(document).ready(function() {
 
    //datatables
    table = $('#table').DataTable({ 
   


        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.
 
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('Summary/ajax_list')?>",
            "type": "POST"
        },
 
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": [ -1 ], //last column
            "orderable": false, //set not orderable
        },
        ],


 
    });
 
});
 
 
 
 
function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}
 
</script>
 
