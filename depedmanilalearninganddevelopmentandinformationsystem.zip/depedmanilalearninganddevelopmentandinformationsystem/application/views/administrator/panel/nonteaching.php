<!-- vIEW LD -->

<div class="form_2 modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true"> -->
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title modal-titles" id="staticBackdropLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                  <form class="form-inline">
                        <div class="row">
                           <div class="col-md-4" id="titlesss">
                           </div>
                           <div class="col-md-2" id="date_start">
                           </div>
                            <div class="col-md-2" id="date_end">
                           </div>
                           <div class="col-md-1" id="number">
                           </div>
                           <div class="col-md-1" id="type">
                           </div>
                           <div class="col-md-2" id="sponsor">
                           </div>
                        </div>
                    </form>
            </div>
            <div class="modal-footer">
         
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Back</button>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card mb-4 py-4 px-4 pt-4 pb-4">
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0">
                        <table id="recruitment" class="table table-striped table-responsive">
                            <thead>
                                <tr>
                                    <th class="text-uppercase text center text-secondary text-xs font-weight-bolder opacity-9">No</th>
                                    <th class="text-uppercase text center text-secondary text-xs font-weight-bolder opacity-9">Email Address</th>
                                    <th class="text-uppercase text center text-secondary text-xs font-weight-bolder opacity-9">Position</th>
                                    <th class="text-uppercase text center text-secondary text-xs font-weight-bolder opacity-9">Place of Assignment</th>
                                    <th class="text-uppercase text center text-secondary text-xs font-weight-bolder opacity-9">Total Training/Seminars</th>
                                    <th class="text-uppercase text center text-secondary text-xs font-weight-bolder opacity-9">Profile Progress</th>

                                    <th class="text-uppercase  text center text-secondary text-xs font-weight-bolder opacity-9">Actions</th> 
                                    <th></th>               
                                </tr>
                            </thead>
                            <tbody class="text-center" >
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>

<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>
   
<script type="text/javascript">


function view_ld(id){
    $.ajax({
        url : "<?php echo site_url('Personnel/view_ld')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {       

      
            $(document).ready(function(){
                 $.each(data, function(index,value){
                    $('#titlesss').append('Title <input type="text" class="form-control" readonly value="'+value.title+'"></input><br>');
                    $('#date_start').append('Date Started <input type="text" class="form-control" readonly value="'+value.date_start+'"></input><br>');
                    $('#date_end').append('Date Ended <input type="text" class="form-control" readonly value="'+value.date_end+'"></input><br>');
                    $('#number').append('Number of hours <input type="text" class="form-control" readonly value="'+value.number+'"></input><br>');
                    $('#type').append('Type of LD<input type="text" class="form-control" readonly value="'+value.type+'"></input><br>');
                    console.log(value.title);
                    $('#sponsor').append('Conducted/Sponsored by <input type="text" class="form-control" readonly value="'+value.sponsor+'"></input><br>');
                 });
                });

 
            $('.form_2').modal('show');
            $('.modal-titles').html('<h1 class="text-gradient-primary">LEARNING AND DEVELOPMENT (L&D) INTERVENTIONS/TRAINING PROGRAMS ATTENDED </i></h1>'); 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

var save_method;
var table;

$(document).ready(function() {
table = $('#recruitment').DataTable(
        {
            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [], //Initial no order.
            "responsive": true,
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo site_url('personnel/ajax_list/2')?>",
                "type": "POST"
            },
     
            //Set column definition initialisation properties.
          "columnDefs": [
                    { responsivePriority: 1, targets: 0 },
                    { responsivePriority: 2, targets: 6 }
                ],
           
        }
    );
});

function add_new_job()
{
    save_method = 'add';
    $('#form')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('.modal_add_job').modal('show'); // show bootstrap modal
    $('.modal-title').text('Create a Candidate'); // Set Title to Bootstrap modal title

}

function move_to(id)
{
    save_method = 'update';
    $('#form1')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
   //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('candidates/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
 
            $('[name="applicant_id"]').val(data.applicant_id);
            $('.actions').modal('show');
            $('.modal-titles').text('Move to'); 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function rate_to(id)
{
    save_method = 'rate';
    $('#form_2')[0].reset(); // reset form on modals
    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
   //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('candidates/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
            

            $('[name="applicant_id"]').val(data.applicant_id);
            $('.form_2').modal('show');
            $('.modal-titles').text('Activity'); 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}

function save()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;
 
    if(save_method == 'add') {
        url = "<?php echo base_url();?>candidates/ajax_add";

    } 

    if(save_method == 'rate') {
        url = "<?php echo base_url();?>candidates/ajax_rate";
    
    }
    else {
        url = "<?php echo base_url();?>candidates/ajax_update";
 
    }
 
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form').serialize(),
        dataType: "json",
       
        success: function(data)
        {
 
            if(data.status) //if success close modal and reload ajax table
            {
                $('.modal_add_job').modal('hide');
                reload_table();
            }
 
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            location.reload();
 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
 
        }
    });
}

function save2()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;
 

     url = "<?php echo base_url();?>candidates/ajax_rate";
    

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form_2').serialize(),
        dataType: "json",
       
        success: function(data)
        {
 
            if(data.status) //if success close modal and reload ajax table
            {
                $('.modal').modal('hide');
                reload_table();
                 location.reload();
            }
 
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            location.reload();
 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
 
        }
    });
}


function save1()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;
 
    if(save_method == 'add') {
        url = "<?php echo base_url();?>candidates/ajax_add";
   
    } else {
        url = "<?php echo base_url();?>candidates/ajax_update";
     
    }
 
    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form1').serialize(),
        dataType: "json",
       
        success: function(data)
        {
 
            if(data.status) //if success close modal and reload ajax table
            {
                $('.modal').modal('hide');
                reload_table();
            }
 
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            location.reload();
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
 
        }
    });
}
function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}

</script>
<!-- Modal -->

<style type="text/css">
    .fa-star{
        color:gold;
        font-weight: bolder;    }

</style>