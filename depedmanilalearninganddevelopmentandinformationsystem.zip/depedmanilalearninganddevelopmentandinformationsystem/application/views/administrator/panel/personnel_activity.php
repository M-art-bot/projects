<div class="container-fluid py-4">
    <div class="row">
         <div class="col-12">
            <div class="card mb-12">
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0 py-4 px-4">
                         <table class="table align-items-center mb-0" id="recruitment">
                          <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No.</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Module Submitted Name</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Category Name</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Module Score</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Actitity Date and Time </th>              
                            </tr>
                          </thead>
                          <tbody>
                 
                          </tbody>
                        </table>
              </div>
                </div>
            </div>
        </div>
    </div>
</div>
       
<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>

<script type="text/javascript">
    $(document).ready(function() {
table = $('#recruitment').DataTable(
        {
            "processing": true, //Feature control the processing indicator.
            "serverSide": true, //Feature control DataTables' server-side processing mode.
            "order": [], //Initial no order.
     
            // Load data for the table's content from an Ajax source
            "ajax": {
                "url": "<?php echo base_url().'ActivityLog/ajax_list/'.$applicant_id?>",
                "type": "POST"
            },
     
            //Set column definition initialisation properties.
            "columnDefs": [
            { 
                "targets": [ -1 ], //last column
                "orderable": false, //set not orderable
            },
            ],
           
        }
    );
});
</script>
