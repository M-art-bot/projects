<div class="form_2 modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title modal-titles" id="staticBackdropLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               <form action="#" id="form_2" class="form-horizontal">
                    <div class="form-body">
                       <div class="mb-3">
                        <label for="validationCustom01" class="form-label">Input score</label>
                           <input type="hidden" name="activity_id" id="activity_id">
                                <input type="text" class="form-control" name="score" placeholder="Score"  id="validationCustom01" required>
                       
                            <div class="invalid-feedback">
                                Please provide a Score.
                            </div>
                        </div> 
                    </div>
          
             </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="btnSave" onclick="save2()" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>


<div class="container-fluid py-4">
    <div class="row">
         <div class="col-12">
            <div class="card mb-12">
                <div class="card-body px-0 pt-0 pb-2">
                    <div class="table-responsive p-0 py-4 px-4">
                         <table class="table align-items-center mb-0" id="recruitment">
        <h1 style="font-size:20pt">Actvities</h1>
 
        <br />
       
        <button class="btn btn-default" onclick="reload_table()"><i class="glyphicon glyphicon-refresh"></i> Reload</button>
        <br />
        <br />
        <table id="table" class="table table-striped table-bordered table-responsive" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Position</th>
                    <th>School</th>
                    <th>Category</th>
                    <th>Module</th>
                    <th>Module G Drive Link</th>
                    <th>Score</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
 
         </table>
              </div>
                </div>
            </div>
        </div>
    </div>
</div>
       
<footer class="footer pt-3">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
                <div class="copyright text-center text-sm text-bold text-muted text-lg-left">
                    
                    <script>
                        document.write(new Date().getFullYear())
                    </script>-  

                    <script>
                        document.write(new Date().getFullYear())
                    </script>    
                </div>
            </div>    
        </div>
    </div>
</footer>


<script type="text/javascript">
 
var save_method; //for save method string
var table;
 
$(document).ready(function() {
 
    //datatables
    table = $('#table').DataTable({ 
   


        "processing": true, //Feature control the processing indicator.
        "serverSide": true, //Feature control DataTables' server-side processing mode.
        "order": [], //Initial no order.
    "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>PLEASE WAIT..<span class="sr-only"></span> '},
        // Load data for the table's content from an Ajax source
        "ajax": {
            "url": "<?php echo site_url('Activities/ajax_list')?>",
            "type": "POST"
        },
 
        //Set column definition initialisation properties.
        "columnDefs": [
        { 
            "targets": [ -1 ], //last column
            "orderable": false, //set not orderable
        },
        ],


 
    });
 
});
 
 
 function rate_to(id)
{
    save_method = 'rate';

    $('.form-group').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
   //Ajax Load data from ajax
    $.ajax({
        url : "<?php echo site_url('activities/ajax_edit')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {
 
            $('[name="activity_id"]').val(data.activity_id);
            $('.form_2').modal('show');
            $('.modal-titles').text('Activity'); 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}


 
function reload_table()
{
    table.ajax.reload(null,false); //reload datatable ajax 
}
 
function save2()
{
    $('#btnSave').text('saving...'); //change button text
    $('#btnSave').attr('disabled',true); //set button disable 
    var url;
 

     url = "<?php echo base_url();?>activities/ajax_update";
    

    // ajax adding data to database
    $.ajax({
        url : url,
        type: "POST",
        data: $('#form_2').serialize(),
        dataType: "json",
       
        success: function(data)
        {
 
            if(data.status) //if success close modal and reload ajax table
            {
                $('.modal').modal('hide');
                reload_table();
                
            }
 
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
            window.href("javascript:window.history.go(-2);");
 
 
        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error adding / update data');
            $('#btnSave').text('save'); //change button text
            $('#btnSave').attr('disabled',false); //set button enable 
 
        }
    });
}

</script>
 
