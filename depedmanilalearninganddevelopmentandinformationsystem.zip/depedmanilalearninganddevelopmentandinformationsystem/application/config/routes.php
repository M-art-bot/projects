<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] 		= 'Employers'; 





















//Employers

$route[md5('employers-login')]		= 'Employers';

$route[md5('employers-registration')] 	= 'Employers/sign_up';

$route[md5('employers-profile')]									= 'Employers/profile';


$route[md5('employers-family')]									= 'Employers/family';
$route[md5('employers-education')]								= 'Employers/education';
$route[md5('employers-civil')]									= 'Employers/civil';
$route[md5('employers-work')]									= 'Employers/work';
$route[md5('employers-ld')]										= 'Employers/ld';
$route[md5('employers-others')]									= 'Employers/others';
$route[md5('employers-voluntary')]								= 'Employers/voluntary';

$route[md5('ld-tip')]											= 'Employers/vacancy';
$route[md5('ld-ppst')]											= 'Employers/ppst';
$route[md5('ld-ppssh')]											= 'Employers/ppssh';
$route[md5('ld-ppss')]											= 'Employers/ppss';

$route[md5('ld-activity')]										= 'Applications/index';
$route['administrator-candidates-activity/(:any)']			= 'Applications/employee/$1';
$route['candidates-view/(:any)']							= 'Applications/activity/$1';


$route['users-logout']				= 'Users/logout';

$route[md5('employers-logout')] = 'Authentication/userslogout';

// Administrator Dashboard
$route['administrator-summary-activities']		= 'Modules/activity';



// Administrator Dashboard
$route['administrator-summary']		= 'Modules/summary';

// Administrator Dashboard
$route['administrator-dashboard']		= 'Dashboard/index';

// Administrator Add Employee
$route['administrator-add-employee']		= 'Personnel/addemployee';

// Administrator Add Modules
$route['administrator-add-modules']			= 'Modules/index';

// Administrator Add Modules
$route['administrator-add-positions']		= 'Positions/index';

// Administrator Candidates
$route['administrator-candidates/(:any)']		= 'Candidates/index/$1';

// Administrator Candidates
$route['administrator-candidates-basic-information/(:any)']		= 'Basic_information/index/$1';

// Administrator Candidates Enlist
$route['administrator-enlists-candidates/(:any)/(:any)']	= 'Enlists/index/$1/$2';

// Administrator Personnel
$route['administrator-personnel']		=	'Personnel/index';

$route['administrator-personnel-teaching']		=	'Personnel/teaching';
$route['administrator-personnel-non-teaching']		=	'Personnel/nonteaching';

$route['administrator-login']			= 'Administrator/index';



$route['404_override'] 				= '';

$route['translate_uri_dashes'] 		= FALSE;

