<?php 
	
	class Personnel extends CI_Controller
	{


		public function index($id = null){

			if($this->session->userdata['logged_in']['userid'])

			{

				$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
				$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

					$data['page']			=	"Personnel";

					$user_id				= 	$this->session->userdata['logged_in']['userid'];
												
					$data['credentials']	=	$this->Dashboard_model->get($user_id);

					$email_address = $this->Personnel_model->getEmail();

    				$data['email_address'] = $email_address;
			
					$this->load->view('administrator/panel/templates/header', $data);
					$this->load->view('administrator/panel/templates/aside', $data);
					$this->load->view('administrator/panel/templates/navbar', $data);
					$this->load->view('administrator/panel/personnel', $data);
					$this->load->view('administrator/panel/templates/subfooter', $data);
					$this->load->view('administrator/panel/templates/footer', $data);

			}

				else{
					redirect('administrator-login');
				}
		}

		 public function employeeList(){

		    $postData = $this->input->post();

		    $data = $this->Personnel_model->getEmployees($postData);

		    echo json_encode($data);
  		}


	}
?>
