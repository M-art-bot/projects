<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ActivityLog extends CI_Controller {


	public function ajax_list($id = null)
    {
	        $list = $this->Applications_model->get_datatables($id);
	        $data = array();
			$no = 1;

          foreach ($list as $job) {
             	
	            $row 	= array();
	            $row[]	= $no++;
	            $row[] 	= '<p class="text-xs font-weight-bold mb-0"><a class="text-secondary text-xs font-weight-bold" target="_blank" href="'.$job->activity_g_drive.'">'.$job->module_name.'</a></p>';
	            $row[] 	= '<p class="text-xs font-weight-bold mb-0">'.$job->category_name.'</p>';
                $row[] 	= '<p class="text-xs font-weight-bold mb-0">'.$job->activity_score.'</p>';
	            $row[] 	= '<p class="text-xs font-weight-bold mb-0">'.$job->timestamp.'</p>';
              
	         
	            $data[] = $row;
	        }
	 
	        $output = array(
	                        "draw" => $_POST['draw'],
	                        "recordsTotal" => $this->Applications_model->count_all($id),
	                        "recordsFiltered" => $this->Applications_model->count_filtered($id),
	                        "data" => $data,
	                );
	        //output to json format
	        echo json_encode($output);
    }


}
