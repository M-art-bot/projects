<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Administrator extends CI_Controller {
	
	public function index()
	{	
		
		$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= '<img src="'.base_url().'assets/admin/images/icon.png" width="40px">'.' DepEd Manila Personnel e-Learning and Information System';

		$this->load->view('administrator/forms/templates/header', $data);
		$this->load->view('administrator/forms/login', $data);
		$this->load->view('administrator/forms/templates/footer', $data);
	}
}
