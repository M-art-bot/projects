<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Employers extends CI_Controller {
	
	public function index()
	{	
		
		$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= '<img src="'.base_url().'assets/admin/images/icon.png" width="40px">'.' DepEd Manila Learning and Development and Information System';

		$this->load->view('administrator/forms/templates/header', $data);
		$this->load->view('administrator/forms/login_2', $data);
		$this->load->view('administrator/forms/templates/footer', $data);
	}

	public function login(){
		$data = array(
							'email_address' => $this->input->post('email_address'),
							'password' 		=> md5($this->input->post('password'))
					);


		$result =$this->Jobs_model->login($data);

		if ($result == TRUE) {

				$email_address = $this->input->post('email_address');
				$result = $this->Jobs_model->read_user_information($email_address);

				if ($result != false) {
					$session_data = array(
					'email_address' => $result[0]->email_address,
					'applicant_id'   => $result[0]->applicant_id
					);
					// Add user data in session
					$this->session->set_userdata('logged_in_user', $session_data);
					redirect(md5('employers-profile'));
				}
		}
		else{	
				$this->session->set_flashdata('failed', 'The password you’ve entered is incorrect.');
				redirect(md5('employers-login'));
		}
	}


	public function sign_up()
	{	
		

		$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= '<img src="'.base_url().'assets/admin/images/icon.png" width="40px">'.' DepEd Manila Personnel e-Learning and Information System';
		

		$data['jobs'] = $this->Jobs_model->get();
		$data['schools'] = $this->Jobs_model->get_schools();

		$this->load->view('administrator/forms/templates/header', $data);
		$this->load->view('administrator/forms/sign_up', $data);
		$this->load->view('administrator/forms/templates/footer', $data);
	}

	public function sign_up_pro(){
		$data = array(		
							'last_name' => strtoupper($this->input->post('last_name')),
							'first_name' =>  strtoupper($this->input->post('first_name')),
							'middle_name' =>  strtoupper($this->input->post('middle_name')),
							'email_address' =>  strtolower($this->input->post('email_address')),
							'password' 		=> md5($this->input->post('password')),
							'job_id' 		=> $this->input->post('job_id'),
							'school_id' 		=> $this->input->post('school_id')
					);


		$validated			=		$this->Users_model->validate_email($data);

		if($validated){

				$successfull 	= 		$this->Users_model->register($data);
				$this->session->set_flashdata('success', 'Your account has been activated successfully. You can now login.');
		      redirect(md5('employers-login'));

		}
		else{
				$this->session->set_flashdata('failed', 'Error adding data.');
		      	redirect(md5('employers-registration'));
		}

				$this->session->set_flashdata('failed', 'Your email has already exists. Please use another email address');
		      	redirect(md5('employers-registration'));
	}

	public function profile(){
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
		$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

			$data['page']			=	"Profile";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);
			
			
			$data['res']	=	$this->Jobs_model->get_resident_address($applicant_id);

			if($data['res']){
				$this->session->set_flashdata('form_res_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_res', 'aww');
			}

			$data['per']	=	$this->Jobs_model->get_permanent_address($applicant_id);

			if($data['per']){
				$this->session->set_flashdata('form_per_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_per', 'aww');
			}

			$data['other']	=	$this->Jobs_model->get_personal_informations($applicant_id);
			
			if($data['other']){
				$this->session->set_flashdata('form_personal_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_personal', 'aww');
			}
			
			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/dashboard', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}
	}

	public function family(){
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
		$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

			$data['page']			=	"Profile";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);


			$data['family']	=	$this->Jobs_model->get_family($applicant_id);

			if($data['family']){
				$this->session->set_flashdata('form_fam_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_fam', 'aww');
			}


			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/family_background', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}
	}


	public function education(){
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

			$data['page']			=	"Profile";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);


			$data['highest']	=	$this->Jobs_model->get_highest($applicant_id);

			$result = array();

			foreach($data['highest'] as $k => $v) {
    			$result['order_item'][] = $v;
    		}

    		$data['order_data'] = $result;

    	

			if($data['highest']){
				$this->session->set_flashdata('form_highest_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_highest', 'aww');
			}



			$data['educ']	=	$this->Jobs_model->get_educ($applicant_id);

			if($data['educ']){
				$this->session->set_flashdata('form_educ_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_educ', 'aww');
			}


			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/education', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}
	}

	public function civil(){
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
	
			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

			$data['page']			=	"Profile";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);


			$data['civil']	=	$this->Jobs_model->get_civil($applicant_id);

			$result = array();

			foreach($data['civil'] as $k => $v) {
    			$result['order_item'][] = $v;
    		}

    		$data['order_data'] = $result;

    	

			if($data['civil']){
				$this->session->set_flashdata('form_civil_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_civil', 'aww');
			}


			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/civil', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}
	}

	public function work(){
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
		
			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

			$data['page']			=	"Profile";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);


			$data['work']	=	$this->Jobs_model->get_work($applicant_id);

			$result = array();

			foreach($data['work'] as $k => $v) {
    			$result['order_item'][] = $v;
    		}

    		$data['order_data'] = $result;

    	

			if($data['work']){
				$this->session->set_flashdata('form_work_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_work', 'aww');
			}


			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/work', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}
	}

	public function voluntary(){
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
		
			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';
			$data['page']			=	"Profile";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);


			$data['voluntary']	=	$this->Jobs_model->get_voluntary($applicant_id);

			$result = array();

			foreach($data['voluntary'] as $k => $v) {
    			$result['order_item'][] = $v;
    		}

    		$data['order_data'] = $result;

    	

			if($data['voluntary']){
				$this->session->set_flashdata('form_voluntary_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_voluntary', 'aww');
			}


			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/voluntary', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}
	}

	public function ld(){
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
		
			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

			$data['page']			=	"Profile";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);


			$data['ld']	=	$this->Jobs_model->get_ld($applicant_id);

			$result = array();

			foreach($data['ld'] as $k => $v) {
    			$result['order_item'][] = $v;
    		}

    		$data['order_data'] = $result;

    	

			if($data['ld']){
				$this->session->set_flashdata('form_ld_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_ld', 'aww');
			}


			$this->load->view('vacancy/header', $data);
			// $this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/ld', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}
	}

	public function others(){
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
			
			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';
			$data['page']			=	"Profile";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);


			$data['others']	=	$this->Jobs_model->get_others($applicant_id);

			$result = array();

			foreach($data['others'] as $k => $v) {
    			$result['order_item'][] = $v;
    		}

    		$data['order_data'] = $result;

    	

			if($data['others']){
				$this->session->set_flashdata('form_others_id', 'yehey');
			}
			else{
				$this->session->set_flashdata('form_others', 'aww');
			}


			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/others', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

		redirect(md5('employers-login'));
		
		}
	}

	public function vacancy(){
		
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
		
			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

			$data['page']			=	"Learning and Development";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);
    		$data['modules']		= 	$this->Module_model->get();

			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/vacancy', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}

	}

	public function ppst(){
		
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
	
			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

			$data['page']			=	"Learning and Development";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);
    			$data['modules']		= 	$this->Module_model->get_2();

			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/ppst', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}

	}

	public function ppssh(){
		
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
		
			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';

			$data['page']			=	"Learning and Development";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
			$data['modules']		= 	$this->Module_model->get_3();					
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);
    	

			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/ppssh', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}

	}

	public function ppss(){
		
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{	

			$data['modules']		= 	$this->Module_model->get_4();

			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';
			$data['page']			=	"Learning and Development";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);
    	

			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/ppss', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect(md5('employers-login'));
		
		}

	}

}
