<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Applications extends CI_Controller {


	public function index(){
		
		if($this->session->userdata['logged_in_user']['applicant_id'])

		{
			$data['title']			= 	$this->session->userdata['logged_in_user']['email_address'].' | DepEd Manila Personnel';
		$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';
		
			$data['page']			=	"Activity Logs";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);
    	

			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/applications', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect('users-login');
		
		}

	}

	public function employee($id = null){

			if($this->session->userdata['logged_in']['userid'])

			{

					$data['title']			= 	"Administrator | Personnel";
					$data['system_name']	=	"HRIS";
					$data['page']			=	"On Board";

					$user_id				= 	$this->session->userdata['logged_in']['userid'];
												
					$data['credentials']	=	$this->Dashboard_model->get($user_id);

					$data['applicant_id']	=	$id;
					
			
					$this->load->view('administrator/panel/templates/header', $data);
					$this->load->view('administrator/panel/templates/aside', $data);
					$this->load->view('administrator/panel/templates/navbar', $data);
					$this->load->view('administrator/panel/personnel_activity', $data);
					$this->load->view('administrator/panel/templates/subfooter', $data);
					$this->load->view('administrator/panel/templates/footer', $data);

			}

				else{
					redirect('administrator-login');
				}
		}


	public function ajax_list($id = null)
    {		
	        $list = $this->Applications_model->get_datatables($id);
	        $data = array();
			$no = 1;

	        foreach ($list as $job) {
             	
	            $row 	= array();
	            $row[]	= $no++;
	            $row[] 	= '<p class="text-xs font-weight-bold mb-0"><a class="text-secondary text-xs font-weight-bold" target="_blank" href="'.$job->activity_g_drive.'">'.$job->module_name.'</a></p>';
	            $row[] 	= '<p class="text-xs font-weight-bold mb-0">'.$job->category_name.'</p>';
                $row[] 	= '<p class="text-xs font-weight-bold mb-0">'.$job->activity_score.'</p>';
	            $row[] 	= '<p class="text-xs font-weight-bold mb-0">'.$job->timestamp.'</p>';
              
	         
	            $data[] = $row;
	        }
	 
	        $output = array(
	                        "draw" => $_POST['draw'],
	                        "recordsTotal" => $this->Applications_model->count_all(),
	                        "recordsFiltered" => $this->Applications_model->count_filtered(),
	                        "data" => $data,
	                );
	        //output to json format
	        echo json_encode($output);
    }

    public function ajax_list_2()
    {
	        $list = $this->View_model->get_datatables();
	        $data = array();
			$no = $_POST['start'];

	        foreach ($list as $job) {
             	$no++;
	            $row 	= array();
          	  	$row[] 	= '<p class="text-xs font-weight-bold mb-0">'.$job->position_title.'</p>';
	            $row[] 	= '<p class="text-xs font-weight-bold mb-0">'.$job->place_of_assignment.'</p>';

              	$star = ['<span class="fa fa-star"></span>','<span class="fa fa-star"></span>','<span class="fa fa-star"></span>','<span class="fa fa-star"></span>','<span class="fa fa-star"></span>','<span class="fa fa-star"></span>'];

	            $hehe = '';

	          	for ($x = 0; $x < $job->rate_standing; $x++) {
	          		
  					$hehe .=  $star[$x];
				}

				$row[] = $hehe;
				
	         	$row[] = $job->activity;
	         	$row[] = $job->action_type;
	 			$row[] = $job->activity_created_timestamp;
	            $data[] = $row;
	        }
	 
	        $output = array(
	                        "draw" => $_POST['draw'],
	                        "recordsTotal" => $this->View_model->count_all(),
	                        "recordsFiltered" => $this->View_model->count_filtered(),
	                        "data" => $data,
	                );
	        //output to json format
	        echo json_encode($output);
    }
    public function activity($id = null){

    	if($this->session->userdata['logged_in_user']['applicant_id'])

		{
			$data['title']			= 	$this->session->userdata['logged_in_user']['email_address'].' | HRIS';
			$data['system_name']	=	"HRIS";
			$data['page']			=	"Activity";

			$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];
										
			$data['credentials']	=	$this->Jobs_model->gets($applicant_id);
    	

			$this->load->view('vacancy/header', $data);
			$this->load->view('vacancy/aside', $data);
			$this->load->view('vacancy/navbar', $data);
			$this->load->view('vacancy/activity', $data);
			$this->load->view('vacancy/subfooter', $data);
			$this->load->view('vacancy/footer', $data);
		}

		else{

			redirect('users-login');
		
		}

    }

    



}
