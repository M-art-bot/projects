<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	
	public function index()
	{	
	  	$this->load->database();

		if($this->session->userdata['logged_in']['userid'])

		{	



			$query = $this->db->select('*, count("activities.module_id") as count')->from('schools')->join('applicants','applicants.school_id=schools.school_id')->join('activities','applicants.applicant_id=activities.applicant_id')->group_by('applicants.school_id')->get();
		 
		      $record = $query->result();
		      $data = [];
		 
		      foreach($record as $row) {
		            $data['label'][] = $row->school_name;
		            $data['data'][] = (int) $row->count;
		      }
		     $data['chart_datas'] = json_encode($data);
// ------------------------------

		     $query2 = $this->db->select('*, count("activities.module_id") as count')->from('modules')->join('activities','activities.module_id=modules.module_id')->group_by('activities.module_id')->get();
		 
		      $record2 = $query2->result();
		      $data2 = [];
		 
		      foreach($record2 as $row) {
		            $data2['label'][] = $row->module_name;
		            $data2['data'][] = (int) $row->count;
		      }
		     $data['chart_data'] = json_encode($data2);

			$query3 = $this->db->select('*, count("job_categories.job_category_id") as count')->from('jobs')->join('job_categories','job_categories.job_category_id=jobs.job_id')->join('applicants','applicants.job_id=jobs.job_id')->group_by('job_categories.job_category_id')->get();
		 
	      	$record3 = $query3->result();
	      	$data3 = [];
		 
		      foreach($record3 as $row) {
		            $data3['label'][] = $row->position_title;
		            $data3['data'][] = (int) $row->count;
	      	}

		     $data['chart_datassss'] = json_encode($data3);


		   	$query4 = $this->db->select('*, count("age.age_id") as count')->from('age')->join('applicants','applicants.age=age.age_id')->group_by('age.age_id')->get();
		 
	      	$record4 = $query4->result();
	      	$data4 = [];
		 
		    foreach($record4 as $row) {
		            $data4['label'][] = $row->age_name;
		            $data4['data'][] = (int) $row->count;
	      	}
	      	
		     $data['chart_data_age'] = json_encode($data4);


			$data['title'] 			= 'DepEd Manila Personnel e-Learning and Information System';
			$data['system_name'] 	= ' DepEd Manila Personnel <br>e-Learning and Information System';
				$data['page']			=	"Dashboard";

			$user_id				= 	$this->session->userdata['logged_in']['userid'];
										
			$data['credentials']	=	$this->Dashboard_model->get($user_id);

			$data['users']		= 	$this->Dashboard_model->count_users();

			$data['teaching']		= 	$this->Dashboard_model->count_teaching();

			$data['nonteaching']		= 	$this->Dashboard_model->count_non_teaching();

			$data['position']		= 	$this->Dashboard_model->position();
			
			// summarise report of submitted module per school
			$data['submmitted']		= $this->Dashboard_model->submitted();
			$this->load->view('administrator/panel/templates/header', $data);
			$this->load->view('administrator/panel/templates/aside', $data);

			$this->load->view('administrator/panel/templates/navbar', $data);
						$this->load->view('administrator/panel/dashboard', $data);
			$this->load->view('administrator/panel/templates/subfooter', $data);
			$this->load->view('administrator/panel/templates/footer', $data);
		}

		else{

			redirect('administrator-login');
		
		}
	}
}
