<?php 
	
	class Basic_information extends CI_Controller
	{


		public function index($id = null, $offset=null){

			if($this->session->userdata['logged_in']['userid'])

			{
				if($id)
				{
					$data['title']			= 	"Administrator | Recruitment";
					$data['system_name']	=	"HRIS";
					$data['page']			=	"Candidates Basic Information";

					$user_id				= 	$this->session->userdata['logged_in']['userid'];
												
					$data['credentials']	=	$this->Dashboard_model->get($user_id);
					
					// Get information of applicant
					$data['profile']		= 	$this->Candidates_model->get_by_id($id);
					$data['family']	=	$this->Jobs_model->get_family($id);
					if(empty($data['family'])){
						$data['family'] = array('spouse_last_name' => '',
												'spouse_first_name' => '',
												'spouse_middle_name' => '',
												'spouse_extension_name' => '',
												'occupation' => '',
												'company_name' => '',
												'company_address' => '',
												'company_tel_no' => '',
												'fathers_last_name' => '',
												'fathers_first_name' => '',
												'fathers_middle_name' => '',
												'fathers_extension_name' => '',
												'mothers_last_name' => '',
												'mothers_first_name' => '',
												'mothers_middle_name' => '',
												'mothers_extension_name' => '',
												'mothers_maiden_name' => '',

											);
					}
					$data['educ']	=	$this->Jobs_model->get_educ($id);
					if(empty($data['educ'])){
						$data['educ'] = array('es_name' => '',
											  'es_year' => '',
											  'secondary_name' => '',
											  'secondary_year' => '',
											  'voc_name' => '',
											  'voc_year' => '',
											  'college_name' => '',
											  'college_year' => '',
											  'grad_name' => '',
											  'grad_year' => '',

											);
					}
					$data['civil']	=	$this->Jobs_model->get_civil($id);

					$result = array();

					if(empty($data['civil'])){
						$result['order_item'][] = array(
															'civil_id' =>'',
															'rating' =>'',
															'civil_service' =>'',
															'date_of_examination' =>'',
															'place_of_examination' =>'',
															'license_number' =>'',
															'date_of_validity' =>'',
														);
					}


					foreach($data['civil'] as $k => $v) {
		    			$result['order_item'][] = $v;
		    		}

		    		$data['order_data'] = $result;

		    		
		    		$data['work']	=	$this->Jobs_model->get_work($id);



					$result_2 = array();

					if(empty($data['work'])){
						$result_2['order_item_2'][] = array(
															'position_title' =>'',
															'date_start' =>'',
															'date_end' =>'',
															'company' =>'',
															'monthly_salary' =>'',
															'pay_grade' =>'',
															'status' =>'',
															'is_gov' =>'',
												

														);
					}


					foreach($data['work'] as $k => $v_2) {
		    			$result_2['order_item_2'][] = $v_2;
		    		}

    				$data['order_data_2'] = $result_2;



					$data['voluntary']	=	$this->Jobs_model->get_voluntary($id);

					$result_3 = array();

					if(empty($data['voluntary'])){
						$result_3['order_item_3'][] = array(
															'voluntary_name' =>'',
															'date_start' =>'',
															'date_end' =>'',
															'type' =>'',
															'number' =>'',
															'position' =>'',
														
												

														);
					}



					foreach($data['voluntary'] as $k => $v) {
		    			$result_3['order_item_3'][] = $v;
		    		}

		    		$data['order_data_3'] = $result_3;

		    		$data['ld']	=	$this->Jobs_model->get_ld($id);

					$result_4 = array();

					if(empty($data['voluntary'])){
						$result_4['order_item_4'][] = array(
															'title' =>'',
															'date_start' =>'',
															'date_end' =>'',
															'type' =>'',
															'number' =>'',
																'sponsor' =>'',
														
																);
					}


					
					foreach($data['ld'] as $k => $v) {
		    			$result_4['order_item_4'][] = $v;
		    		}

		    		$data['order_data_4'] = $result_4;

		    		$data['others']	=	$this->Jobs_model->get_others($id);

					$result_5 = array();

					if(empty($data['others'])){
						$result_5['order_item_5'][] = array(
															'hobbies' =>'',
															'recognition' =>'',
															'membership' =>'',
															
																);
					}



					foreach($data['others'] as $k => $v) {
		    			$result_5['order_item_5'][] = $v;
		    		}

		    		$data['order_data_5'] = $result_5;


					$this->load->view('administrator/panel/templates/header', $data);
					$this->load->view('administrator/panel/templates/aside', $data);
					$this->load->view('administrator/panel/templates/navbar', $data);
					$this->load->view('administrator/panel/basic_information', $data);
					$this->load->view('administrator/panel/templates/subfooter', $data);
					$this->load->view('administrator/panel/templates/footer', $data);
				}
			}

			else{
				redirect('administrator-login');
			}
		}

	}
?>