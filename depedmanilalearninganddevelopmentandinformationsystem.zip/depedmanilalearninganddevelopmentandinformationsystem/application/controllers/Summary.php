<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Summary extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('text');
    }   

    public function ajax_list()
    {
        $list = $this->Summary_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $modules) {
            $no++;
            $row = array();
            $row[] = '<a href="#">'.$modules->category_name.'</a>';
            $row[] = '<a href="#">'.$modules->module_name.'</a>';
            $row[] = '<a href="'.$modules->module_g_drive.'"target="_blank">'.$modules->module_g_drive.'</a>';
            $row[] = $modules->count;

         
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Summary_model->count_all(),
                        "recordsFiltered" => $this->Summary_model->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }
 
   
}