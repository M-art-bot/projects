<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Activities extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('text');
    }   

    public function ajax_list()
    {
        $list = $this->Activities_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $modules) {
            $no++;
            $row = array();
            $row[] = $modules->first_name.' '.$modules->middle_name[0].' '.$modules->last_name;
            $row[] = $modules->position_title;
            $row[] = $modules->school_name;
            $row[] = '<a href="#">'.$modules->category_name.'</a>';
            $row[] = '<a href="#">'.$modules->module_name.'</a>';
            $row[] = '<a href="'.$modules->module_g_drive.'"target="_blank">'.$modules->module_g_drive.'</a>';
            $row[] = $modules->activity_score;
            $row[] =   '<a class="btn btn-sm btn-warning" href="javascript:void(0)" onclick="rate_to('.$modules->activity_id.')" title="Assess"><i class="fa fa-pencil"></i>Input Grade</a> ';
         
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Activities_model->count_all(),
                        "recordsFiltered" => $this->Activities_model->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }
 
   public function ajax_edit($id)
        {
            $data = $this->Activities_model->get_by_id($id);
            echo json_encode($data);
        }

      public function ajax_update()
        {
            $data = array(
                    'activity_score' => $this->input->post('score'),
                
                );
            $this->Activities_model->update(array('activity_id' => $this->input->post('activity_id')), $data);
            echo json_encode(array("status" => TRUE));
        }

}