<?php
	
	class Info extends CI_Controller
	{
		
		public function basic_update(){

			$update_basic_information	=	array('first_name' => strtoupper($this->input->post('first_name')),
													'middle_name' => strtoupper($this->input->post('middle_name')),
													'last_name' => strtoupper($this->input->post('last_name')),
													'extension_name' => strtoupper($this->input->post('extension_name')),
													'email_address' => $this->input->post('email_address'),
													'date_of_birth' => $this->input->post('date_of_birth'),
													'place_of_birth' => strtoupper($this->input->post('place_of_birth')),
													'gender' => strtoupper($this->input->post('gender')),
													'civil_status' => strtoupper($this->input->post('civil_status')),
													'citizenship' => strtoupper($this->input->post('citizenship')),
													'telephone_no' => strtoupper($this->input->post('telephone_no')),
													'mobile_no' => strtoupper($this->input->post('mobile_no')),
													'applicant_id'	=> $this->input->post('applicant_id'),
													'personal' => 1
											);

			$success	= 	$this->Info_model->update_info($update_basic_information);

		
			$this->session->set_flashdata('success', 'Successfully updated.');
      		redirect(md5('employers-profile'));
			


		}


		public function fam_update(){

			$update_fam_information	=	array(	
													'spouse_last_name' => strtoupper($this->input->post('spouse_last_name')),
													'spouse_first_name' => strtoupper($this->input->post('spouse_first_name')),
													'spouse_middle_name' => strtoupper($this->input->post('spouse_middle_name')),
													'spouse_extension_name' => strtoupper($this->input->post('spouse_extension_name')),
													'occupation' => strtoupper($this->input->post('occupation')),
													'company_name' => strtoupper($this->input->post('company_name')),
													'company_address' => strtoupper($this->input->post('company_address')),
													'company_tel_no'	=> strtoupper($this->input->post('company_tel_no')),
													'fathers_last_name' => strtoupper($this->input->post('fathers_last_name')),
													'fathers_first_name' => strtoupper($this->input->post('fathers_first_name')),
													'fathers_middle_name' => strtoupper($this->input->post('fathers_middle_name')),
													'fathers_extension_name' => strtoupper($this->input->post('fathers_extension_name')),
													'mothers_last_name' => strtoupper($this->input->post('mothers_last_name')),
													'mothers_first_name' => strtoupper($this->input->post('mothers_first_name')),
													'mothers_middle_name' => strtoupper($this->input->post('mothers_middle_name')),
													'mothers_maiden_name' => strtoupper($this->input->post('mothers_maiden_name')),
													'family_id'	=> $this->input->post('family_id')
											);

			$success	= 	$this->Info_model->update_family($update_fam_information);

		
			$this->session->set_flashdata('success_fam', 'Successfully updated.');
      		redirect(md5('employers-family'));
			


		}

		public function fam_add(){

			$add_fam_information	=	array(	
													'spouse_last_name' => strtoupper( $this->input->post('spouse_last_name')),
													'spouse_first_name' => strtoupper($this->input->post('spouse_first_name')),
													'spouse_middle_name' => strtoupper($this->input->post('spouse_middle_name')),
													'spouse_extension_name' => strtoupper($this->input->post('spouse_extension_name')),
													'occupation' => strtoupper($this->input->post('occupation')),
													'company_name' => strtoupper($this->input->post('company_name')),
													'company_address' => strtoupper($this->input->post('company_address')),
													'company_tel_no'	=> strtoupper($this->input->post('company_tel_no')),
													'fathers_last_name' => strtoupper($this->input->post('fathers_last_name')),
													'fathers_first_name' => strtoupper($this->input->post('fathers_first_name')),
													'fathers_middle_name' => strtoupper($this->input->post('fathers_middle_name')),
													'fathers_extension_name' => strtoupper($this->input->post('fathers_extension_name')),
													'mothers_last_name' => strtoupper($this->input->post('mothers_last_name')),
													'mothers_first_name' => strtoupper($this->input->post('mothers_first_name')),
													'mothers_middle_name' => strtoupper($this->input->post('mothers_middle_name')),
													'mothers_maiden_name' => strtoupper($this->input->post('mothers_maiden_name')),
													'applicant_id'	=> $this->input->post('applicant_id')
											);

			$update_fam              = array('fam' => 1, 'applicant_id'	=> $this->input->post('applicant_id'));
			$this->Info_model->fam($update_fam);

			$success	= 	$this->Info_model->add_family($add_fam_information);

		
			$this->session->set_flashdata('success_add_fam', 'Successfully Added.');
      		redirect(md5('employers-family'));
			

		}

		public function educ_add(){

			$add_educ_information	=	array(	
													'es_name' => strtoupper($this->input->post('es_name')),
													'es_year' => strtoupper($this->input->post('es_year')),
													'secondary_name' => strtoupper($this->input->post('secondary_name')),
													'secondary_year' => strtoupper($this->input->post('secondary_year')),
													'voc_name' => strtoupper($this->input->post('voc_name')),
													'voc_year' => strtoupper($this->input->post('voc_year')),
													'college_name' => strtoupper($this->input->post('college_name')),
													'college_course' => strtoupper($this->input->post('college_course')),
													'college_year'	=> strtoupper($this->input->post('college_year')),
													// 'grad_name' => strtoupper($this->input->post('grad_name')),
													// 'grad_year' => strtoupper($this->input->post('grad_year')),
													'applicant_id'	=> $this->input->post('applicant_id')
											);

			$update_fam              = array('educ' => 1, 'applicant_id'	=> $this->input->post('applicant_id'));
			$this->Info_model->educ($update_fam);

			$success	= 	$this->Info_model->add_educ($add_educ_information);

		
			$this->session->set_flashdata('success_educ_add', 'Successfully Added.');
      		redirect(md5('employers-education'));
			

		}

		public function educ_update(){

			$update_educ_information	=	array(	
													'es_name' => strtoupper($this->input->post('es_name')),
													'es_year' => strtoupper($this->input->post('es_year')),
													'secondary_name' => strtoupper($this->input->post('secondary_name')),
													'secondary_year' => strtoupper($this->input->post('secondary_year')),
													'voc_name' => strtoupper($this->input->post('voc_name')),
													'voc_year' => strtoupper($this->input->post('voc_year')),
													'college_name' => strtoupper($this->input->post('college_name')),
													'college_year'	=> strtoupper($this->input->post('college_year')),
													'grad_name' => strtoupper($this->input->post('grad_name')),
													'grad_year' => strtoupper($this->input->post('grad_year')),
													'educational_backgrounds_id'	=> $this->input->post('educational_backgrounds_id')
											);

			$success	= 	$this->Info_model->update_educ($update_educ_information);

		
			$this->session->set_flashdata('success_educ', 'Successfully updated.');
      		redirect(md5('employers-education'));
			

		}


		public function res_update(){

			$update_res_information	=	array(	
													'res_lot_no' => strtoupper($this->input->post('res_lot_no')),
													'res_street' => strtoupper($this->input->post('res_street')),
													'res_subdivision' => strtoupper($this->input->post('res_subdivision')),
													'res_brgy' => strtoupper($this->input->post('res_brgy')),
													'res_city' => strtoupper($this->input->post('res_city')),
													'res_prov' => strtoupper($this->input->post('res_prov')),
													'res_zip' => strtoupper($this->input->post('res_zip')),
													'res_id'	=> $this->input->post('res_id')
											);

			$success	= 	$this->Info_model->update_res($update_res_information);

		
			$this->session->set_flashdata('success_res', 'Successfully updated.');
      		redirect(md5('employers-profile'));
			


		}

		public function res_add(){

			$add_res_information	=	array(	
													'res_lot_no' => strtoupper($this->input->post('res_lot_no')),
													'res_street' => strtoupper($this->input->post('res_street')),
													'res_subdivision' => strtoupper($this->input->post('res_subdivision')),
													'res_brgy' => strtoupper($this->input->post('res_brgy')),
													'res_city' => strtoupper($this->input->post('res_city')),
													'res_prov' => strtoupper($this->input->post('res_prov')),
													'res_zip' => strtoupper($this->input->post('res_zip')),
													'applicant_id'	=> $this->input->post('applicant_id')
											);
			$update_fam              = array('res' => 1, 'applicant_id'	=> $this->input->post('applicant_id'));
			$this->Info_model->res($update_fam);
			$success	= 	$this->Info_model->add_res($add_res_information);

		
			$this->session->set_flashdata('success_add', 'Successfully Added.');
      		redirect(md5('employers-profile'));
			


		}

		public function per_update(){

			$update_per_information	=	array(	
													'per_lot_no' => strtoupper($this->input->post('per_lot_no')),
													'per_street' => strtoupper($this->input->post('per_street')),
													'per_subdivision' => strtoupper($this->input->post('per_subdivision')),
													'per_brgy' => strtoupper($this->input->post('per_brgy')),
													'per_city' => strtoupper($this->input->post('per_city')),
													'per_prov' => strtoupper($this->input->post('per_prov')),
													'per_zip' => strtoupper($this->input->post('per_zip')),
													'per_id'	=> $this->input->post('per_id')
											);

			$success	= 	$this->Info_model->update_per($update_per_information);

		
			$this->session->set_flashdata('success_per', 'Successfully updated.');
      		redirect(md5('employers-profile'));
			


		}

		public function per_add(){

			$add_per_information	=	array(	
													'per_lot_no' => strtoupper($this->input->post('per_lot_no')),
													'per_street' => strtoupper($this->input->post('per_street')),
													'per_subdivision' => strtoupper($this->input->post('per_subdivision')),
													'per_brgy' => strtoupper($this->input->post('per_brgy')),
													'per_city' => strtoupper($this->input->post('per_city')),
													'per_prov' => strtoupper($this->input->post('per_prov')),
													'per_zip' => strtoupper($this->input->post('per_zip')),
													'applicant_id'	=> $this->input->post('applicant_id')
											);
			$update_fam              = array('per' => 1, 'applicant_id'	=> $this->input->post('applicant_id'));
			$this->Info_model->per($update_fam);
			$success	= 	$this->Info_model->add_per($add_per_information);

		
			$this->session->set_flashdata('success_add_per', 'Successfully Added.');
      		redirect(md5('employers-profile'));
			


		}

		public function update_other(){

			$update_personal_information	=	array(	
													'height' => strtoupper($this->input->post('height')),
													'weight' => strtoupper($this->input->post('weight')),
													'blood_type' => strtoupper($this->input->post('blood_type')),
													'gsis' => strtoupper($this->input->post('gsis')),
													'pagibig' => strtoupper($this->input->post('pagibig')),
													'philhealth' => strtoupper($this->input->post('philhealth')),
													'sss' => strtoupper($this->input->post('sss')),
													'tin'	=> strtoupper($this->input->post('tin')),
													'employee_no'	=> strtoupper($this->input->post('employee_no')),
													'personal_id'	=> $this->input->post('personal_id')

											);

			$success	= 	$this->Info_model->update_personal_informations($update_personal_information);

		
			$this->session->set_flashdata('success_personal', 'Successfully updated.');
      		redirect(md5('employers-profile'));
			


		}

		public function add_other(){

			$add_personal_information	=	array(	
													'height' => strtoupper($this->input->post('height')),
													'weight' => strtoupper($this->input->post('weight')),
													'blood_type' => strtoupper($this->input->post('blood_type')),
													'gsis' => strtoupper($this->input->post('gsis')),
													'pagibig' => strtoupper($this->input->post('pagibig')),
													'philhealth' => strtoupper($this->input->post('philhealth')),
													'sss' => strtoupper($this->input->post('sss')),
													'tin'	=> strtoupper($this->input->post('tin')),
													'employee_no'	=> strtoupper($this->input->post('employee_no')),
													'applicant_id'	=> $this->input->post('applicant_id')
											);
			$update_fam              = array('other_1' => 1, 'applicant_id'	=> $this->input->post('applicant_id'));
			$this->Info_model->other($update_fam);
			
			$success	= 	$this->Info_model->add_personal_informations($add_personal_information);

		
			$this->session->set_flashdata('success_add_personal', 'Successfully Added.');
      		redirect(md5('employers-profile'));
			


		}

		public function civil_add(){
			
			
			$civil_id	= $this->Info_model->add_civil_informations();
	        	
	    	
    		$this->session->set_flashdata('success_add_civil', 'Successfully Added.');
    		redirect(md5('employers-civil'));
	    	
	    	
		}

		public function civil_update(){
			
			
			$civil_id	= $this->Info_model->update_civil_informations();
	        	
	    	
    		$this->session->set_flashdata('success_civil', 'Successfully Updates.');
    		redirect(md5('employers-civil'));
	    	
	    	
		}

		public function work_add(){
			
			
			$work_id	= $this->Info_model->add_work_informations();
	        	
	    	
    		$this->session->set_flashdata('success_add_work', 'Successfully Added.');
    		redirect(md5('employers-work'));
	    	
	    	
		}

		public function work_update(){
			
			
			$work_id	= $this->Info_model->update_work_informations();
	        	
	    	
    		$this->session->set_flashdata('success_work', 'Successfully Updates.');
    		redirect(md5('employers-work'));
	    	
	    	
		}

		public function voluntary_add(){
			
			
			$work_id	= $this->Info_model->add_voluntary_informations();
	        	
	    	
    		$this->session->set_flashdata('success_add_voluntary', 'Successfully Added.');
    		redirect(md5('employers-voluntary'));
	    	
	    	
		}

		public function voluntary_update(){
			
			
			$work_id	= $this->Info_model->update_voluntary_informations();
	        	
	    	
    		$this->session->set_flashdata('success_voluntary', 'Successfully Updated.');
    		redirect(md5('employers-voluntary'));
	    	
	    	
		}

		public function ld_add(){
			
			
			$work_id	= $this->Info_model->add_ld_informations();
	        	
	    	
    		$this->session->set_flashdata('success_add_ld', 'Successfully Added.');
    		redirect(md5('employers-ld'));
	    	
	    	
		}

		public function highest_add(){
			
			
			$work_id	= $this->Info_model->add_highest_informations();
	        	
	    	
    		$this->session->set_flashdata('success_highest', 'Successfully Added.');
    		redirect(md5('employers-education'));
	    	
	    	
		}

		public function highest_update(){
			
			
			$work_id	= $this->Info_model->update_highest_informations();
	        	
	    	
    		$this->session->set_flashdata('success_highest', 'Successfully Updated.');
    		redirect(md5('employers-education'));
	    	
	    	
		}

		public function ld_update(){
			
			
			$work_id	= $this->Info_model->update_ld_informations();
	        	
	    	
    		$this->session->set_flashdata('success_ld', 'Successfully Updated.');
    		redirect(md5('employers-ld'));
	    	
	    	
		}

		public function others_add(){
			
			
			$work_id	= $this->Info_model->add_others_informations();
	        	
	    	
    		$this->session->set_flashdata('success_add_others', 'Successfully Added.');
    		redirect(md5('employers-others'));
	    	
	    	
		}

		public function others_update(){
			
			
			$work_id	= $this->Info_model->update_others_informations();
	        	
	    	
    		$this->session->set_flashdata('success_others', 'Successfully Updated.');
    		redirect(md5('employers-others'));
	    	
	    	
		}
	
	}

?>