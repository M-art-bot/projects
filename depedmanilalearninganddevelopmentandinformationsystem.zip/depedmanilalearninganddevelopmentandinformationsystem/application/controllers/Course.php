<?php

	class Course extends CI_Controller
	{
		
		
		public function ajax_add()
	    {	
    		$applicant_id			= 	$this->session->userdata['logged_in_user']['applicant_id'];

	        $data = array(
	                'module_id' => $this->input->post('module_id'),
	                'activity_g_drive'	=> $this->input->post('course_g_drive'),
	                'activity_score'	=> '',
	                'applicant_id' => $applicant_id
	            );

	     
	       
	       $this->Activity_model->save($data);

	       $this->session->set_flashdata('success', ' ');
	       redirect(md5('ld-tip'));
	    }

	   
	}

?>