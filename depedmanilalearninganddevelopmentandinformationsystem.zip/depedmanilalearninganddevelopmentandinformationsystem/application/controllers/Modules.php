<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Modules extends CI_Controller{
	public function __construct()
    {
        parent::__construct();
        $this->load->helper('text');
    } 	



    public function index()
    {
    $data['title']          = 'DepEd Manila Personnel e-Learning and Information System';
        $data['system_name']    = ' DepEd Manila Personnel <br>e-Learning and Information System';
		$data['page']			=	"Add Modules";

		$user_id				= 	$this->session->userdata['logged_in']['userid'];
		$data['credentials']	=	$this->Dashboard_model->get($user_id);
					
		$this->load->view('administrator/panel/templates/header', $data);
		$this->load->view('administrator/panel/templates/aside', $data);
		$this->load->view('administrator/panel/templates/navbar', $data);
		$this->load->view('administrator/panel/addmodules', $data);
		$this->load->view('administrator/panel/templates/subfooter', $data);
		$this->load->view('administrator/panel/templates/footer', $data);
    }
    
    public function ajax_list()
    {
        $list = $this->Module_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $modules) {
            $no++;
            $row = array();
            $row[] = $modules->category_name;
            $row[] = $modules->module_name;
            $row[] = '<a href="'.$modules->module_g_drive.'"target="_blank">'.$modules->module_g_drive.'</a>';
   
 
            //add html for action
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_person('."'".$modules->module_id."'".')"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_person('."'".$modules->module_id."'".')"><i class="glyphicon glyphicon-trash"></i> Delete</a>';
         
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Module_model->count_all(),
                        "recordsFiltered" => $this->Module_model->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }
 
    public function ajax_edit($id)
    {
        $data = $this->Module_model->get_by_id($id);
      
        echo json_encode($data);
    }
 
    public function ajax_add()
    {
        $this->_validate();
        $data = array(
                'module_name' => $this->input->post('module_name'),
                'category_id' => $this->input->post('category_id'),
                'module_g_drive' => $this->input->post('module_g_drive'),
        
            );
        $insert = $this->Module_model->save($data);
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_update()
    {
        $this->_validate();
        $data = array(
                'module_name' => $this->input->post('module_name'),
                'category_id' => $this->input->post('category_id'),
                'module_g_drive' => $this->input->post('module_g_drive'),

            );
        $this->Module_model->update(array('module_id' => $this->input->post('module_id')), $data);
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->Module_model->delete_by_id($id);
        echo json_encode(array("status" => TRUE));
    }
 
 
    private function _validate()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
 
        if($this->input->post('module_name') == '')
        {
            $data['inputerror'][] = 'module_name';
            $data['error_string'][] = 'Module name is required';
            $data['status'] = FALSE;
        }
 
        if($this->input->post('module_g_drive') == '')
        {
            $data['inputerror'][] = 'module_g_drive';
            $data['error_string'][] = 'G drive link is required';
            $data['status'] = FALSE;
        }
 
        if($this->input->post('category_id') == '')
        {
            $data['inputerror'][] = 'category_id';
            $data['error_string'][] = 'Category Name is required';
            $data['status'] = FALSE;
        }
 
        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }

    public function summary(){
        $data['title']          =   "Administrator | Summary";
        $data['system_name']    =   "E Learning and Module Program";
        $data['page']           =   "Summary";

        $user_id                =   $this->session->userdata['logged_in']['userid'];
        $data['credentials']    =   $this->Dashboard_model->get($user_id);
                    
        $this->load->view('administrator/panel/templates/header', $data);
        $this->load->view('administrator/panel/templates/aside', $data);
        $this->load->view('administrator/panel/templates/navbar', $data);
        $this->load->view('administrator/panel/summary', $data);
        $this->load->view('administrator/panel/templates/subfooter', $data);
        $this->load->view('administrator/panel/templates/footer', $data);
    }

    public function activity(){
      $data['title']            = 'DepEd Manila Personnel e-Learning and Information System';
        $data['system_name']    = ' DepEd Manila Personnel <br>e-Learning and Information System';
        $data['page']           =   "Employee-Activities";

        $user_id                =   $this->session->userdata['logged_in']['userid'];
        $data['credentials']    =   $this->Dashboard_model->get($user_id);
                    
        $this->load->view('administrator/panel/templates/header', $data);
        $this->load->view('administrator/panel/templates/aside', $data);
        $this->load->view('administrator/panel/templates/navbar', $data);
        $this->load->view('administrator/panel/activities', $data);
        $this->load->view('administrator/panel/templates/subfooter', $data);
        $this->load->view('administrator/panel/templates/footer', $data);
    }

}