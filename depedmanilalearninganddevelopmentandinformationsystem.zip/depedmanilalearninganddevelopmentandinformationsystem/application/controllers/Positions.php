<?php

defined('BASEPATH') OR exit('No direct script access allowed');
class Positions extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('text');
    }   



    public function index()
    {
       $data['title']           = 'DepEd Manila Personnel e-Learning and Information System';
        $data['system_name']    = ' DepEd Manila Personnel <br>e-Learning and Information System';
        $data['page']           =   "Add Position";

        $user_id                =   $this->session->userdata['logged_in']['userid'];
        $data['credentials']    =   $this->Dashboard_model->get($user_id);
                    
        $this->load->view('administrator/panel/templates/header', $data);
        $this->load->view('administrator/panel/templates/aside', $data);
        $this->load->view('administrator/panel/templates/navbar', $data);
        $this->load->view('administrator/panel/addpositions', $data);
        $this->load->view('administrator/panel/templates/subfooter', $data);
        $this->load->view('administrator/panel/templates/footer', $data);
    }
    
    public function ajax_list()
    {
        $list = $this->Position_model->get_datatables();
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $modules) {
            $no++;
            $row = array();
            $row[] = $modules->job_category_name;
            $row[] = $modules->position_title;

            //add html for action
            $row[] = '<a class="btn btn-sm btn-primary" href="javascript:void(0)" title="Edit" onclick="edit_person('."'".$modules->job_id."'".')"><i class="glyphicon glyphicon-pencil"></i> Edit</a>
                  <a class="btn btn-sm btn-danger" href="javascript:void(0)" title="Hapus" onclick="delete_person('."'".$modules->job_id."'".')"><i class="glyphicon glyphicon-trash"></i> Delete</a>';
         
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Position_model->count_all(),
                        "recordsFiltered" => $this->Position_model->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }
 
    public function ajax_edit($id)
    {
        $data = $this->Position_model->get_by_id($id);
      
        echo json_encode($data);
    }
 
    public function ajax_add()
    {
        $this->_validate();
        $data = array(
                'job_category_id' => $this->input->post('job_category_id'),
                'position_title'         => $this->input->post('position_title'),
        
            );
        $insert = $this->Position_model->save($data);
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_update()
    {
        $this->_validate();
        $data = array(
                 'job_category_id' => $this->input->post('job_category_id'),
                'position_title'         => $this->input->post('position_title'),
        
            );
       
            
        $this->Position_model->update(array('job_id' => $this->input->post('job_id')), $data);
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->Position_model->delete_by_id($id);
        echo json_encode(array("status" => TRUE));
    }
 
 
    private function _validate()
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
 
        if($this->input->post('job_category_id') == '')
        {
            $data['inputerror'][] = 'Category name';
            $data['error_string'][] = 'Category name is required';
            $data['status'] = FALSE;
        }
 
     
        if($this->input->post('position_title') == '')
        {
            $data['inputerror'][] = 'Position Title';
            $data['error_string'][] = 'Position Title is required';
            $data['status'] = FALSE;
        }
 
        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }

}