ERROR - 2021-05-15 17:34:50 --> Severity: error --> Exception: Call to undefined method Dashboard_model::count_jobs() C:\xampp\htdocs\hris\application\controllers\Dashboard.php 20
ERROR - 2021-05-15 17:35:17 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 11
ERROR - 2021-05-15 17:35:40 --> Severity: Notice --> Trying to get property 'applicant_id' of non-object C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 11
ERROR - 2021-05-15 17:35:54 --> Severity: error --> Exception: syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 11
ERROR - 2021-05-15 17:35:58 --> Severity: Notice --> Undefined index: applicant_id C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 11
ERROR - 2021-05-15 17:37:11 --> Severity: Notice --> Undefined index: COUNT(*) C:\xampp\htdocs\hris\application\models\Dashboard_model.php 33
ERROR - 2021-05-15 17:39:08 --> Severity: Notice --> Trying to access array offset on value of type int C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 11
ERROR - 2021-05-15 17:48:32 --> 404 Page Not Found: Jobs/sign_IN
ERROR - 2021-05-15 17:48:32 --> 404 Page Not Found: Jobs/assets
