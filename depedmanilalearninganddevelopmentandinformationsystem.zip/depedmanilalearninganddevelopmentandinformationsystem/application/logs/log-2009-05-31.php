<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2009-05-31 15:46:57 --> 404 Page Not Found: Candidates-dashboard/index
