ERROR - 2021-05-30 18:00:57 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 51
ERROR - 2021-05-30 18:00:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 51
ERROR - 2021-05-30 18:02:49 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:02:49 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:02:53 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:02:53 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:03:03 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:03:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:03:04 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:03:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:15 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:22 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:28 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:28 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:31 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:31 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:58 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:04:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:06:08 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 57
ERROR - 2021-05-30 18:06:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 57
ERROR - 2021-05-30 18:07:46 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 44
ERROR - 2021-05-30 18:18:26 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:21:23 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:23 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:23 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:24 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:25 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:25 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:26 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:27 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:27 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:27 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:27 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:27 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:27 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:32 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:33 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:39 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:39 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:39 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:39 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:39 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:21:40 --> Severity: Notice --> Undefined index: HTTP_REFERER C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 13
ERROR - 2021-05-30 18:26:50 --> Severity: error --> Exception: Call to undefined method Employers::logged_in() C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 9
ERROR - 2021-05-30 18:41:58 --> Severity: error --> Exception: Call to undefined method Employers::logged_in() C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 9
ERROR - 2021-05-30 18:47:02 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 67
ERROR - 2021-05-30 18:47:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 67
ERROR - 2021-05-30 18:47:02 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 10
ERROR - 2021-05-30 18:47:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 10
ERROR - 2021-05-30 18:47:34 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 10
ERROR - 2021-05-30 18:47:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 10
ERROR - 2021-05-30 18:47:44 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 10
ERROR - 2021-05-30 18:47:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 10
ERROR - 2021-05-30 18:49:10 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:49:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:50:00 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:50:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:51:41 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:51:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:52:24 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:52:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:53:16 --> 404 Page Not Found: Lid-tip/index
ERROR - 2021-05-30 18:53:26 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:53:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 464
ERROR - 2021-05-30 18:54:22 --> Severity: Notice --> Object of class CI_Session could not be converted to number C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 10
ERROR - 2021-05-30 18:54:22 --> Severity: Notice --> Trying to get property 'userdata' of non-object C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:54:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:54:22 --> Severity: error --> Exception: Call to a member function flashdata() on int C:\xampp\htdocs\codeigniterapps\hris\application\views\employee\pages\login.php 32
ERROR - 2021-05-30 18:54:58 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:54:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:54:58 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:54:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:55:16 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:55:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:55:21 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:55:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:55:36 --> Severity: error --> Exception: syntax error, unexpected '!' C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:55:38 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:55:38 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 18:56:01 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:56:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:56:33 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:56:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:56:36 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 18:56:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 69
ERROR - 2021-05-30 19:01:21 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\codeigniterapps\hris\application\views\employee\templates\header.php 9
ERROR - 2021-05-30 19:01:40 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\codeigniterapps\hris\application\views\employee\templates\header.php 9
ERROR - 2021-05-30 19:03:58 --> 404 Page Not Found: Employers-profile/index
ERROR - 2021-05-30 19:04:19 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 68
ERROR - 2021-05-30 19:04:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 68
ERROR - 2021-05-30 19:04:19 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 19:04:19 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 19:04:26 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 68
ERROR - 2021-05-30 19:04:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 68
ERROR - 2021-05-30 19:04:26 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 19:04:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 12
ERROR - 2021-05-30 19:07:46 --> 404 Page Not Found: Candidates-dashboard/index
