<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-25 04:56:03 --> Severity: Notice --> Undefined variable: jobs C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\panel\dashboard.php 26
ERROR - 2021-05-25 04:58:30 --> Severity: Notice --> Undefined variable: jobs C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\panel\dashboard.php 26
ERROR - 2021-05-25 05:04:50 --> Severity: error --> Exception: syntax error, unexpected '$route' (T_VARIABLE) C:\xampp\htdocs\codeigniterapps\hris\application\config\routes.php 35
ERROR - 2021-05-25 05:06:49 --> 404 Page Not Found: Administrator-personnel/index
ERROR - 2021-05-25 05:06:50 --> 404 Page Not Found: Administrator-personnel/assets
