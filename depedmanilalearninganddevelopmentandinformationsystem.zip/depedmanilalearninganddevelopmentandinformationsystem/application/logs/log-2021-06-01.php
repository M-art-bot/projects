ERROR - 2021-06-01 10:59:36 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 10:59:50 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 10:59:55 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:00:49 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:00:50 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:00:51 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:00:53 --> 404 Page Not Found: Ld-activity/16
ERROR - 2021-06-01 11:00:56 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:00:57 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:01:33 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:01:38 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:02:07 --> Severity: error --> Exception: syntax error, unexpected 'echo' (T_ECHO), expecting ')' C:\xampp\htdocs\codeigniterapps\hris\application\models\Activity_log.php 32
ERROR - 2021-06-01 11:02:15 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:02:48 --> Severity: Notice --> Undefined variable: applicant_id C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\applications.php 55
ERROR - 2021-06-01 11:42:37 --> 404 Page Not Found: Dadada/index
