ERROR - 2021-06-05 15:20:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\codeigniterapps\hris\application\models\Summary_model.php 46
ERROR - 2021-06-05 15:21:34 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\codeigniterapps\hris\application\models\Summary_model.php 46
ERROR - 2021-06-05 15:22:10 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\codeigniterapps\hris\application\models\Summary_model.php 46
