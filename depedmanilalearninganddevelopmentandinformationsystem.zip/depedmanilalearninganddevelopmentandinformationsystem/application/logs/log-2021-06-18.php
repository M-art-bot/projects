<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-18 09:13:14 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
ERROR - 2021-06-18 09:13:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
ERROR - 2021-06-18 09:34:47 --> 404 Page Not Found: Users-login/index
