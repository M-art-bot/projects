ERROR - 2021-06-09 10:30:49 --> Query error: Unknown column 'applicants.firstname' in 'order clause' - Invalid query: SELECT applicants.*, jobs.*, schools.*, count(ld.applicant_id) as total
FROM `applicants`
JOIN `jobs` ON `jobs`.`job_id` = `applicants`.`job_id`
LEFT JOIN `ld` ON `ld`.`applicant_id`=`applicants`.`applicant_id`
JOIN `schools` ON `schools`.`school_id` = `applicants`.`school_id`
GROUP BY `applicants`.`applicant_id`
ORDER BY `applicants`.`firstname` ASC
 LIMIT 10
ERROR - 2021-06-09 10:30:50 --> Query error: Unknown column 'applicants.firstname' in 'order clause' - Invalid query: SELECT applicants.*, jobs.*, schools.*, count(ld.applicant_id) as total
FROM `applicants`
JOIN `jobs` ON `jobs`.`job_id` = `applicants`.`job_id`
LEFT JOIN `ld` ON `ld`.`applicant_id`=`applicants`.`applicant_id`
JOIN `schools` ON `schools`.`school_id` = `applicants`.`school_id`
GROUP BY `applicants`.`applicant_id`
ORDER BY `applicants`.`firstname` DESC
 LIMIT 10
ERROR - 2021-06-09 10:30:53 --> Query error: Unknown column 'applicants.firstname' in 'order clause' - Invalid query: SELECT applicants.*, jobs.*, schools.*, count(ld.applicant_id) as total
FROM `applicants`
JOIN `jobs` ON `jobs`.`job_id` = `applicants`.`job_id`
LEFT JOIN `ld` ON `ld`.`applicant_id`=`applicants`.`applicant_id`
JOIN `schools` ON `schools`.`school_id` = `applicants`.`school_id`
GROUP BY `applicants`.`applicant_id`
ORDER BY `applicants`.`firstname` ASC
 LIMIT 10
ERROR - 2021-06-09 10:31:00 --> Query error: Unknown column 'applicants.firstname' in 'order clause' - Invalid query: SELECT applicants.*, jobs.*, schools.*, count(ld.applicant_id) as total
FROM `applicants`
JOIN `jobs` ON `jobs`.`job_id` = `applicants`.`job_id`
LEFT JOIN `ld` ON `ld`.`applicant_id`=`applicants`.`applicant_id`
JOIN `schools` ON `schools`.`school_id` = `applicants`.`school_id`
GROUP BY `applicants`.`applicant_id`
ORDER BY `applicants`.`firstname` ASC
 LIMIT 10
ERROR - 2021-06-09 10:33:26 --> Query error: Unknown column 'applicants.firstname' in 'order clause' - Invalid query: SELECT applicants.*, jobs.*, schools.*, count(ld.applicant_id) as total
FROM `applicants`
JOIN `jobs` ON `jobs`.`job_id` = `applicants`.`job_id`
LEFT JOIN `ld` ON `ld`.`applicant_id`=`applicants`.`applicant_id`
JOIN `schools` ON `schools`.`school_id` = `applicants`.`school_id`
GROUP BY `applicants`.`applicant_id`
ORDER BY `applicants`.`firstname` ASC
 LIMIT 10
