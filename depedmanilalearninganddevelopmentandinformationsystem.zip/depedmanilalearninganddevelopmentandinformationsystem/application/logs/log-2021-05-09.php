<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-09 13:54:51 --> Severity: Notice --> Undefined index: userid C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-09 13:56:37 --> Severity: Notice --> Undefined index: applicantid C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 13
ERROR - 2021-05-09 13:56:44 --> Severity: Notice --> Undefined index: applicantid C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 36
ERROR - 2021-05-09 13:57:42 --> Severity: Notice --> Undefined index: userid C:\xampp\htdocs\hris\application\controllers\Recruitment.php 8
ERROR - 2021-05-09 13:59:16 --> Severity: Notice --> Undefined index: applicantid C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 13
ERROR - 2021-05-09 19:37:27 --> Unable to load the requested class: Facebook
ERROR - 2021-05-09 19:38:14 --> Unable to load the requested class: Facebook
ERROR - 2021-05-09 19:38:22 --> Unable to load the requested class: Facebook
ERROR - 2021-05-09 19:38:59 --> Unable to load the requested class: Facebook
ERROR - 2021-05-09 19:39:22 --> Unable to load the requested class: Facebook
ERROR - 2021-05-09 19:39:49 --> Unable to load the requested class: Facebook
ERROR - 2021-05-09 19:39:50 --> 404 Page Not Found: Oauth_login/assets
ERROR - 2021-05-09 19:41:02 --> Unable to load the requested class: Facebook
ERROR - 2021-05-09 19:41:03 --> Unable to load the requested class: Facebook
ERROR - 2021-05-09 19:50:21 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-09 19:50:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
