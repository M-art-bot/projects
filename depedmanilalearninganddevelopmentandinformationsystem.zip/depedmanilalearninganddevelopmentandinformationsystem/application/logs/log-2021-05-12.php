<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-12 04:12:26 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 04:12:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 04:12:26 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 25
ERROR - 2021-05-12 04:12:26 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-12 04:12:26 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-12 04:12:26 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-12 04:12:26 --> Severity: Warning --> Undefined array key "draw" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 72
ERROR - 2021-05-12 04:12:26 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 04:12:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 05:55:28 --> Severity: Compile Error --> Cannot redeclare Jobs::dashboard() C:\xampp\htdocs\hris\application\controllers\Jobs.php 144
ERROR - 2021-05-12 05:56:05 --> 404 Page Not Found: Jobs/assets
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 432
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 432
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 438
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 438
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 449
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 449
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 460
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 460
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 471
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 471
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 482
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 482
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 493
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 493
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 504
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 504
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 639
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 639
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 645
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 645
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 656
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 656
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 667
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 667
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 678
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 678
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 689
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 689
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 700
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 700
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 711
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 711
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 722
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 722
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 733
ERROR - 2021-05-12 05:57:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 733
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 147
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 147
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 153
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 153
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 164
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 164
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 175
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 175
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 186
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 186
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 197
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 197
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 208
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 208
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $per C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 219
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 219
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 354
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 354
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 360
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 360
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 371
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 371
ERROR - 2021-05-12 06:04:37 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 382
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 382
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 393
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 393
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 404
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 404
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 415
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 415
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 426
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 426
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 437
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 437
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 448
ERROR - 2021-05-12 06:04:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 448
ERROR - 2021-05-12 06:05:21 --> Severity: Compile Error --> Cannot redeclare Jobs_model::get_family() C:\xampp\htdocs\hris\application\models\Jobs_model.php 127
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 354
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 354
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 360
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 360
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 371
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 371
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 382
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 382
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 393
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 393
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 404
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 404
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 415
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 415
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 426
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 426
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 437
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 437
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Undefined variable $other C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 448
ERROR - 2021-05-12 06:06:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 448
ERROR - 2021-05-12 06:11:00 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting "elseif" or "else" or "endif" C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 915
ERROR - 2021-05-12 06:14:23 --> 404 Page Not Found: Canidates-dashboard/index
ERROR - 2021-05-12 06:14:45 --> Severity: Warning --> Undefined array key "password
				" C:\xampp\htdocs\hris\application\controllers\Jobs.php 43
ERROR - 2021-05-12 06:16:15 --> Severity: Warning --> Undefined array key "logged_in_user" C:\xampp\htdocs\hris\application\controllers\Jobs.php 90
ERROR - 2021-05-12 06:16:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Jobs.php 90
ERROR - 2021-05-12 06:35:51 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 237
ERROR - 2021-05-12 07:07:42 --> Query error: Column 'occupation' cannot be null - Invalid query: INSERT INTO `family_background` (`spouse_last_name`, `spouse_first_name`, `spouse_middle_name`, `spouse_extension_name`, `occupation`, `company_name`, `company_address`, `company_tel_no`, `fathers_last_name`, `fathers_first_name`, `fathers_middle_name`, `fathers_extension_name`, `mothers_last_name`, `mothers_first_name`, `mothers_middle_name`, `mothers_maiden_name`, `applicant_id`) VALUES ('DEL ROSARIO', 'TEUDULO', 'REYES', 'N/A', NULL, 'N/A', 'N/A', 'N/A', NULL, NULL, NULL, NULL, 'MORGADO', 'LUCIA', 'FERRER', 'N/A', '16')
ERROR - 2021-05-12 07:11:27 --> Query error: Column 'occupation' cannot be null - Invalid query: INSERT INTO `family_background` (`spouse_last_name`, `spouse_first_name`, `spouse_middle_name`, `spouse_extension_name`, `occupation`, `company_name`, `company_address`, `company_tel_no`, `fathers_last_name`, `fathers_first_name`, `fathers_middle_name`, `fathers_extension_name`, `mothers_last_name`, `mothers_first_name`, `mothers_middle_name`, `mothers_maiden_name`, `applicant_id`) VALUES ('DEL ROSARIO', 'TEUDULO', 'REYES', 'N/A', NULL, 'N/A', 'N/A', 'N/A', NULL, NULL, NULL, NULL, 'MORGADO', 'LUCIA', 'FERRER', 'N/A', '16')
ERROR - 2021-05-12 07:11:31 --> Query error: Column 'occupation' cannot be null - Invalid query: INSERT INTO `family_background` (`spouse_last_name`, `spouse_first_name`, `spouse_middle_name`, `spouse_extension_name`, `occupation`, `company_name`, `company_address`, `company_tel_no`, `fathers_last_name`, `fathers_first_name`, `fathers_middle_name`, `fathers_extension_name`, `mothers_last_name`, `mothers_first_name`, `mothers_middle_name`, `mothers_maiden_name`, `applicant_id`) VALUES ('DEL ROSARIO', 'TEUDULO', 'REYES', 'N/A', NULL, 'N/A', 'N/A', 'N/A', NULL, NULL, NULL, NULL, 'MORGADO', 'LUCIA', 'FERRER', 'N/A', '16')
ERROR - 2021-05-12 07:11:45 --> Query error: Column 'occupation' cannot be null - Invalid query: INSERT INTO `family_background` (`spouse_last_name`, `spouse_first_name`, `spouse_middle_name`, `spouse_extension_name`, `occupation`, `company_name`, `company_address`, `company_tel_no`, `fathers_last_name`, `fathers_first_name`, `fathers_middle_name`, `fathers_extension_name`, `mothers_last_name`, `mothers_first_name`, `mothers_middle_name`, `mothers_maiden_name`, `applicant_id`) VALUES ('DEL ROSARIO', 'TEUDULO', 'REYES', 'N/A', NULL, 'N/A', 'N/A', 'N/A', NULL, NULL, NULL, NULL, 'MORGADO', 'LUCIA', 'FERRER', 'N/A', '16')
ERROR - 2021-05-12 07:13:14 --> Query error: Column 'fathers_last_name' cannot be null - Invalid query: INSERT INTO `family_background` (`spouse_last_name`, `spouse_first_name`, `spouse_middle_name`, `spouse_extension_name`, `occupation`, `company_name`, `company_address`, `company_tel_no`, `fathers_last_name`, `fathers_first_name`, `fathers_middle_name`, `fathers_extension_name`, `mothers_last_name`, `mothers_first_name`, `mothers_middle_name`, `mothers_maiden_name`, `applicant_id`) VALUES ('DEL ROSARIO', 'TEUDULO', 'REYES', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', NULL, NULL, NULL, NULL, 'MORGADO', 'LUCIA', 'FERRER', 'N/A', '16')
ERROR - 2021-05-12 07:14:34 --> Query error: Column 'fathers_last_name' cannot be null - Invalid query: INSERT INTO `family_background` (`spouse_last_name`, `spouse_first_name`, `spouse_middle_name`, `spouse_extension_name`, `occupation`, `company_name`, `company_address`, `company_tel_no`, `fathers_last_name`, `fathers_first_name`, `fathers_middle_name`, `fathers_extension_name`, `mothers_last_name`, `mothers_first_name`, `mothers_middle_name`, `mothers_maiden_name`, `applicant_id`) VALUES ('DEL ROSARIO', 'TEUDULO', 'REYES', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', NULL, NULL, NULL, NULL, 'MORGADO', 'LUCIA', 'FERRER', 'N/A', '16')
ERROR - 2021-05-12 07:25:30 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 07:25:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 07:25:30 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 25
ERROR - 2021-05-12 07:25:30 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-12 07:25:30 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "draw" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 72
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 25
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "draw" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 72
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 07:25:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 43
ERROR - 2021-05-12 07:58:20 --> Severity: Warning --> Undefined array key "logged_in_user" C:\xampp\htdocs\hris\application\controllers\Jobs.php 90
ERROR - 2021-05-12 07:58:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Jobs.php 90
ERROR - 2021-05-12 07:59:11 --> 404 Page Not Found: Canidates-dashboard/index
ERROR - 2021-05-12 07:59:31 --> 404 Page Not Found: Canidates-dashboard/index
ERROR - 2021-05-12 08:22:54 --> 404 Page Not Found: Jobs/education
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 61
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 66
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 77
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 88
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 99
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 111
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 122
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 133
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 144
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 155
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 166
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 177
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 188
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 200
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 211
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 222
ERROR - 2021-05-12 08:24:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\family_background.php 233
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 111
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 122
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 133
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 144
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 155
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 166
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 177
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 188
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 200
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 211
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 222
ERROR - 2021-05-12 08:26:35 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 233
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 111
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 122
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 133
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 144
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 155
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 166
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 177
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 188
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 200
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 211
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 222
ERROR - 2021-05-12 08:27:17 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 233
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 111
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 122
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 133
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 144
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 155
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 166
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 177
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 188
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 200
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 211
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 222
ERROR - 2021-05-12 08:33:45 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 233
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 111
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 122
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 133
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 144
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 155
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 166
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 177
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 188
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 200
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 211
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 222
ERROR - 2021-05-12 08:35:26 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 233
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 111
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 122
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 133
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 144
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 155
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 166
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 177
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 188
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 200
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 211
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 222
ERROR - 2021-05-12 08:35:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 233
ERROR - 2021-05-12 08:37:40 --> Severity: Warning --> Undefined array key "family" C:\xampp\htdocs\hris\application\controllers\Jobs.php 198
ERROR - 2021-05-12 08:37:40 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 111
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 111
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 122
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 122
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 133
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 133
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 144
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 144
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 155
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 155
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 166
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 166
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 177
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 177
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 188
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 188
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 200
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 200
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 211
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 211
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 222
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 222
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 233
ERROR - 2021-05-12 08:37:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 233
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined array key "family" C:\xampp\htdocs\hris\application\controllers\Jobs.php 198
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 111
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 111
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 122
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 122
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 133
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 133
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 144
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 144
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 155
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 155
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 166
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 166
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 177
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 177
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 188
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 188
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 200
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 200
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 211
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 211
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 222
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 222
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Undefined variable $family C:\xampp\htdocs\hris\application\views\vacancy\education.php 233
ERROR - 2021-05-12 08:38:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\education.php 233
ERROR - 2021-05-12 08:40:54 --> Severity: Warning --> Undefined array key "logged_in" C:\xampp\htdocs\hris\application\controllers\Candidates.php 9
ERROR - 2021-05-12 08:40:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Candidates.php 9
ERROR - 2021-05-12 10:34:38 --> Severity: error --> Exception: syntax error, unexpected single-quoted string "educational_backgrounds_id", expecting ")" C:\xampp\htdocs\hris\application\controllers\Info.php 136
ERROR - 2021-05-12 10:36:05 --> Query error: Unknown column 'es_yea' in 'field list' - Invalid query: INSERT INTO `educational_backgrounds` (`es_name`, `es_yea`, `secondary_name`, `secondary_year`, `voc_name`, `voc_year`, `college_name`, `college_year`, `grad_name`, `grade_year`, `applicant_id`) VALUES ('ANDRES BONIFACIO ELEMENTARY SCHOOL', '2010', 'CAYETANO ARELLANO HIGH SCHOOL', '2014', 'N/A', 'N/A', 'UNIVERSIDAD DE MANILA', '2020', 'N/A', NULL, '16')
ERROR - 2021-05-12 10:36:20 --> Query error: Unknown column 'es_yea' in 'field list' - Invalid query: INSERT INTO `educational_backgrounds` (`es_name`, `es_yea`, `secondary_name`, `secondary_year`, `voc_name`, `voc_year`, `college_name`, `college_year`, `grad_name`, `grade_year`, `applicant_id`) VALUES ('ANDRES BONIFACIO ELEMENTARY SCHOOL', '2010', 'CAYETANO ARELLANO HIGH SCHOOL', '2014', 'N/A', 'N/A', 'UNIVERSIDAD DE MANILA', '2020', 'N/A', NULL, '16')
ERROR - 2021-05-12 10:36:27 --> Query error: Unknown column 'grade_year' in 'field list' - Invalid query: INSERT INTO `educational_backgrounds` (`es_name`, `es_year`, `secondary_name`, `secondary_year`, `voc_name`, `voc_year`, `college_name`, `college_year`, `grad_name`, `grade_year`, `applicant_id`) VALUES ('ANDRES BONIFACIO ELEMENTARY SCHOOL', '2010', 'CAYETANO ARELLANO HIGH SCHOOL', '2014', 'N/A', 'N/A', 'UNIVERSIDAD DE MANILA', '2020', 'N/A', NULL, '16')
ERROR - 2021-05-12 10:37:00 --> 404 Page Not Found: Canidates-dashboard/index
ERROR - 2021-05-12 10:42:29 --> Severity: Warning --> Undefined array key "logged_in_user" C:\xampp\htdocs\hris\application\controllers\Jobs.php 184
ERROR - 2021-05-12 10:42:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Jobs.php 184
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 110
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 121
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 132
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 143
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 154
ERROR - 2021-05-12 10:43:13 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 165
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 110
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 121
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 132
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 143
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 154
ERROR - 2021-05-12 10:43:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 165
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 110
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 121
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 132
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 143
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 154
ERROR - 2021-05-12 10:44:38 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 165
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 61
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 66
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 77
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 88
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 99
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 110
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 121
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 132
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 143
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 154
ERROR - 2021-05-12 10:44:42 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\education.php 165
ERROR - 2021-05-12 10:45:00 --> 404 Page Not Found: Canidates-dashboard/index
ERROR - 2021-05-12 10:47:44 --> Severity: Warning --> Undefined array key "logged_in_user" C:\xampp\htdocs\hris\application\controllers\Jobs.php 184
ERROR - 2021-05-12 10:47:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Jobs.php 184
ERROR - 2021-05-12 10:48:44 --> Severity: Warning --> Undefined array key "password
				" C:\xampp\htdocs\hris\application\controllers\Jobs.php 43
ERROR - 2021-05-12 10:54:12 --> 404 Page Not Found: Candidates-civil/index
