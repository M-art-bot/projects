ERROR - 2021-05-08 10:36:23 --> Severity: error --> Exception: Too few arguments to function Jobs_model::get_by_id(), 0 passed in C:\xampp\htdocs\hris\application\controllers\Candidates_2.php on line 17 and exactly 1 expected C:\xampp\htdocs\hris\application\models\Jobs_model.php 12
ERROR - 2021-05-08 10:39:45 --> Severity: Notice --> Trying to get property 'job_title' of non-object C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:39:45 --> Severity: Notice --> Trying to get property 'job_title' of non-object C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:39:45 --> Severity: Notice --> Trying to get property 'job_title' of non-object C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:39:52 --> Severity: Notice --> Trying to get property 'job_title' of non-object C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:39:52 --> Severity: Notice --> Trying to get property 'job_title' of non-object C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:39:52 --> Severity: Notice --> Trying to get property 'job_title' of non-object C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:40:06 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:40:06 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:40:06 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:41:13 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:05 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:05 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:05 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:14 --> Severity: Warning --> Illegal string offset 'job_title;' C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:14 --> Severity: Warning --> Illegal string offset 'job_title;' C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:14 --> Severity: Warning --> Illegal string offset 'job_title;' C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:20 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:20 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:20 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 54
ERROR - 2021-05-08 10:42:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 54
ERROR - 2021-05-08 10:42:47 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 54
ERROR - 2021-05-08 10:42:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 54
ERROR - 2021-05-08 10:42:47 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:42:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 54
ERROR - 2021-05-08 10:42:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 54
ERROR - 2021-05-08 10:42:47 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:43:00 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:43:00 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:43:00 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:43:43 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 54
ERROR - 2021-05-08 10:43:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 54
ERROR - 2021-05-08 10:43:43 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:43:50 --> Severity: Notice --> Undefined index: job_title; C:\xampp\htdocs\hris\application\views\pages\vacancy_list.php 55
ERROR - 2021-05-08 10:55:58 --> 404 Page Not Found: Candidates-profile/index
ERROR - 2021-05-08 11:00:33 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or ',' C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 28
ERROR - 2021-05-08 11:00:51 --> Severity: Notice --> Undefined index: email_addresss C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 18
ERROR - 2021-05-08 14:25:33 --> Severity: Notice --> Undefined variable: email_address C:\xampp\htdocs\hris\application\models\Users_model.php 37
ERROR - 2021-05-08 14:51:08 --> Severity: error --> Exception: Call to undefined method Candidates_model::view() C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 38
ERROR - 2021-05-08 14:51:54 --> 404 Page Not Found: Candidates/update
ERROR - 2021-05-08 14:51:55 --> 404 Page Not Found: Candidates/assets
ERROR - 2021-05-08 14:53:06 --> Severity: Notice --> Undefined index: userid C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-08 14:54:58 --> Severity: Notice --> Undefined index: applicantid C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 36
ERROR - 2021-05-08 14:55:35 --> Severity: Notice --> Undefined index: applicantid C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 13
ERROR - 2021-05-08 14:57:33 --> Severity: Notice --> Undefined index: userid C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-08 15:00:04 --> Severity: Notice --> Undefined index: applicantid C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 36
ERROR - 2021-05-08 15:09:20 --> Severity: Notice --> Undefined index: userid C:\xampp\htdocs\hris\application\controllers\Basic_information.php 9
ERROR - 2021-05-08 15:26:23 --> Severity: Notice --> Undefined index: applicantid C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 36
ERROR - 2021-05-08 17:34:32 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 36
ERROR - 2021-05-08 17:34:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Candidates_2.php 36
