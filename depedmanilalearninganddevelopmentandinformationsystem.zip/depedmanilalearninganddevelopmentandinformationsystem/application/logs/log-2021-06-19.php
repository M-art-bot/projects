<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-19 16:56:34 --> Severity: Notice --> Undefined variable: system_name C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\views\administrator\forms\login_2.php 15
ERROR - 2021-06-19 16:56:46 --> Severity: Compile Error --> Can't use function return value in write context C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\controllers\Employers.php 11
ERROR - 2021-06-19 16:56:54 --> Severity: error --> Exception: Call to undefined function system_name() C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\controllers\Employers.php 11
ERROR - 2021-06-19 16:57:14 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\controllers\Employers.php 11
ERROR - 2021-06-19 16:57:14 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\controllers\Employers.php 11
ERROR - 2021-06-19 16:57:14 --> Severity: Notice --> Undefined variable: system_name C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\views\administrator\forms\login_2.php 15
ERROR - 2021-06-19 16:57:32 --> Severity: error --> Exception: Call to undefined function system_name() C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\controllers\Employers.php 11
ERROR - 2021-06-19 16:57:43 --> Severity: Notice --> Undefined variable: system_name C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\views\administrator\forms\login_2.php 15
ERROR - 2021-06-19 16:57:49 --> Severity: Notice --> Undefined variable: system_name C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\views\administrator\forms\login_2.php 15
ERROR - 2021-06-19 16:57:55 --> Severity: error --> Exception: Call to undefined function system_name() C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\controllers\Employers.php 11
ERROR - 2021-06-19 16:58:08 --> Severity: Notice --> Undefined variable: system_name C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\views\administrator\forms\login_2.php 15
ERROR - 2021-06-19 16:58:12 --> Severity: Notice --> Undefined variable: system_name C:\xampp\htdocs\codeigniterapps\depedmanilalearninganddevelopmentandinformationsystem\application\views\administrator\forms\login_2.php 15
