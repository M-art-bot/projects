	ERROR - 2021-05-23 18:01:30 --> Query error: Unknown column 'activities.applicant_id' in 'where clause' - Invalid query: SELECT *
FROM `applicants`
JOIN `courses` ON `applicants`.`applicant_id` = `courses`.`applicant_id`
WHERE `activities`.`applicant_id` = '16'
ORDER BY `activities`.`activity_id` DESC
 LIMIT 10
