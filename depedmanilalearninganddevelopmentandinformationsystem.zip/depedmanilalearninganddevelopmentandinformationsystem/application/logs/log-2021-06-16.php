ERROR - 2021-06-16 17:51:21 --> Severity: Notice --> Undefined property: stdClass::$age_name C:\xampp\htdocs\codeigniterapps\hris\application\models\Personnel_model.php 73
ERROR - 2021-06-16 17:51:46 --> Severity: Notice --> Undefined property: stdClass::$age_name C:\xampp\htdocs\codeigniterapps\hris\application\models\Personnel_model.php 73
ERROR - 2021-06-16 17:51:54 --> Severity: Notice --> Undefined property: stdClass::$age_name C:\xampp\htdocs\codeigniterapps\hris\application\models\Personnel_model.php 73
ERROR - 2021-06-16 17:52:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL
ORDER BY `first_name` ASC
 LIMIT 10' at line 3 - Invalid query: SELECT *
FROM `applicants`
WHERE  IS NULL
ORDER BY `first_name` ASC
 LIMIT 10
ERROR - 2021-06-16 17:53:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL
ORDER BY `first_name` ASC
 LIMIT 10' at line 3 - Invalid query: SELECT *
FROM `applicants`
WHERE  IS NULL
ORDER BY `first_name` ASC
 LIMIT 10
ERROR - 2021-06-16 04:48:26 --> 404 Page Not Found: Ld-tip/index
ERROR - 2021-06-16 04:49:14 --> 404 Page Not Found: Employers/tip
ERROR - 2021-06-16 04:49:18 --> 404 Page Not Found: Employers/tip
ERROR - 2021-06-16 04:49:21 --> 404 Page Not Found: Employers/tip
ERROR - 2021-06-16 04:50:05 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 143
ERROR - 2021-06-16 04:50:08 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 143
ERROR - 2021-06-16 04:50:15 --> 404 Page Not Found: Employers/tip
ERROR - 2021-06-16 04:50:20 --> 404 Page Not Found: Employers/tip
ERROR - 2021-06-16 04:50:23 --> 404 Page Not Found: Employers/tip
ERROR - 2021-06-16 07:09:26 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
ERROR - 2021-06-16 07:09:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
