<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-13 14:30:20 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:31:46 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:31:55 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:32:07 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:33:45 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:35:05 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:35:40 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:36:41 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:39:28 --> 404 Page Not Found: 54990a71663450a4496870f4de5e41402/index
ERROR - 2021-06-13 14:39:30 --> 404 Page Not Found: 54990a71663450a4496870f4de5e41401/index
ERROR - 2021-06-13 14:57:44 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:57:47 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:58:08 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:58:31 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 14:58:38 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 15:01:27 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 15:06:00 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-06-13 15:06:07 --> 404 Page Not Found: Candidates-education/index
ERROR - 2021-06-13 15:06:10 --> 404 Page Not Found: Candidates-work/index
ERROR - 2021-06-13 15:06:20 --> 404 Page Not Found: 4f8a0f94ab7e1ca6d01f29fcc8fc58f0/index
ERROR - 2021-06-13 15:06:24 --> 404 Page Not Found: 4f8a0f94ab7e1ca6d01f29fcc8fc58f0/index
ERROR - 2021-06-13 15:11:43 --> 404 Page Not Found: Candidates-civil/index
ERROR - 2021-06-13 15:14:15 --> 404 Page Not Found: Candidates-family/index
ERROR - 2021-06-13 15:19:06 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Users.php 62
ERROR - 2021-06-13 15:20:03 --> 404 Page Not Found: 6a4e0e051a771d05e9a1f3460ec94fe8/index
ERROR - 2021-06-13 15:20:07 --> 404 Page Not Found: 6a4e0e051a771d05e9a1f3460ec94fe8/index
ERROR - 2021-06-13 15:20:39 --> 404 Page Not Found: 6a4e0e051a771d05e9a1f3460ec94fe8/index
ERROR - 2021-06-13 15:20:43 --> 404 Page Not Found: 6a4e0e051a771d05e9a1f3460ec94fe8/index
ERROR - 2021-06-13 15:20:48 --> 404 Page Not Found: 6a4e0e051a771d05e9a1f3460ec94fe8/index
ERROR - 2021-06-13 15:23:07 --> 404 Page Not Found: Ld-tip/index
ERROR - 2021-06-13 15:23:12 --> 404 Page Not Found: Ld-tip/index
ERROR - 2021-06-13 15:23:33 --> 404 Page Not Found: Ld-ppst/index
ERROR - 2021-06-13 15:26:06 --> 404 Page Not Found: Ld-ppssh/index
ERROR - 2021-06-13 15:33:00 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 596
ERROR - 2021-06-13 15:33:00 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 596
ERROR - 2021-06-13 15:33:06 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 596
ERROR - 2021-06-13 15:33:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 596
ERROR - 2021-06-13 15:34:16 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-06-13 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-06-13 15:38:32 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 10
ERROR - 2021-06-13 15:38:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 10
ERROR - 2021-06-13 15:45:08 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-06-13 15:45:08 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-06-13 15:46:24 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-06-13 15:46:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
