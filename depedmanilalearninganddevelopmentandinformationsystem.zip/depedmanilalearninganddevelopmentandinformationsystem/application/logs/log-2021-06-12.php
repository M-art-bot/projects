<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-12 13:21:42 --> 404 Page Not Found: Employers/index
ERROR - 2021-06-12 13:21:45 --> 404 Page Not Found: Employers/index
ERROR - 2021-06-12 13:21:47 --> 404 Page Not Found: Employers/index
ERROR - 2021-06-12 13:21:54 --> 404 Page Not Found: Employers/index
ERROR - 2021-06-12 13:22:03 --> 404 Page Not Found: Employers/index
ERROR - 2021-06-12 14:00:37 --> Severity: Warning --> Use of undefined constant employers - assumed 'employers' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\forms\login_2.php 103
ERROR - 2021-06-12 14:00:37 --> Severity: Warning --> Use of undefined constant registration - assumed 'registration' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\forms\login_2.php 103
ERROR - 2021-06-12 14:00:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\forms\login_2.php 103
ERROR - 2021-06-12 14:00:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\forms\login_2.php 103
ERROR - 2021-06-12 14:01:01 --> 404 Page Not Found: 99356330151c4903d963791508db67b9/index
ERROR - 2021-06-12 14:07:40 --> 404 Page Not Found: 99356330151c4903d963791508db67b9/index
ERROR - 2021-06-12 14:07:41 --> Severity: error --> Exception: Call to undefined function decrypt() C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\forms\login_2.php 96
ERROR - 2021-06-12 14:07:42 --> Severity: error --> Exception: Call to undefined function decrypt() C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\forms\login_2.php 96
ERROR - 2021-06-12 14:07:50 --> Severity: error --> Exception: Call to undefined function md5_decrypt() C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\forms\login_2.php 96
ERROR - 2021-06-12 14:08:27 --> Severity: error --> Exception: Call to undefined function decryptIt() C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\forms\login_2.php 96
ERROR - 2021-06-12 14:17:01 --> Severity: Compile Error --> Can't use function return value in write context C:\xampp\htdocs\codeigniterapps\hris\application\config\routes.php 11
ERROR - 2021-06-12 14:33:05 --> 404 Page Not Found: Employers/profile
ERROR - 2021-06-12 14:33:14 --> 404 Page Not Found: Employers/profile
ERROR - 2021-06-12 14:35:11 --> 404 Page Not Found: Employers-profile/index
ERROR - 2021-06-12 14:35:12 --> 404 Page Not Found: Employers-login/index
