<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-03 01:04:55 --> Severity: Notice --> Undefined property: Dashboard::$session0 C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:04:55 --> Severity: error --> Exception: Call to a member function userdata() on null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:06:07 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:06:36 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:06:41 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:07:08 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:08:04 --> 404 Page Not Found: Administrative-login/index
ERROR - 2021-05-03 01:08:19 --> 404 Page Not Found: Administrative-login/index
ERROR - 2021-05-03 01:10:36 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:10:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:10:43 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:10:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:12:18 --> Severity: error --> Exception: syntax error, unexpected ')', expecting variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\hris\application\controllers\Dashboard.php 14
ERROR - 2021-05-03 01:12:36 --> Severity: error --> Exception: syntax error, unexpected ')', expecting variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\hris\application\controllers\Dashboard.php 14
ERROR - 2021-05-03 01:12:51 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:12:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:12:51 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 23
ERROR - 2021-05-03 01:12:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 23
ERROR - 2021-05-03 01:13:23 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:13:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:13:23 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 23
ERROR - 2021-05-03 01:13:23 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 23
ERROR - 2021-05-03 01:14:36 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:14:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 01:19:00 --> Severity: Notice --> Undefined property: Dashboard::$Dashboard_model C:\xampp\htdocs\hris\application\controllers\Dashboard.php 18
ERROR - 2021-05-03 01:19:00 --> Severity: error --> Exception: Call to a member function get() on null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 18
ERROR - 2021-05-03 01:19:14 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\hris\application\models\Dashboard_model.php 13
ERROR - 2021-05-03 01:19:14 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 6
ERROR - 2021-05-03 01:19:42 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\hris\application\models\Dashboard_model.php 13
ERROR - 2021-05-03 01:19:42 --> Severity: Notice --> Trying to get property 'username' of non-object C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 6
ERROR - 2021-05-03 01:20:48 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\hris\application\controllers\Dashboard.php 17
ERROR - 2021-05-03 01:21:06 --> Severity: Notice --> Trying to get property 'username' of non-object C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 6
ERROR - 2021-05-03 01:22:26 --> Severity: Notice --> Undefined index: username C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 6
ERROR - 2021-05-03 01:23:44 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\hris\application\views\administrator\panel\dashboard.php 6
ERROR - 2021-05-03 01:42:04 --> Severity: Notice --> Undefined index: system_name C:\xampp\htdocs\hris\application\views\administrator\panel\templates\aside.php 6
ERROR - 2021-05-03 01:56:29 --> Severity: Notice --> Undefined variable: pages C:\xampp\htdocs\hris\application\views\administrator\panel\templates\aside.php 16
ERROR - 2021-05-03 02:01:03 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 02:01:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 08:39:03 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 08:39:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-03 14:49:34 --> 404 Page Not Found: Administrator-das/index
ERROR - 2021-05-03 14:49:37 --> 404 Page Not Found: Administrator-das/assets
ERROR - 2021-05-03 14:50:59 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Recruitment.php 8
ERROR - 2021-05-03 14:50:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Recruitment.php 8
ERROR - 2021-05-03 14:51:01 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Recruitment.php 8
ERROR - 2021-05-03 14:51:01 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Recruitment.php 8
