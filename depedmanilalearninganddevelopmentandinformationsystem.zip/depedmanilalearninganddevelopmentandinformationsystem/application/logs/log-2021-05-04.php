<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-04 01:53:43 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Recruitment.php 8
ERROR - 2021-05-04 01:53:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Recruitment.php 8
ERROR - 2021-05-04 06:26:00 --> 404 Page Not Found: /index
ERROR - 2021-05-04 07:53:28 --> 404 Page Not Found: Person/ajax_add
ERROR - 2021-05-04 08:03:51 --> 404 Page Not Found: Person/ajax_add
ERROR - 2021-05-04 08:04:32 --> 404 Page Not Found: Person/ajax_add
ERROR - 2021-05-04 08:04:50 --> Severity: Compile Error --> Cannot declare class Authentication_model, because the name is already in use C:\xampp\htdocs\hris\application\models\Recruitment_model.php 2
ERROR - 2021-05-04 08:06:52 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:08:03 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:08:46 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:11:49 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:11:52 --> 404 Page Not Found: Recruitment/assets
ERROR - 2021-05-04 08:12:14 --> Severity: error --> Exception: syntax error, unexpected variable "$route" C:\xampp\htdocs\hris\application\config\routes.php 11
ERROR - 2021-05-04 08:12:19 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:12:48 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:12:49 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:12:51 --> Severity: error --> Exception: Unmatched ')' C:\xampp\htdocs\hris\application\views\administrator\panel\recruitment.php 89
ERROR - 2021-05-04 08:12:52 --> Severity: error --> Exception: Unmatched ')' C:\xampp\htdocs\hris\application\views\administrator\panel\recruitment.php 89
ERROR - 2021-05-04 08:13:11 --> 404 Page Not Found: /index
ERROR - 2021-05-04 08:13:30 --> 404 Page Not Found: /index
ERROR - 2021-05-04 08:29:03 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:29:21 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:34:25 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:35:18 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:35:20 --> 404 Page Not Found: Recruitment/assets
ERROR - 2021-05-04 08:35:33 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:35:45 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:21 --> 404 Page Not Found: Recruitment/DA
ERROR - 2021-05-04 08:36:25 --> 404 Page Not Found: Recruitment/DA
ERROR - 2021-05-04 08:36:44 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:44 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:45 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:45 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:45 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:45 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:46 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:46 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:46 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:36:46 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:37:01 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:37:02 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:37:15 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:37:16 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:37:20 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:37:27 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:37:28 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:37:49 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:37:51 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:38:08 --> 404 Page Not Found: Recruitment/ajax_adds
ERROR - 2021-05-04 08:38:14 --> 404 Page Not Found: Recruitment/ajax_adds
ERROR - 2021-05-04 08:38:15 --> 404 Page Not Found: Recruitment/ajax_adds
ERROR - 2021-05-04 08:38:15 --> 404 Page Not Found: Recruitment/ajax_adds
ERROR - 2021-05-04 08:38:16 --> 404 Page Not Found: Recruitment/ajax_adds
ERROR - 2021-05-04 08:38:21 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:38:39 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:38:50 --> 404 Page Not Found: Recruitment/ajax_add
ERROR - 2021-05-04 08:39:54 --> Severity: Warning --> Undefined property: Recruitment::$person C:\xampp\htdocs\hris\application\controllers\Recruitment.php 38
ERROR - 2021-05-04 08:39:54 --> Severity: error --> Exception: Call to a member function save() on null C:\xampp\htdocs\hris\application\controllers\Recruitment.php 38
ERROR - 2021-05-04 08:40:01 --> Severity: Warning --> Undefined property: Recruitment::$person C:\xampp\htdocs\hris\application\controllers\Recruitment.php 38
ERROR - 2021-05-04 08:40:01 --> Severity: error --> Exception: Call to a member function save() on null C:\xampp\htdocs\hris\application\controllers\Recruitment.php 38
ERROR - 2021-05-04 08:40:36 --> Severity: Warning --> Undefined property: Recruitment::$person C:\xampp\htdocs\hris\application\controllers\Recruitment.php 38
ERROR - 2021-05-04 08:40:36 --> Severity: error --> Exception: Call to a member function save() on null C:\xampp\htdocs\hris\application\controllers\Recruitment.php 38
ERROR - 2021-05-04 09:02:54 --> 404 Page Not Found: Person/ajax_list
ERROR - 2021-05-04 09:03:18 --> 404 Page Not Found: Person/ajax_list
ERROR - 2021-05-04 09:03:31 --> 404 Page Not Found: Person/ajax_list
ERROR - 2021-05-04 09:03:33 --> 404 Page Not Found: Person/assets
ERROR - 2021-05-04 09:11:47 --> Severity: error --> Exception: Call to undefined method Recruitment_model::get_datatables_query() C:\xampp\htdocs\hris\application\models\Recruitment_model.php 24
ERROR - 2021-05-04 09:12:00 --> Severity: error --> Exception: Call to undefined method Recruitment_model::get_datatables_query() C:\xampp\htdocs\hris\application\models\Recruitment_model.php 24
ERROR - 2021-05-04 09:14:50 --> Severity: error --> Exception: Call to undefined method Recruitment_model::get_datatables_query() C:\xampp\htdocs\hris\application\models\Recruitment_model.php 24
ERROR - 2021-05-04 09:16:47 --> Severity: error --> Exception: Call to undefined method Recruitment_model::get_datatables_query() C:\xampp\htdocs\hris\application\models\Recruitment_model.php 24
ERROR - 2021-05-04 09:17:23 --> Severity: error --> Exception: Call to undefined method Recruitment_model::get_datatables_query() C:\xampp\htdocs\hris\application\models\Recruitment_model.php 24
ERROR - 2021-05-04 09:17:31 --> Severity: error --> Exception: Call to undefined method Recruitment_model::get_datatables_query() C:\xampp\htdocs\hris\application\models\Recruitment_model.php 24
ERROR - 2021-05-04 09:17:49 --> Severity: error --> Exception: Call to undefined method Recruitment_model::get_datatables_query() C:\xampp\htdocs\hris\application\models\Recruitment_model.php 24
ERROR - 2021-05-04 09:18:26 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:18:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:18:27 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 25
ERROR - 2021-05-04 09:18:27 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 09:18:27 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 09:18:27 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 46
ERROR - 2021-05-04 09:18:27 --> Severity: Warning --> Undefined array key "draw" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 62
ERROR - 2021-05-04 09:18:27 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:18:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:21:42 --> Severity: Warning --> Undefined array key 2 C:\xampp\htdocs\hris\application\models\Recruitment_model.php 61
ERROR - 2021-05-04 09:21:42 --> Severity: Warning --> Undefined array key 2 C:\xampp\htdocs\hris\application\models\Recruitment_model.php 61
ERROR - 2021-05-04 09:36:21 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:21 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 25
ERROR - 2021-05-04 09:36:21 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 09:36:21 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 09:36:21 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 46
ERROR - 2021-05-04 09:36:21 --> Severity: Warning --> Undefined array key "draw" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 62
ERROR - 2021-05-04 09:36:21 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:24 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:24 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 25
ERROR - 2021-05-04 09:36:24 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 09:36:24 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 09:36:24 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 46
ERROR - 2021-05-04 09:36:24 --> Severity: Warning --> Undefined array key "draw" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 62
ERROR - 2021-05-04 09:36:24 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:29 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:29 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 25
ERROR - 2021-05-04 09:36:29 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 09:36:29 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 09:36:29 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 46
ERROR - 2021-05-04 09:36:29 --> Severity: Warning --> Undefined array key "draw" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 62
ERROR - 2021-05-04 09:36:29 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 09:36:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 10:13:07 --> Severity: error --> Exception: syntax error, unexpected token "." C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:13:13 --> Severity: Warning --> Undefined property: stdClass::$caandidates C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:13:14 --> Severity: Warning --> Undefined property: stdClass::$caandidates C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:20:11 --> Query error: Column 'job_id' in order clause is ambiguous - Invalid query: SELECT *
FROM `jobs`
JOIN `applicants` ON `applicants`.`job_id` = `jobs`.`job_id`
ORDER BY `job_id` DESC
 LIMIT 10
ERROR - 2021-05-04 10:20:30 --> Severity: Warning --> Undefined array key "search" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 10:20:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\models\Recruitment_model.php 40
ERROR - 2021-05-04 10:20:31 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 25
ERROR - 2021-05-04 10:20:31 --> Severity: Warning --> Undefined array key "length" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 10:20:31 --> Severity: Warning --> Undefined array key "start" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 26
ERROR - 2021-05-04 10:20:31 --> Query error: Column 'job_id' in order clause is ambiguous - Invalid query: SELECT *
FROM `jobs`
JOIN `applicants` ON `applicants`.`job_id` = `jobs`.`job_id`
ORDER BY `job_id` DESC
ERROR - 2021-05-04 10:20:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\hris\system\core\Exceptions.php:271) C:\xampp\htdocs\hris\system\core\Common.php 570
ERROR - 2021-05-04 10:26:42 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 34
ERROR - 2021-05-04 10:26:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ' job_id) AS Total
FROM `jobs`
JOIN `applicants` ON `applicants`.`job_id` = `j...' at line 1 - Invalid query: SELECT `applicants`.*, `jobs`.*, COUNT(applicants, job_id) AS Total
FROM `jobs`
JOIN `applicants` ON `applicants`.`job_id` = `jobs`.`job_id`
ORDER BY `jobs`.`job_id` DESC
 LIMIT 10
ERROR - 2021-05-04 10:27:41 --> Severity: Warning --> Undefined property: stdClass::$Total C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:27:45 --> Severity: Warning --> Undefined property: stdClass::$Total C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:28:05 --> Severity: Warning --> Undefined property: stdClass::$Total C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:31:18 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 34
ERROR - 2021-05-04 10:33:17 --> Severity: Warning --> Undefined property: stdClass::$total C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:33:17 --> Severity: Warning --> Undefined property: stdClass::$total C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:34:07 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\hris\application\models\Recruitment_model.php 34
ERROR - 2021-05-04 10:34:11 --> Severity: Warning --> Undefined property: stdClass::$total C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:34:11 --> Severity: Warning --> Undefined property: stdClass::$total C:\xampp\htdocs\hris\application\controllers\Recruitment.php 52
ERROR - 2021-05-04 10:47:14 --> Severity: Warning --> Undefined array key "logged_in" C:\xampp\htdocs\hris\application\controllers\Recruitment.php 8
ERROR - 2021-05-04 10:47:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Recruitment.php 8
ERROR - 2021-05-04 10:51:27 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::count_all_result() C:\xampp\htdocs\hris\application\models\Recruitment_model.php 28
ERROR - 2021-05-04 10:52:57 --> Query error: Duplicate column name 'job_id' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM (
SELECT `applicants`.*, `jobs`.*, count(applicants.job_id) as candidates
FROM `jobs`
JOIN `applicants` ON `applicants`.`job_id` = `jobs`.`job_id`
GROUP BY `jobs`.`job_id`
) CI_count_all_results
