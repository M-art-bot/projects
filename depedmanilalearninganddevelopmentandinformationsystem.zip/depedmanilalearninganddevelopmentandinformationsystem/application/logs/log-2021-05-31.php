<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-31 15:52:59 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-05-31 15:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-05-31 15:53:36 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 68
ERROR - 2021-05-31 15:53:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Employers.php 68
ERROR - 2021-05-31 15:57:43 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-05-31 15:57:47 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-05-31 15:58:02 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-05-31 15:58:37 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-05-31 15:58:38 --> 404 Page Not Found: Candidates-dashboard/index
ERROR - 2021-05-31 15:58:39 --> 404 Page Not Found: Welcome/index
