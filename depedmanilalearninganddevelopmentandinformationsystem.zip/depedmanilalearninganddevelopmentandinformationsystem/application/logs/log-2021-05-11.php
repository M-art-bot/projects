ERROR - 2021-05-11 13:10:46 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:11:18 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:12:31 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:12:36 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:12:46 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result_array() C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:12:52 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::row_array() C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:13:05 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:13:24 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:13:28 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:13:48 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:13:53 --> Severity: error --> Exception: Object of class CI_DB_mysqli_result could not be converted to string C:\xampp\htdocs\hris\application\models\Jobs_model.php 69
ERROR - 2021-05-11 13:15:04 --> Severity: Notice --> Undefined index: res_lot_no C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 190
ERROR - 2021-05-11 13:15:04 --> Severity: Notice --> Undefined index: res_street C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 201
ERROR - 2021-05-11 13:15:04 --> Severity: Notice --> Undefined index: res_subdivision C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 212
ERROR - 2021-05-11 13:15:04 --> Severity: Notice --> Undefined index: res_brgy C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 223
ERROR - 2021-05-11 13:15:04 --> Severity: Notice --> Undefined index: res_city C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 234
ERROR - 2021-05-11 13:15:04 --> Severity: Notice --> Undefined index: res_prov C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 245
ERROR - 2021-05-11 13:15:04 --> Severity: Notice --> Undefined index: res_zip C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 256
ERROR - 2021-05-11 13:15:35 --> Severity: Notice --> Undefined index: res_lot_no C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 190
ERROR - 2021-05-11 13:15:35 --> Severity: Notice --> Undefined index: res_street C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 201
ERROR - 2021-05-11 13:15:35 --> Severity: Notice --> Undefined index: res_subdivision C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 212
ERROR - 2021-05-11 13:15:35 --> Severity: Notice --> Undefined index: res_brgy C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 223
ERROR - 2021-05-11 13:15:35 --> Severity: Notice --> Undefined index: res_city C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 234
ERROR - 2021-05-11 13:15:35 --> Severity: Notice --> Undefined index: res_prov C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 245
ERROR - 2021-05-11 13:15:35 --> Severity: Notice --> Undefined index: res_zip C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 256
ERROR - 2021-05-11 13:15:54 --> Severity: Notice --> Undefined index: res_lot_no C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 190
ERROR - 2021-05-11 13:15:54 --> Severity: Notice --> Undefined index: res_street C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 201
ERROR - 2021-05-11 13:15:54 --> Severity: Notice --> Undefined index: res_subdivision C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 212
ERROR - 2021-05-11 13:15:54 --> Severity: Notice --> Undefined index: res_brgy C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 223
ERROR - 2021-05-11 13:15:54 --> Severity: Notice --> Undefined index: res_city C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 234
ERROR - 2021-05-11 13:15:54 --> Severity: Notice --> Undefined index: res_prov C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 245
ERROR - 2021-05-11 13:15:54 --> Severity: Notice --> Undefined index: res_zip C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 256
ERROR - 2021-05-11 13:16:13 --> Severity: Notice --> Undefined index: res_lot_no C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 192
ERROR - 2021-05-11 13:16:13 --> Severity: Notice --> Undefined index: res_street C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 203
ERROR - 2021-05-11 13:16:13 --> Severity: Notice --> Undefined index: res_subdivision C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 214
ERROR - 2021-05-11 13:16:13 --> Severity: Notice --> Undefined index: res_brgy C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 225
ERROR - 2021-05-11 13:16:13 --> Severity: Notice --> Undefined index: res_city C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 236
ERROR - 2021-05-11 13:16:13 --> Severity: Notice --> Undefined index: res_prov C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 247
ERROR - 2021-05-11 13:16:13 --> Severity: Notice --> Undefined index: res_zip C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 258
ERROR - 2021-05-11 13:16:27 --> Severity: Notice --> Undefined index: res_lot_no C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 192
ERROR - 2021-05-11 13:16:27 --> Severity: Notice --> Undefined index: res_street C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 203
ERROR - 2021-05-11 13:16:27 --> Severity: Notice --> Undefined index: res_subdivision C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 214
ERROR - 2021-05-11 13:16:27 --> Severity: Notice --> Undefined index: res_brgy C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 225
ERROR - 2021-05-11 13:16:27 --> Severity: Notice --> Undefined index: res_city C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 236
ERROR - 2021-05-11 13:16:27 --> Severity: Notice --> Undefined index: res_prov C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 247
ERROR - 2021-05-11 13:16:27 --> Severity: Notice --> Undefined index: res_zip C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 258
ERROR - 2021-05-11 13:16:40 --> Severity: Notice --> Undefined index: res_lot_no C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 192
ERROR - 2021-05-11 13:16:40 --> Severity: Notice --> Undefined index: res_street C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 203
ERROR - 2021-05-11 13:16:40 --> Severity: Notice --> Undefined index: res_subdivision C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 214
ERROR - 2021-05-11 13:16:40 --> Severity: Notice --> Undefined index: res_brgy C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 225
ERROR - 2021-05-11 13:16:40 --> Severity: Notice --> Undefined index: res_city C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 236
ERROR - 2021-05-11 13:16:40 --> Severity: Notice --> Undefined index: res_prov C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 247
ERROR - 2021-05-11 13:16:40 --> Severity: Notice --> Undefined index: res_zip C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 258
ERROR - 2021-05-11 14:11:42 --> Severity: Compile Error --> Cannot redeclare Info_model::update_info() C:\xampp\htdocs\hris\application\models\Info_model.php 18
ERROR - 2021-05-11 14:13:01 --> 404 Page Not Found: Info/residential_update
ERROR - 2021-05-11 14:13:58 --> Query error: Unknown column 'res_steet' in 'field list' - Invalid query: UPDATE `residential_address` SET `res_lot_no` = NULL, `res_steet` = NULL, `res_subdivision` = NULL, `res_brgy` = NULL, `res_city` = NULL, `res_prov` = NULL, `res_zip` = NULL, `res_id` = '1'
WHERE `res_id` = '1'
ERROR - 2021-05-11 14:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 195
ERROR - 2021-05-11 14:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 201
ERROR - 2021-05-11 14:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 212
ERROR - 2021-05-11 14:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 223
ERROR - 2021-05-11 14:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 234
ERROR - 2021-05-11 14:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 245
ERROR - 2021-05-11 14:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 256
ERROR - 2021-05-11 14:17:17 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 267
ERROR - 2021-05-11 14:21:29 --> Severity: Notice --> Undefined variable: candidates C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 284
ERROR - 2021-05-11 14:21:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 284
ERROR - 2021-05-11 14:30:41 --> Severity: Notice --> Undefined index: res_id C:\xampp\htdocs\hris\application\models\Info_model.php 20
ERROR - 2021-05-11 14:32:51 --> Severity: Notice --> Undefined index: res_id C:\xampp\htdocs\hris\application\models\Info_model.php 20
ERROR - 2021-05-11 14:35:00 --> Severity: error --> Exception: Call to undefined method Info_model::add_res() C:\xampp\htdocs\hris\application\controllers\Info.php 67
ERROR - 2021-05-11 14:45:07 --> Query error: Table 'hris.permanent_address' doesn't exist - Invalid query: SELECT *
FROM `permanent_address`
WHERE `applicant_id` = '16'
 LIMIT 1
ERROR - 2021-05-11 14:51:13 --> Severity: Notice --> Undefined variable: add_res_information C:\xampp\htdocs\hris\application\controllers\Info.php 113
ERROR - 2021-05-11 14:51:33 --> Query error: Unknown column 'per_lot_no' in 'field list' - Invalid query: INSERT INTO `residential_address` (`per_lot_no`, `per_street`, `per_subdivision`, `per_brgy`, `per_city`, `per_prov`, `per_zip`, `applicant_id`) VALUES ('289', 'E. CASTILLO ST.', 'MAYPAJO', '31', 'CALOOCAN CITY', 'NCR', '1014', '16')
ERROR - 2021-05-11 14:57:01 --> Severity: Notice --> Undefined index: telephone_no C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 96
ERROR - 2021-05-11 14:57:01 --> Severity: Notice --> Undefined index: mobile_no C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 107
