<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-10 03:46:34 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-06-10 03:46:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-06-10 03:46:35 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
ERROR - 2021-06-10 03:46:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 39
