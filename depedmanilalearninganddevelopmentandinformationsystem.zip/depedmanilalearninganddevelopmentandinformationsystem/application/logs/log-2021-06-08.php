ERROR - 2021-06-08 11:52:25 --> Severity: Notice --> Undefined index: ld C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 205
ERROR - 2021-06-08 11:52:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Jobs.php 205
