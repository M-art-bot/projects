ERROR - 2021-05-07 15:23:29 --> 404 Page Not Found: Authentication/assets
ERROR - 2021-05-07 15:27:25 --> 404 Page Not Found: Authentication/register
ERROR - 2021-05-07 15:29:22 --> Query error: Table 'hris.candidates' doesn't exist - Invalid query: SELECT *
FROM `candidates`
WHERE `candidate_email_address` = 'dada@yahoo.com'
ERROR - 2021-05-07 15:46:52 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\hris\application\controllers\Authentication.php 32
ERROR - 2021-05-07 15:47:11 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\hris\application\controllers\Authentication.php 32
ERROR - 2021-05-07 15:47:30 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ')' C:\xampp\htdocs\hris\application\models\Users_model.php 22
ERROR - 2021-05-07 15:47:49 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp\htdocs\hris\application\controllers\Authentication.php 27
ERROR - 2021-05-07 15:48:01 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ')' C:\xampp\htdocs\hris\application\models\Users_model.php 22
ERROR - 2021-05-07 15:48:14 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ')' C:\xampp\htdocs\hris\application\models\Users_model.php 22
ERROR - 2021-05-07 15:48:21 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ')' C:\xampp\htdocs\hris\application\models\Users_model.php 22
ERROR - 2021-05-07 15:48:38 --> 404 Page Not Found: Authentication/register
ERROR - 2021-05-07 15:48:43 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ')' C:\xampp\htdocs\hris\application\models\Users_model.php 22
ERROR - 2021-05-07 15:50:12 --> 404 Page Not Found: Authentication/register
ERROR - 2021-05-07 15:53:25 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\hris\application\controllers\Authentication.php 11
ERROR - 2021-05-07 15:53:56 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\hris\application\controllers\Authentication.php 11
ERROR - 2021-05-07 15:54:04 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\hris\application\controllers\Authentication.php 11
ERROR - 2021-05-07 15:55:18 --> 404 Page Not Found: Authentication/register
ERROR - 2021-05-07 15:56:06 --> 404 Page Not Found: Authentication/register
ERROR - 2021-05-07 15:56:08 --> 404 Page Not Found: Authentication/assets
ERROR - 2021-05-07 15:57:06 --> Severity: 8192 --> Methods with the same name as their class will not be constructors in a future version of PHP; Authentication has a deprecated constructor C:\xampp\htdocs\hris\application\controllers\Authentication.php 3
ERROR - 2021-05-07 15:57:06 --> 404 Page Not Found: Authentication/register
