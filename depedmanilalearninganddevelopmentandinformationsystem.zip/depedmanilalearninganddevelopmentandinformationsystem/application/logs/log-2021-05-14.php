ERROR - 2021-05-14 16:25:42 --> Query error: Column 'position_title' cannot be null - Invalid query: INSERT INTO `jobs` (`position_title`, `item_no`, `pay_grade`, `salary`, `education`, `training`, `experience`, `eligibility`, `place_of_assignment`, `is_active`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2021-05-14 16:25:46 --> Query error: Column 'position_title' cannot be null - Invalid query: INSERT INTO `jobs` (`position_title`, `item_no`, `pay_grade`, `salary`, `education`, `training`, `experience`, `eligibility`, `place_of_assignment`, `is_active`) VALUES (NULL, '**************', 'SG', '2', '12,000', 'N/A', 'BACHELORS DEGREE RELEVANT TO THE JOB', 'Career Service (Professional) Second Level Eligibility', 'Division of City Schools', '1')
ERROR - 2021-05-14 16:26:18 --> Query error: Column 'position_title' cannot be null - Invalid query: INSERT INTO `jobs` (`position_title`, `item_no`, `pay_grade`, `salary`, `education`, `training`, `experience`, `eligibility`, `place_of_assignment`, `is_active`) VALUES (NULL, '**************', 'SG', '2', '12,000', 'N/A', 'BACHELORS DEGREE RELEVANT TO THE JOB', 'Career Service (Professional) Second Level Eligibility', 'Division of City Schools', '1')
ERROR - 2021-05-14 17:01:19 --> Severity: error --> Exception: Call to undefined method Jobs_model::get_datatables() C:\xampp\htdocs\hris\application\controllers\Jobs.php 349
ERROR - 2021-05-14 17:01:25 --> Severity: error --> Exception: Call to undefined method Jobs_model::get_datatables() C:\xampp\htdocs\hris\application\controllers\Jobs.php 349
ERROR - 2021-05-14 17:02:51 --> Severity: error --> Exception: Call to undefined method Jobs_model::get_datatables() C:\xampp\htdocs\hris\application\controllers\Jobs.php 349
ERROR - 2021-05-14 17:02:58 --> Severity: error --> Exception: Call to undefined method Jobs_model::get_datatables() C:\xampp\htdocs\hris\application\controllers\Jobs.php 349
ERROR - 2021-05-14 17:03:24 --> Severity: error --> Exception: Call to undefined method Jobs_model::get_datatables() C:\xampp\htdocs\hris\application\controllers\Jobs.php 349
ERROR - 2021-05-14 17:07:57 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\hris\application\controllers\Jobs.php 361
ERROR - 2021-05-14 17:13:56 --> Query error: Unknown column 'posution_title' in 'where clause' - Invalid query: SELECT *
FROM `jobs`
WHERE   (
`posution_title` LIKE '%d%' ESCAPE '!'
 )
ORDER BY `job_id` DESC
 LIMIT 10
ERROR - 2021-05-14 17:13:59 --> Query error: Unknown column 'posution_title' in 'where clause' - Invalid query: SELECT *
FROM `jobs`
WHERE   (
`posution_title` LIKE '%da%' ESCAPE '!'
 )
ORDER BY `job_id` DESC
 LIMIT 10
ERROR - 2021-05-14 17:22:56 --> Severity: Notice --> Undefined property: stdClass::$job_title C:\xampp\htdocs\hris\application\controllers\Recruitment.php 60
