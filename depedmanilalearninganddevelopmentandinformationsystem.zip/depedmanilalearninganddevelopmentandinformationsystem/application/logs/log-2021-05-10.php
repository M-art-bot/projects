ERROR - 2021-05-10 05:35:04 --> Severity: Notice --> Undefined variable: email_address C:\xampp\htdocs\hris\application\models\Jobs_model.php 59
ERROR - 2021-05-10 05:35:04 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `email_address` = ''
 LIMIT 1
ERROR - 2021-05-10 05:35:24 --> Severity: Notice --> Undefined variable: email_address C:\xampp\htdocs\hris\application\models\Jobs_model.php 59
ERROR - 2021-05-10 05:35:24 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `email_address` = ''
 LIMIT 1
ERROR - 2021-05-10 05:35:50 --> Severity: Notice --> Undefined variable: email_address C:\xampp\htdocs\hris\application\models\Jobs_model.php 59
ERROR - 2021-05-10 05:36:04 --> Severity: Notice --> Undefined variable: email_address C:\xampp\htdocs\hris\application\models\Jobs_model.php 59
ERROR - 2021-05-10 05:36:45 --> 404 Page Not Found: Jobs/dashboard
ERROR - 2021-05-10 05:37:44 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\hris\application\controllers\Jobs.php 89
ERROR - 2021-05-10 05:37:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Jobs.php 89
ERROR - 2021-05-10 05:38:09 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\hris\application\controllers\Jobs.php 89
ERROR - 2021-05-10 05:38:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Jobs.php 89
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 111
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 128
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 128
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 128
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 128
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 128
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 128
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 128
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 128
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 128
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Trying to access array offset on value of type bool C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 210
ERROR - 2021-05-10 05:46:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 210
ERROR - 2021-05-10 06:27:50 --> Severity: Notice --> Undefined index: username C:\xampp\htdocs\hris\application\views\vacancy\navbar.php 25
ERROR - 2021-05-10 07:02:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Candidates_model_2 C:\xampp\htdocs\hris\system\core\Loader.php 348
ERROR - 2021-05-10 07:10:46 --> Severity: Notice --> Undefined variable: jobs C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 6
ERROR - 2021-05-10 07:10:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 6
ERROR - 2021-05-10 07:11:37 --> Severity: Notice --> Undefined variable: jobs C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 6
ERROR - 2021-05-10 07:11:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\dashboard.php 6
ERROR - 2021-05-10 13:04:51 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-10 13:04:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Dashboard.php 9
ERROR - 2021-05-10 13:05:26 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\hris\application\controllers\Personnel.php 9
ERROR - 2021-05-10 13:05:26 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Personnel.php 9
