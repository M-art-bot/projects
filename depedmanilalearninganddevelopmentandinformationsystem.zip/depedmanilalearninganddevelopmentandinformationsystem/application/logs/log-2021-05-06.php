ERROR - 2021-05-06 17:02:59 --> Severity: Notice --> Undefined property: Enlists::$table C:\xampp\htdocs\hris\system\core\Model.php 73
ERROR - 2021-05-06 17:02:59 --> Severity: Notice --> Undefined property: Enlists::$column_search C:\xampp\htdocs\hris\system\core\Model.php 73
ERROR - 2021-05-06 17:02:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hris\application\models\Enlists_model.php 45
ERROR - 2021-05-06 17:02:59 --> Query error: No tables used - Invalid query: SELECT *
WHERE `job_id` = '1'
AND `action_id` = '1'
 LIMIT 10
ERROR - 2021-05-06 17:03:26 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting ';' or ',' C:\xampp\htdocs\hris\application\models\Enlists_model.php 18
ERROR - 2021-05-06 17:13:55 --> Severity: error --> Exception: syntax error, unexpected '$query' (T_VARIABLE) C:\xampp\htdocs\hris\application\models\Move_model.php 31
ERROR - 2021-05-06 17:14:01 --> Severity: error --> Exception: Too few arguments to function Move_model::get_alls(), 0 passed in C:\xampp\htdocs\hris\application\controllers\Enlists.php on line 27 and exactly 1 expected C:\xampp\htdocs\hris\application\models\Move_model.php 24
ERROR - 2021-05-06 17:14:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:14:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:14:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:14:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:14:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:14:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:14:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:14:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:14:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:49 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:49 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:49 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:49 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:49 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:49 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:49 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:49 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:49 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:54 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:54 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:54 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:54 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:54 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:54 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:54 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:54 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:15:54 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:03 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:03 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:03 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:03 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:03 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:03 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:03 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:03 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:03 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:16:19 --> Severity: Notice --> Undefined variable: val C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 87
ERROR - 2021-05-06 17:30:34 --> Severity: error --> Exception: syntax error, unexpected 'job_id' (T_STRING), expecting ';' or ',' C:\xampp\htdocs\hris\application\views\administrator\panel\candidates.php 88
ERROR - 2021-05-06 17:57:57 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 75
ERROR - 2021-05-06 17:58:16 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 75
ERROR - 2021-05-06 17:59:39 --> Severity: error --> Exception: syntax error, unexpected ']' C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 75
ERROR - 2021-05-06 18:02:12 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ';' or ',' C:\xampp\htdocs\hris\application\views\administrator\panel\enlists.php 75
