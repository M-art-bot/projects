ERROR - 2021-05-13 19:09:41 --> Severity: Notice --> Undefined variable: order_data C:\xampp\htdocs\hris\application\views\vacancy\civil.php 172
ERROR - 2021-05-13 19:09:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\vacancy\civil.php 172
ERROR - 2021-05-13 19:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hris\application\views\vacancy\civil.php 172
ERROR - 2021-05-13 19:41:13 --> Severity: Notice --> Undefined index: career_service C:\xampp\htdocs\hris\application\views\vacancy\civil.php 190
ERROR - 2021-05-13 19:41:13 --> Severity: Notice --> Undefined index: career_service C:\xampp\htdocs\hris\application\views\vacancy\civil.php 191
ERROR - 2021-05-13 19:41:13 --> Severity: Notice --> Undefined index: career_service C:\xampp\htdocs\hris\application\views\vacancy\civil.php 190
ERROR - 2021-05-13 19:41:13 --> Severity: Notice --> Undefined index: career_service C:\xampp\htdocs\hris\application\views\vacancy\civil.php 191
ERROR - 2021-05-13 19:41:13 --> Severity: Notice --> Undefined index: career_service C:\xampp\htdocs\hris\application\views\vacancy\civil.php 190
ERROR - 2021-05-13 19:41:13 --> Severity: Notice --> Undefined index: career_service C:\xampp\htdocs\hris\application\views\vacancy\civil.php 191
ERROR - 2021-05-13 19:44:00 --> 404 Page Not Found: Info/civil_update
ERROR - 2021-05-13 19:44:02 --> 404 Page Not Found: Info/assets
ERROR - 2021-05-13 23:52:59 --> Severity: Notice --> Undefined index: logged_in_user C:\xampp\htdocs\hris\application\controllers\Jobs.php 222
ERROR - 2021-05-13 23:52:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\controllers\Jobs.php 222
