ERROR - 2021-06-07 09:38:20 --> Query error: Unknown column 'activities.module_id' in 'on clause' - Invalid query: SELECT *
FROM `applicants`
JOIN `modules` ON `activities`.`module_id`=`modules`.`module_id`
JOIN `categories` ON `categories`.`category_id`=`modules`.`category_id`
JOIN `activities` ON `applicants`.`applicant_id`=`activities`.`applicant_id`
JOIN `jobs` ON `jobs`.`job_id`=`applicants`.`job_id`
JOIN `schools` ON `schools`.`school_id`=`applicants`.`school_id`
ORDER BY `activities`.`module_id` DESC
 LIMIT 10
ERROR - 2021-06-07 09:39:05 --> Severity: error --> Exception: syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\codeigniterapps\hris\application\models\Activities_model.php 23
ERROR - 2021-06-07 09:50:39 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\panel\dashboard.php 68
ERROR - 2021-06-07 09:50:49 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\panel\dashboard.php 68
ERROR - 2021-06-07 09:50:50 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\panel\dashboard.php 68
ERROR - 2021-06-07 09:50:51 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\xampp\htdocs\codeigniterapps\hris\application\views\administrator\panel\dashboard.php 68
