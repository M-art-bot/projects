ERROR - 2021-06-06 11:03:26 --> Severity: Notice --> Undefined variable: candidate C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Personnel.php 105
ERROR - 2021-06-06 11:03:26 --> Severity: Notice --> Trying to get property 'vw' of non-object C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Personnel.php 105
ERROR - 2021-06-06 11:27:18 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Info.php 10
ERROR - 2021-06-06 11:39:04 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting '(' C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Personnel.php 111
ERROR - 2021-06-06 12:29:26 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 227
ERROR - 2021-06-06 13:46:47 --> Severity: error --> Exception: Call to undefined method Info_model::update_civil_informations() C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Info.php 317
ERROR - 2021-06-06 13:51:25 --> Severity: Notice --> Undefined variable: count_product C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 186
ERROR - 2021-06-06 13:51:25 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 197
ERROR - 2021-06-06 13:51:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 197
ERROR - 2021-06-06 13:51:25 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 198
ERROR - 2021-06-06 13:51:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 198
ERROR - 2021-06-06 13:51:25 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 199
ERROR - 2021-06-06 13:51:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 199
ERROR - 2021-06-06 13:51:25 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 200
ERROR - 2021-06-06 13:51:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 200
ERROR - 2021-06-06 13:51:25 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 201
ERROR - 2021-06-06 13:51:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 201
ERROR - 2021-06-06 13:51:25 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 202
ERROR - 2021-06-06 13:51:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 202
ERROR - 2021-06-06 13:51:25 --> Query error: Unknown column 'civil_service' in 'field list' - Invalid query: INSERT INTO `work_experiences` (`civil_service`, `rating`, `date_of_examination`, `place_of_examination`, `license_number`, `date_of_validity`, `applicant_id`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, '1')
ERROR - 2021-06-06 13:51:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\codeigniterapps\hris\system\core\Exceptions.php:271) C:\xampp\htdocs\codeigniterapps\hris\system\core\Common.php 570
ERROR - 2021-06-06 13:51:43 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 199
ERROR - 2021-06-06 13:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 199
ERROR - 2021-06-06 13:51:43 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 200
ERROR - 2021-06-06 13:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 200
ERROR - 2021-06-06 13:51:43 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 201
ERROR - 2021-06-06 13:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 201
ERROR - 2021-06-06 13:51:43 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 202
ERROR - 2021-06-06 13:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 202
ERROR - 2021-06-06 13:51:43 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 203
ERROR - 2021-06-06 13:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 203
ERROR - 2021-06-06 13:51:43 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 204
ERROR - 2021-06-06 13:51:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 204
ERROR - 2021-06-06 13:51:43 --> Query error: Unknown column 'civil_service' in 'field list' - Invalid query: INSERT INTO `work_experiences` (`civil_service`, `rating`, `date_of_examination`, `place_of_examination`, `license_number`, `date_of_validity`, `applicant_id`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, '1')
ERROR - 2021-06-06 13:51:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\codeigniterapps\hris\system\core\Exceptions.php:271) C:\xampp\htdocs\codeigniterapps\hris\system\core\Common.php 570
ERROR - 2021-06-06 13:52:09 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 200
ERROR - 2021-06-06 13:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 200
ERROR - 2021-06-06 13:52:09 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 201
ERROR - 2021-06-06 13:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 201
ERROR - 2021-06-06 13:52:09 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 202
ERROR - 2021-06-06 13:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 202
ERROR - 2021-06-06 13:52:09 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 203
ERROR - 2021-06-06 13:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 203
ERROR - 2021-06-06 13:52:09 --> Severity: Warning --> strtoupper() expects parameter 1 to be string, array given C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 204
ERROR - 2021-06-06 13:52:09 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 204
ERROR - 2021-06-06 13:52:09 --> Query error: Unknown column 'civil_service' in 'field list' - Invalid query: INSERT INTO `work_experiences` (`civil_service`, `rating`, `date_of_examination`, `place_of_examination`, `license_number`, `date_of_validity`, `applicant_id`) VALUES ('N/A', NULL, NULL, NULL, NULL, NULL, '1')
ERROR - 2021-06-06 13:52:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\codeigniterapps\hris\system\core\Exceptions.php:271) C:\xampp\htdocs\codeigniterapps\hris\system\core\Common.php 570
ERROR - 2021-06-06 13:52:30 --> Query error: Unknown column 'civil_service' in 'field list' - Invalid query: INSERT INTO `work_experiences` (`civil_service`, `rating`, `date_of_examination`, `place_of_examination`, `license_number`, `date_of_validity`, `applicant_id`) VALUES ('N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', '1')
ERROR - 2021-06-06 14:11:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 363
ERROR - 2021-06-06 14:12:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\codeigniterapps\hris\application\models\Info_model.php 363
ERROR - 2021-06-06 14:13:59 --> Severity: Notice --> Undefined index: order_item C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\ld.php 171
ERROR - 2021-06-06 14:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\codeigniterapps\hris\application\views\vacancy\ld.php 171
