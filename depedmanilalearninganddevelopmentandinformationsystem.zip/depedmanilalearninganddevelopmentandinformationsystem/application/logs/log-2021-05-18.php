<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-18 16:22:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'rrpoultr_igni408'@'localhost' (using password: YES) C:\xampp\htdocs\hris\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-05-18 16:22:52 --> Unable to connect to the database
ERROR - 2021-05-18 17:56:51 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\hris\application\views\administrator\forms\login_2.php 19
ERROR - 2021-05-18 17:56:51 --> Severity: Notice --> Undefined variable: credentials C:\xampp\htdocs\hris\application\views\administrator\forms\login_2.php 35
ERROR - 2021-05-18 17:56:51 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\hris\application\views\administrator\forms\login_2.php 35
