<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-15 07:31:35 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
ERROR - 2021-06-15 07:31:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
ERROR - 2021-06-15 07:34:50 --> Query error: Unknown column 'applicants.firstname' in 'order clause' - Invalid query: SELECT applicants.*, jobs.*, schools.*, count(ld.applicant_id) as total
FROM `applicants`
JOIN `jobs` ON `jobs`.`job_id` = `applicants`.`job_id`
LEFT JOIN `ld` ON `ld`.`applicant_id`=`applicants`.`applicant_id`
JOIN `schools` ON `schools`.`school_id` = `applicants`.`school_id`
WHERE `jobs`.`job_category_id` = 1
GROUP BY `applicants`.`applicant_id`
ORDER BY `applicants`.`firstname` ASC
 LIMIT 10
ERROR - 2021-06-15 08:11:07 --> Severity: Notice --> Undefined property: stdClass::$age C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 53
ERROR - 2021-06-15 08:11:07 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::result() C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 58
ERROR - 2021-06-15 08:14:30 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$age C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 56
ERROR - 2021-06-15 08:14:30 --> Severity: Notice --> Undefined variable: data4 C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 69
ERROR - 2021-06-15 08:21:32 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 59
ERROR - 2021-06-15 08:21:32 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 59
ERROR - 2021-06-15 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 59
ERROR - 2021-06-15 08:21:44 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 59
ERROR - 2021-06-15 08:24:08 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Dashboard.php 59
ERROR - 2021-06-15 09:46:17 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
ERROR - 2021-06-15 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
ERROR - 2021-06-15 10:09:21 --> 404 Page Not Found: Ld-tip/index
ERROR - 2021-06-15 10:54:54 --> Severity: Notice --> Undefined index: logged_in C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
ERROR - 2021-06-15 10:54:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\codeigniterapps\hris\application\controllers\Applications.php 40
ERROR - 2021-06-15 11:05:56 --> 404 Page Not Found: Ld-tip/index
