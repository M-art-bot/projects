<?php
	
	class Dashboard_model extends CI_Model
	{
		
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
		}

		public function get($user_id){
			$condition = "user_id =" . "'" . $user_id . "'";

			$this->db->select('*');
			$this->db->from('users');
			$this->db->where($condition);
			$this->db->limit(1);
			$query = $this->db->get();

			if ($query->num_rows() == 1) {
			return $query->row_array();
			} else {
			return false;
			}
			
		}

		public function count_users(){
			$this->db->from('applicants');
	        return $this->db->count_all_results();
			
		}

		public function count_teaching(){
			$this->db->from('jobs');
			$this->db->join('applicants', 'applicants.job_id=jobs.job_id');
			$this->db->where('job_category_id', 1);
	        return $this->db->count_all_results();
			
		}

		public function count_non_teaching(){
			$this->db->from('jobs');
			$this->db->join('applicants', 'applicants.job_id=jobs.job_id');
			$this->db->where('job_category_id', 2);
	        return $this->db->count_all_results();
			
		}

		public function submitted(){
		   	$this->db->select('activities.*');
        	$this->db->from('activities');
	    
	        $query = $this->db->get();
	        return $query->result_array();
			
		}

		public function position(){
			$this->db->select('* , count("job_id") as position');
			$this->db->from('jobs');
			$query = $this->db->get();	
			return $query->result_array();
		}
		// public function count_position(){
		// 	$this->db->select('*');
			// $this->db->join('jobs', 'applicants.job_id =jobs.job_id');
		//     $q=$this->db->get('schools');
		//     $count=$q->result();
		//     return count($count);
		// }


		public function count_jobs(){
			$this->db->select('*');
			$this->db->join('jobs', 'applicants.job_id = jobs.job_id');
		    $q=$this->db->get('applicants');
		    $count=$q->result();
		    return count($count);
			
		}

		public function getss(){
			$query = $this->db->select('*, count("activities.module_id") as count')->from('schools')->join('applicants','applicants.school_id=schools.school_id')->join('activities','applicants.applicant_id=activities.applicant_id')->group_by('applicants.school_id')->get();
		 
		      $record = $query->result();
		      $data = [];
		 
		      foreach($record as $row) {
		            $data['label'][] = $row->school_name;
		            $data['data'][] = (int) $row->count;
		      }
		     $data['chart_data'] = json_encode($data);
		}

	}


?>