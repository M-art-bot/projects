<?php
	
	class Administrator_model extends CI_Model
	{
		
		public function __construct()
		{
			parent::__construct();
		}

		public function login(){

		}

		public function logout(){
			
		}
	}


?>