<?php 
    
    class Info_model extends CI_Model
	{
		
		public function __construct()
		{
			$this->load->database();
	

	
		}

		public function update_info($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}

		public function fam($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}

		public function res($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}

		public function per($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}

		public function educ($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}

		public function other($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}

		public function civil($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}


		public function vw($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}

		public function work($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}


		public function highest($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}


		public function ld($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}


		public function other_2($data){

			$this->db->where('applicant_id', $data['applicant_id']);
			$this->db->update('applicants', $data);
	        return $this->db->affected_rows();
		}


		public function update_res($data){

			$this->db->where('res_id', $data['res_id']);
			$this->db->update('residential_address', $data);
	        return $this->db->affected_rows();
		}

		public function add_res($data)
	    {
	        $this->db->insert('residential_address', $data);
	        return $this->db->insert_id();
	    }

	    public function update_educ($data){

			$this->db->where('educational_backgrounds_id', $data['educational_backgrounds_id']);
			$this->db->update('educational_backgrounds', $data);
	        return $this->db->affected_rows();
		}

		public function add_educ($data)
	    {
	        $this->db->insert('educational_backgrounds', $data);
	        return $this->db->insert_id();
	    }

	    public function update_family($data){

			$this->db->where('family_id', $data['family_id']);
			$this->db->update('family_background', $data);
	        return $this->db->affected_rows();
		}

		public function add_family($data)
	    {
	        $this->db->insert('family_background', $data);
	        return $this->db->insert_id();
	    }

	    public function update_per($data){

			$this->db->where('per_id', $data['per_id']);
			$this->db->update('permanent_address', $data);
	        return $this->db->affected_rows();
		}

		public function add_per($data)
	    {
	        $this->db->insert('permanent_address', $data);
	        return $this->db->insert_id();
	    }

     	public function update_personal_informations($data){

			$this->db->where('personal_id', $data['personal_id']);
			$this->db->update('personal_informations', $data);
	        return $this->db->affected_rows();
		}

		public function add_personal_informations($data)
	    {
	        $this->db->insert('personal_informations', $data);
	        return $this->db->insert_id();
	    }

	    public function add_civil_informations($data = null)
	    {
	        $count_product = count($this->input->post('career_service'));

			for($x = 0; $x < $count_product; $x++) {

				$items = array(
							'civil_service' => strtoupper($this->input->post('career_service')[$x]),
							'rating' => strtoupper($this->input->post('rating')[$x]),
							'date_of_examination' => strtoupper($this->input->post('date_of_examination')[$x]),
							'place_of_examination' => strtoupper($this->input->post('place_of_examination')[$x]),
							'license_number' => strtoupper($this->input->post('license_number')[$x]),
							'date_of_validity' => strtoupper($this->input->post('date_of_validity')[$x]),
							'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
						);
			$update_fam              = array('csc' => 1, 'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']);
			$this->Info_model->civil($update_fam);

			$this->db->insert('civil_service_eligibility', $items);
				}

			return true;
	    }

	    public function update_civil_informations($data = null)
	    {	

	    	 $count_product = count($this->input->post('career_service'));

			if($count_product)
				{
					$this->db->where('applicant_id', $this->session->userdata['logged_in_user']['applicant_id']);
					$this->db->delete('civil_service_eligibility');
				}

	        $count_product = count($this->input->post('career_service'));

			for($x = 0; $x < $count_product; $x++) {

				$items = array(
							'civil_service' => strtoupper($this->input->post('career_service')[$x]),
							'rating' => strtoupper($this->input->post('rating')[$x]),
							'date_of_examination' => strtoupper($this->input->post('date_of_examination')[$x]),
							'place_of_examination' => strtoupper($this->input->post('place_of_examination')[$x]),
							'license_number' => strtoupper($this->input->post('license_number')[$x]),
							'date_of_validity' => strtoupper($this->input->post('date_of_validity')[$x]),
							'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
						);
					$this->db->insert('civil_service_eligibility', $items);
				}

			return true;
			


		}

	     public function add_work_informations($data = null)
	    {
	        $count_product = count($this->input->post('position_title'));

			for($x = 0; $x < $count_product; $x++) {

				$items = array(
							'position_title' => strtoupper($this->input->post('position_title')[$x]),
							'date_start' => strtoupper($this->input->post('date_start')[$x]),
							'date_end' => strtoupper($this->input->post('date_end')[$x]),
							'company' => strtoupper($this->input->post('company')[$x]),
							'monthly_salary' => strtoupper($this->input->post('monthly_salary')[$x]),
							'pay_grade' => strtoupper($this->input->post('pay_grade')[$x]),
							'status' => strtoupper($this->input->post('status')[$x]),
							'is_gov' => strtoupper($this->input->post('is_gov')[$x]),
							'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
						);

			$update_fam              = array('work' => 1, 'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']);
			$this->Info_model->work($update_fam);

			$this->db->insert('work_experiences', $items);
				}

			return true;
	    }

	     public function add_highest_informations($data = null)
	    {
	        $count_product = count($this->input->post('grad_name'));

			for($x = 0; $x < $count_product; $x++) {

				$items = array(
							'grad_name' => strtoupper($this->input->post('grad_name')[$x]),
							'grad_course' => strtoupper($this->input->post('grad_course')[$x]),
							'grad_year' => strtoupper($this->input->post('grad_year')[$x]),
							'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
						);

			$update_highest             = array('highest_id' => 1, 'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']);
			$this->Info_model->highest($update_highest);

			$this->db->insert('highest', $items);
				}

			return true;
	    }

	     public function update_highest_informations($data = null)
	    {	
    	  	$count_product = count($this->input->post('grad_name'));


	       if($count_product)
				{
					$this->db->where('applicant_id', $this->session->userdata['logged_in_user']['applicant_id']);
					$this->db->delete('highest');

					for($x = 0; $x < $count_product; $x++) {

						$items = array(
									'grad_name' => strtoupper($this->input->post('grad_name')[$x]),
									'grad_course' => strtoupper($this->input->post('grad_course')[$x]),
									'grad_year' => strtoupper($this->input->post('grad_year')[$x]),
									'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
							);

						$this->db->insert('highest', $items);
					}
				}
			
				return true;
	    }





	    public function update_work_informations($data = null)
	    {	

	        $count_product = count($this->input->post('position_title'));

			
			if($count_product)
				{
					$this->db->where('applicant_id', $this->session->userdata['logged_in_user']['applicant_id']);
					$this->db->delete('work_experiences');

					for($x = 0; $x < $count_product; $x++) {

						$items = array(
								'position_title' => strtoupper($this->input->post('position_title')[$x]),
								'date_start' => strtoupper($this->input->post('date_start')[$x]),
								'date_end' => strtoupper($this->input->post('date_end')[$x]),
								'company' => strtoupper($this->input->post('company')[$x]),
								'monthly_salary' => strtoupper($this->input->post('monthly_salary')[$x]),
								'pay_grade' => strtoupper($this->input->post('pay_grade')[$x]),
								'status' => strtoupper($this->input->post('status')[$x]),
								'is_gov' => strtoupper($this->input->post('is_gov')[$x]),
								'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
							);

						$this->db->insert('work_experiences', $items);
					}
				}
			
				return true;
			

		}

		public function add_voluntary_informations($data = null)
	    {
	        $count_product = count($this->input->post('voluntary_name'));

			for($x = 0; $x < $count_product; $x++) {

				$items = array(
							'voluntary_name' => strtoupper($this->input->post('voluntary_name')[$x]),
							'date_start' => strtoupper($this->input->post('date_start')[$x]),
							'date_end' => strtoupper($this->input->post('date_end')[$x]),
							'number' => strtoupper($this->input->post('number')[$x]),
							'position' => strtoupper($this->input->post('position')[$x]),
							'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
						);

			$update_fam              = array('vw' => 1, 'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']);
			$this->Info_model->vw($update_fam);

			$this->db->insert('voluntary', $items);
				}

			return true;
	    }


	    public function update_voluntary_informations($data = null)
	    {	

	        $count_product = count($this->input->post('voluntary_name'));

			
			if($count_product)
				{
					$this->db->where('applicant_id', $this->session->userdata['logged_in_user']['applicant_id']);
					$this->db->delete('voluntary');

					for($x = 0; $x < $count_product; $x++) {

						$items = array(
								'voluntary_name' => strtoupper($this->input->post('voluntary_name')[$x]),
								'date_start' => strtoupper($this->input->post('date_start')[$x]),
								'date_end' => strtoupper($this->input->post('date_end')[$x]),
								'number' => strtoupper($this->input->post('number')[$x]),
								'position' => strtoupper($this->input->post('position')[$x]),
								'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
							);

						$this->db->insert('voluntary', $items);
					}
				}
			
				return true;
			

		}

		public function add_ld_informations($data = null)
	    {
	        $count_product = count($this->input->post('title'));

			for($x = 0; $x < $count_product; $x++) {

				$items = array(
							'title' => strtoupper($this->input->post('title')[$x]),
							'date_start' => strtoupper($this->input->post('date_start')[$x]),
							'date_end' => strtoupper($this->input->post('date_end')[$x]),
							'number' => strtoupper($this->input->post('number')[$x]),
							'type' => strtoupper($this->input->post('type')[$x]),
							'sponsor' => strtoupper($this->input->post('sponsor')[$x]),
							'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
						);

				$update_fam              = array('ld' => 1,'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']);
			$this->Info_model->ld($update_fam);

			$this->db->insert('ld', $items);
				}

			return true;
	    }


	    public function update_ld_informations($data = null)
	    {	

	        $count_product = count($this->input->post('title'));

			
			if($count_product)
				{
					$this->db->where('applicant_id', $this->session->userdata['logged_in_user']['applicant_id']);
					$this->db->delete('ld');

					for($x = 0; $x < $count_product; $x++) {

						$items = array(
								'title' => strtoupper($this->input->post('title')[$x]),
								'date_start' => strtoupper($this->input->post('date_start')[$x]),
								'date_end' => strtoupper($this->input->post('date_end')[$x]),
								'number' => strtoupper($this->input->post('number')[$x]),
								'type' => strtoupper($this->input->post('type')[$x]),
								'sponsor' => strtoupper($this->input->post('sponsor')[$x]),
								'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
							);

						$this->db->insert('ld', $items);
					}
				}
			
				return true;
			

		}


		public function add_others_informations($data = null)
	    {
	        $count_product = count($this->input->post('hobbies'));

			for($x = 0; $x < $count_product; $x++) {

				$items = array(
							'hobbies' => strtoupper($this->input->post('hobbies')[$x]),
							'recognition' => strtoupper($this->input->post('recognition')[$x]),
							'membership' => strtoupper($this->input->post('membership')[$x]),
							'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
						);

				$update_fam              = array('other_2' => 1, 'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']);
			$this->Info_model->other_2($update_fam);

			$this->db->insert('others', $items);
				}

			return true;
	    }


	    public function update_others_informations($data = null)
	    {	

	        $count_product = count($this->input->post('hobbies'));

			
			if($count_product)
				{
					$this->db->where('applicant_id', $this->session->userdata['logged_in_user']['applicant_id']);
					$this->db->delete('others');

					for($x = 0; $x < $count_product; $x++) {

						$items = array(
								'hobbies' => strtoupper($this->input->post('hobbies')[$x]),
								'recognition' => strtoupper($this->input->post('recognition')[$x]),
								'membership' => strtoupper($this->input->post('membership')[$x]),
								'applicant_id' => $this->session->userdata['logged_in_user']['applicant_id']
							);

						$this->db->insert('others', $items);
					}
				}
			
				return true;
			

		}

	}



		