<?php
	
	class View_model extends CI_Model
	{
		
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
		}


		var $table = 'applicants';
	    var $column_order = array('jobs.position_title','jobs.place_of_assignment',null);
	    var $column_search = array('jobs.position_title','jobs.place_of_assignment');
	    var $order = array('activities.activity_id' => 'desc');

     	public function get_datatables()
	    {
	        $this->_get_datatables_query();
	        if($_POST['length'] != -1)
	        $this->db->limit($_POST['length'], $_POST['start']);
	        $query = $this->db->get();
	        return $query->result();

	    }

	    private function _get_datatables_query()
	    {	
    	 	$this->db->select('applicants.*, jobs.*, activities.*, actions.*');
	        $this->db->from($this->table);
	     
	 		$this->db->join('jobs', 'jobs.job_id = applicants.job_id');
 			$this->db->join('activities', 'activities.applicant_Id = applicants.applicant_id');
 			$this->db->join('actions', 'actions.action_id = activities.action_id');
 		 	$this->db->where('applicants.applicant_id', $this->session->userdata['logged_in_user']['applicant_id']);
	      
	      
	 		

	        $i = 0;
	     
	        foreach ($this->column_search as $item) // loop column 
	        {
	            if($_POST['search']['value']) // if datatable send POST for search
	            {
	                 
	                if($i===0) // first loop
	                {
	                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
	                    $this->db->like($item, $_POST['search']['value']);
	                }
	                else
	                {
	                    $this->db->or_like($item, $_POST['search']['value']);
	                }
	 
	                if(count($this->column_search) - 1 == $i) //last loop
	                    $this->db->group_end(); //close bracket
	            }
	            $i++;
	        }
	         
	        if(isset($_POST['order'])) // here order processing
	        {
	            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
	        } 
	        else if(isset($this->order))
	        {
	            $order = $this->order;
	            $this->db->order_by(key($order), $order[key($order)]);
	        }
	    	}

		    public function count_filtered()
		    {
		        $this->_get_datatables_query();
		        $query = $this->db->get();
		        return $query->num_rows();
		    }
		 
		    public function count_all()
		    {
		        $this->db->from($this->table);
		        return $this->db->count_all_results();
		    }


	}


?>