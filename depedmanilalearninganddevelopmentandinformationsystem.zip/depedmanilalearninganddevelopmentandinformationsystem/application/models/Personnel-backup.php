<?php
	class Personnel_model extends CI_Model
	{
		
		public function __construct()
		{
			parent::__construct();
			$this->load->database();
		}

		public function getEmployees($postData=null){

			$response = array();

			## Read value
			$draw = $postData['draw'];
			$start = $postData['start'];
			$rowperpage = $postData['length']; // Rows display per page
			$columnIndex = $postData['order'][0]['column']; // Column index
			$columnName = $postData['columns'][$columnIndex]['data']; // Column name
			$columnSortOrder = $postData['order'][0]['dir']; // asc or desc
			$searchValue = $postData['search']['value']; // Search value

			$searchEmail = $postData['searchEmail'];

			$search_arr = array();
			$searchQuery = "";
			if($searchValue != ''){
			  $search_arr[] = " (email_address like '%".$searchValue."%' or 
			        email_address like '%".$searchValue."%' or 
			        email_address like'%".$searchValue."%' ) ";
			}
			if($searchEmail != ''){
			  $search_arr[] = " email_address='".$searchEmail."' ";
			}

			if(count($search_arr) > 0){
			  $searchQuery = implode(" and ",$search_arr);
			}

			## Total number of records without filtering
			$this->db->select('count(*) as allcount');
			$records = $this->db->get('applicants')->result();
			$totalRecords = $records[0]->allcount;

			## Total number of record with filtering
			$this->db->select('count(*) as allcount');
			if($searchQuery != '')
			$this->db->where($searchQuery);
			$records = $this->db->get('applicants')->result();
			$totalRecordwithFilter = $records[0]->allcount;

			## Fetch records
			$this->db->select('*');
			if($searchQuery != '')
			$this->db->where($searchQuery);
			$this->db->order_by($columnName, $columnSortOrder);
			$this->db->limit($rowperpage, $start);
			$records = $this->db->get('applicants')->result();

			$data = array();

			$no=1;
			foreach($records as $record ){
			 
			  	$data[] = 	array( 		
				
							      	"first_name"		=>	$record->last_name.', '.$record->first_name.' '.$record->middle_name,
							      	"email_address"		=>	$record->email_address,
							      	"date_of_birth"		=>	$record->date_of_birth,
							      	
						  	); 
			}

		      ## Response
		      $response = array(
		          "draw" => intval($draw),
		          "iTotalRecords" => $totalRecords,
		          "iTotalDisplayRecords" => $totalRecordwithFilter,
		          "aaData" => $data
		      );

     			 return $response; 
  			}


		  public function getEmail(){

		      ## Fetch records
		      $this->db->distinct();
		      $this->db->select('email_address');
		      $this->db->order_by('email_address','asc');
		      $records = $this->db->get('applicants')->result();

		      $data = array();

		      foreach($records as $record ){
		         
		          $data[] = $record->email_address;
		      }

		      return $data;
		  }

	}
?>
